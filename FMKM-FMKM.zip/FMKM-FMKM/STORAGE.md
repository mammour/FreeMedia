***
***
**[◄◄ Back to Wiki Index](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/index)**
***

**[Table of Contents](https://i.imgur.com/Qz5ADdf.png)** - For mobile users

***
***

#### 3D Modeling Apps

[Blender](https://www.blender.org/) / [Render](https://github.com/prman-pixar/RenderManForBlender), [Spline](https://spline.design/), [Anim8or](https://www.anim8or.com/), [Wings 3D](http://www.wings3d.com/), [JustSketch.Me](https://justsketch.me/), [Tinkercad](https://www.tinkercad.com/), [Chakoku](https://github.com/itta611/ChokokuCAD), [PovRay](http://www.povray.org/), [FreeCAD](https://www.freecadweb.org/), [PicoCad](https://johanpeitz.itch.io/picocad), [Vectary](https://www.vectary.com/), [LibreCAD](https://librecad.org/), [Art of Illusion](http://aoi.sourceforge.net/), [BRL-CAD](https://brlcad.org/) 

***

#### 3D Models

[CGPersia](https://cgpersia.com/), [Clara](https://clara.io/library), [Sketchfab](https://sketchfab.com/), [GrabCad](https://grabcad.com/), [Daz3D](https://www.3dcu.com/), [3DRU](https://3dru.net/), [CGDownloads](https://cgdownloads.com/), [P3DM](https://p3dm.ru/), [3D-Load](https://3d-load.net/), [CGTrader](https://www.cgtrader.com/free-3d-models), [Free3D](https://free3d.com/), [VRModels](https://vrmodels.store/), [TurboSquid](https://www.turbosquid.com/), [CadNav](https://www.cadnav.com/), [BlendSwap](https://www.blendswap.com/), [3DModelsCC0](https://www.3dmodelscc0.com/), [Blenders-Models](https://www.blender-models.com/), [Render State](https://render-state.to/), [Open3DModel](https://www.open3dmodel.com/), [KiCad](https://kicad.github.io/), [Archive3d](https://archive3d.net/), [TopGFX](http://topgfx.info/index.php), [3DPirate](https://3dpirate.net/), [3dexport](https://3dexport.com/free-3d-models), [shop3dmili](https://shop3dmili.com/free), [archibaseplanet](https://archibaseplanet.com/), [cults3d](https://cults3d.com/), [3dsky](https://3dsky.org/), [turbosquid](https://www.turbosquid.com/Search/3D-Models/free), [3dwarehouse](https://3dwarehouse.sketchup.com/), [BlenderKit](https://www.blenderkit.com/), [3Dmili](https://3dmili.com/), [3DFree](https://www.3dfree.top/), [poly.pizza](https://poly.pizza/), [rigmodels](https://rigmodels.com/)

***

#### 3DS Roms

* [CIA-3DS](https://www.cia-3ds.com/)
* [ciaspara3ds](https://ciaspara3ds.blogspot.com/)
* [HShop](https://hshop.erista.me/)

***

#### Absolute Enable Right Click

Absolute Enable - [Firefox](https://addons.mozilla.org/en-US/firefox/addon/absolute-enable-right-click/) /
[Chrome](https://chrome.google.com/webstore/detail/absolute-enable-right-cli/jdocbkpgdakpekjlhemmfcncgdjeiika) / [Script](https://greasyfork.org/en/scripts/23772-absolute-enable-right-click-copy)

Simple Allow - [Firefox](https://addons.mozilla.org/en-US/firefox/addon/simple-allow-copy/) / [Chrome](https://chrome.google.com/webstore/detail/simple-allow-copy/aefehdhdciieocakfobpaaolhipkcpgc?hl=en)

***

#### Adblock Defenders

**[AdGuardExtra](https://github.com/AdguardTeam/AdGuardExtra)** / [Script](https://userscripts.adtidy.org/release/adguard-extra/1.0/adguard-extra.user.js), **[fuck fuckadblock](https://bogachenko.github.io/fuckfuckadblock/)**, [BlockAdblock Blocker](https://greasyfork.org/en/scripts/406036-blockadblock-blocker), [Easylist](https://easylist-downloads.adblockplus.org/antiadblockfilters.txt), [Assassinate Ad Block Blockers](https://greasyfork.org/en/scripts/382482-assassinate-ad-block-blockers)

[Test Adblock Defender](https://blockads.fivefilters.org/)

***

####  Alternative Search Engines

* **https://yandex.com/**
* **https://go.mail.ru/**
* **https://www.baidu.com/** - [PHP Version](https://github.com/yuantuo666/baiduwp-php)
* **https://r0.ru/** 
* **https://www.ecosia.org/** - [Firefox](https://addons.mozilla.org/en-US/firefox/addon/ecosia-the-green-search/) / [Chrome](https://chrome.google.com/webstore/detail/ecosia-the-search-engine/eedlgdlajadkbbjoobobefphmfkcchfk)
* https://oceanhero.today/
* https://llarryyllarryy.github.io/Max-Impact-Search/
* https://www.lycos.com/
* https://www.dogpile.com/
* http://advangle.com/
* http://gigablast.com/
* https://www.webcrawler.com/ 
* https://millionshort.com/
* https://www.wiby.me/
* https://www.goodshop.com/
* https://mwmbl.org/ + [GitHub](https://github.com/mwmbl/mwmbl)
* https://lazyweb.ai/
* https://www.instya.com/
* https://ambition.dk/kompetencer/media-search-social/trafik/tools/impersonal/
* https://education.iseek.com/iseek/home.page
* https://www.lycos.com/
* https://search.excite.com/
* https://www.oscobo.com/
* https://www.search.com/
* https://www.metacrawler.com/
* http://fefoo.com/
* https://www.entireweb.com/
* https://www.chatnoir.eu/
* https://felvin.com/
* https://petalsearch.com/
* https://okeano.com/ 
* http://www.seekport.com/
* https://www.exalead.com/search/
* http://www.search.tl/
* https://andisearch.com/
* https://search.carrot2.org/#/web
* http://www.surfcanyon.com/
* https://you.com/
* https://www.teoma.com/
* https://www.4search.com/
* https://www.info.com/
* https://www.yahoo.com/
* http://frogfind.com/
* https://search.visymo.com/
* https://entfer.com/
* https://presearch.org/ + [GitHub](https://github.com/presearchofficial)
* https://search.aol.com/
* https://www.bing.com/
* https://www.entireweb.com/
* https://all-io.net/
* https://www.alltheinternet.com/
* https://www.etools.ch/
* https://www.faganfinder.com/
* http://www.goofram.com/
* https://www.izito.com/
* http://www.myallsearch.com/
* https://www.zapmeta.com/
* https://biznar.com/biznar/desktop/en/search.html
* https://www.etools.ch/search.do
* http://citeseer.ist.psu.edu/index
* https://www.harmari.com/search/unified/
* https://worldwidescience.org/
* https://www.startpage.com/
* https://github.com/prabhatsharma/zinc
* https://benbusby.com/projects/whoogle-search/

**Non-English**

* http://www.alleba.com/
* https://www.eniro.se/
* https://www.goo.ne.jp/
* http://www.najdi.si/
* https://www.naver.com/
* https://www.onet.pl/
* https://www.orange.fr/portail
* http://www.parseek.com/
* https://www.sapo.pt/
* https://www.walla.co.il/
* https://www.2lingual.com/

***

#### Alternative Software / App Sites

**[AlternativeTo](https://alternativeto.net/)**, [Ethical](https://ethical.net/resources/), [Slant](https://www.slant.co/), [SaaSHub](https://www.saashub.com/), [switching.software](https://switching.software/), [ALTERNATIVES](https://github.com/mayfrost/guides/blob/master/ALTERNATIVES.md), [Alternative.me](https://alternative.me/), [Top Best Alternatives](https://www.topbestalternatives.com/), [GoFOSS](https://gitlab.com/curlycrixus/gofoss), [osalt](http://osalt.com/), [Open Source Alternatives](https://www.opensourcealternative.to/), [Alternatives.app](https://alternatives.app/), [AlternativeBK](https://alternativebk.com/), [TopAlter](https://topalter.com/), [Prism Break](https://prism-break.org/)

***

#### Alternative Twitch Player

[Firefox](https://addons.mozilla.org/en-US/firefox/addon/twitch_5/), [Chrome](https://chrome.google.com/webstore/detail/alternate-player-for-twit/bhplkbgoehhhddaoolmakpocnenplmhf)

***

#### Ambient Rain Sounds

**[RainyMood](https://www.rainymood.com/)**, [Rainbow Hunt](https://rainbowhunt.com/), [Pluvior](https://pluvior.com/), [rainfor.me](http://rainfor.me/), [Raining.fm](https://raining.fm/), [Rainyscope](https://rainyscope.com/)

***

#### Android Audio Players

[VLC](https://www.videolan.org/vlc/download-android.html), [mpv-android](https://f-droid.org/packages/is.xyz.mpv), [Foobar2000](https://www.foobar2000.org/apk), [Vanilla Music](https://f-droid.org/packages/ch.blinkenlights.android.vanilla), [Vinyl Music Player](https://f-droid.org/packages/com.poupa.vinylmusicplayer), [BlackHole](https://github.com/Sangwan5688/BlackHole), [RAAG](https://github.com/raag-music/raag/), [Metro](https://f-droid.org/en/packages/io.github.muntashirakon.Music/), [Pulse Music](https://f-droid.org/en/packages/com.hardcodecoder.pulsemusic/), [Musicolet](https://play.google.com/store/apps/details?id=in.krosbits.musicolet&hl=en_US&gl=US), [RetroMusicPlayer](https://github.com/RetroMusicPlayer/RetroMusicPlayer), [Auxio](https://f-droid.org/en/packages/org.oxycblt.auxio/), [RetroPad](https://jamesob.com/apps/retropod.html), [Apollo-Music](https://github.com/nuclearfog/Apollo-Music), [Music Player GO](https://github.com/enricocid/Music-Player-GO), [Nyx](https://play.google.com/store/apps/details?id=com.awedea.nyx), [Serenity](https://github.com/YajanaRao/Serenity), [ExoPlayer](https://github.com/google/ExoPlayer), [Timber](https://github.com/naman14/Timber), [TimberX](https://github.com/naman14/TimberX), [Howl](https://github.com/Iamlooker/Howl), [SoundSpice](https://github.com/farshed/SoundSpice-mobile), [Bungee](https://github.com/OpenConsultingGroup/Flutter-Music-App)

***

#### Android Browsers

**[Browsers Wiki](https://en.m.wikipedia.org/wiki/Comparison_of_web_browsers)**, [2](https://en.m.wikipedia.org/wiki/List_of_web_browsers), [Iceraven Browser](https://github.com/fork-maintainers/iceraven-browser), [Kiwi](https://kiwibrowser.com/), [Stargon Browser](https://play.google.com/store/apps/details?id=net.onecook.browser), [Berry Browser](https://play.google.com/store/apps/details?id=jp.ejimax.berrybrowser), [Ecoasia](https://play.google.com/store/apps/details?id=com.ecosia.android), [AlohaBrowser](https://alohabrowser.com/), [Naked Browser](https://play.google.com/store/apps/details?id=com.fevdev.nakedbrowser), [Via](https://play.google.com/store/apps/details?id=mark.via.gp), [Lynket](https://github.com/arunkumar9t2/lynket-browser), [Lightning](https://github.com/anthonycr/Lightning-Browser), [Dot Browser](https://github.com/dothq/browser-android) , [Fennec](https://f-droid.org/en/packages/org.mozilla.fennec_fdroid/) (Debloated Firefox), [Float](https://play.google.com/store/apps/details?id=com.xpp.floatbrowser), [EinkBro](https://f-droid.org/packages/info.plateaukao.einkbro/) (Eink Devices)

***

#### Android Note Apps

[xaviertobin](https://play.google.com/store/apps/details?id=com.xaviertobin.noted), [colornote](https://www.colornote.com/), [notion](https://www.notion.so/), [joplinapp](https://joplinapp.org/), [standardnotes](https://standardnotes.org/), [zoho](https://www.zoho.com/notebook/), [getupnote](https://play.google.com/store/apps/details?id=com.getupnote.android), [onenote](https://support.microsoft.com/en-us/office/microsoft-onenote-for-android-46b4b49d-2bef-4746-9c30-6abb5e20b688), [markor](https://fossdroid.com/a/markor.html), [Leaflet](https://github.com/PotatoProject/Leaflet), [neuriNote](https://github.com/appml/neutrinote), [easy4u](https://play.google.com/store/apps/details?id=co.easy4u.writer), [orgzly](http://www.orgzly.com/), [Markor](https://gsantner.net/project/markor.html) / [GitHub](https://github.com/gsantner/markor), [sNotz](https://sunilpaulmathew.github.io/sNotz/) / [GitHub](https://github.com/sunilpaulmathew/sNotz), [JustNote](https://justnote.cc/), [Quillnote](https://play.google.com/store/apps/details?id=org.qosp.notes)

***

#### Android Operating Systems

**[Android Rom List](https://github.com/musabcel/android_rom_list)**, [LineageOS](https://www.lineageos.org/), [Replicant](https://www.replicant.us/), [potatoproject](https://potatoproject.co/), [ArrowOS](https://arrowos.net/download), [CDroid](https://crdroid.net/), [HavocOS](https://sourceforge.net/projects/havoc-os/), [Corvusrom](https://www.corvusrom.com/), [BlissRoms](https://downloads.blissroms.org/), [ParanoidAndroid](https://paranoidandroid.co/), [PixelExperience](https://download.pixelexperience.org/), [Evolution-x](https://evolution-x.org/), [e.foundation](https://e.foundation/), [BeyondROM_S20](https://t.me/BeyondROM_S20), [ProtonAOSP](https://protonaosp.org/) / [GitHub](https://github.com/ProtonAOSP), [Anarchy-Droid](https://anarchy-droid.com/) / [Github](https://github.com/amo13/Anarchy-Droid), [Evolution X](https://evolution-x.org/), [ProjectBlaze](https://github.com/ProjectBlaze)

***

#### Android TV IPTV Players

[TiviMate](https://play.google.com/store/apps/details?id=ar.tvplayer.tv), [implayer](https://implayer.tv/), [iptvsmarters](https://www.iptvsmarters.com/), [ottnavigator](https://play.google.com/store/apps/details?id=studio.scillarium.ottnavigator). [homeiptv](https://www.homeiptv.com/)

***

#### Anime Download Apps

[Monkey-DL](https://github.com/Oshan96/monkey-dl), [HakuNeko](https://hakuneko.download/) / [2](https://github.com/manga-download/hakuneko), [Anime Downloader](https://github.com/anime-dl/anime-downloader), [Anigrab](https://github.com/ngomile/anigrab), [AnimeDL](https://github.com/justfoolingaround/animdl), [ultimate-batch-anime-downloader](https://github.com/KorigamiK/ultimate-batch-anime-downloader), [AnimeClassroom](https://github.com/justdvnsh/AnimeClassroom), [Anime-Downloader](https://github.com/henry-richard7/Anime-Downloader), [Anime-dl](https://github.com/gabelluardo/anime-dl) / [2](https://github.com/vrienstudios/anime-dl) / [3](https://github.com/vrienstudios/anime-dl)
***

#### Antivirus

**[Malwarebytes Premium](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/base64#wiki_malwarebytes_premium)**, [Hitman Pro](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/base64#wiki_hitman_pro), [Adaware Antivirus](https://www.adaware.com/free-antivirus-download), [ClamAV](https://www.clamav.net/), [Emisoft Emergency Kit](https://www.emsisoft.com/en/home/emergencykit/), [Immunet](https://www.immunet.com). [Eset nod32](https://eset.version-2.sg/event/trial/) (Use Temp Accounts), [MalwareScanner](https://github.com/password123456/malwarescanner), [EsetKeyRobot](https://t.me/EsetKeyRobot)

***

#### App Launchers

[Omega Launcher](https://github.com/otakuhqz/omega), [SmartLauncher](https://www.smartlauncher.net/) / [Pro](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/base64#wiki_smartlauncher_pro), [Lawnchair](https://lawnchair.app/), [Launchers Quick Tile](https://play.google.com/store/apps/details?id=com.gocalsd.quicktile.launchers), [ActivityLauncher](https://github.com/butzist/ActivityLauncher), [Smart Dock](https://github.com/axel358/smartdock), [Microsoft Launcher](https://play.google.com/store/apps/details?id=com.microsoft.launcher), [Olauncher](https://github.com/jooooscha/Olauncher), [Unlauncher](https://github.com/jkuester/unlauncher), [Ratio](https://blloc.com/), [Edge Card Launcher](https://play.google.com/store/apps/details?id=com.reactivstudios.android.edge4), [Nova 7.0](https://www.apkmirror.com/apk/teslacoil-software/nova-launcher/nova-launcher-7-0-57-release/) / [8.0](https://www.apkmirror.com/apk/teslacoil-software/nova-launcher/nova-launcher-8-0-1-release/) (Pre-Acquisition), [Stario](https://play.google.com/store/apps/details?id=com.stario.launcher)

***

#### Audio Converters

[FFmpeg](https://ffmpeg.org/), [Audio Converter Online](https://online-audio-converter.com/), [FlicFlac](https://github.com/DannyBen/FlicFlac), [LameXP](https://sourceforge.net/projects/lamexp/), [FFaudioConverter](https://github.com/Bleuzen/FFaudioConverter/), [SoX](http://sox.sourceforge.net/), [FreeAC](https://www.freac.org/), [OnlineAudioConverter](https://onlineaudioconverter.com/), [dBpoweramp](https://www.dbpoweramp.com/dmc.htm), [FLAC2iTunes](https://github.com/pathartl/FLAC2iTunes/releases/tag/1.0.0), [M4AtoMP3](https://m4amp3.com/),  [M4AtoWAV](https://m4atowav.com/), [fre : ac](https://github.com/enzo1982/freac)

***

#### Audio Editors 

**[G-Meh](https://g-meh.com/vst/)**, **[Audacity](https://github.com/cookiengineer/audacity)**, [2](https://archive.org/details/audacity-2.4.2), [3](https://www.audacityteam.org/), [4](https://github.com/temporary-audacity/audacity), [5](https://tenacityaudio.org/), [6](https://github.com/Audacium/audacium) / [DarkAudacity](http://www.darkaudacity.com/), [MusE](https://muse-sequencer.github.io/), [Lexis Audio Editor](https://www.lexisaudioeditor.com/), [mp3DirectCut](https://mpesch3.de/), [Ardour](https://ardour.org/), [LMMS](https://lmms.io/), [AudioMass](https://audiomass.co/), [FamiStudio](https://famistudio.org/), [ocenaudio](https://www.ocenaudio.com/en/startpage), [mp3mymp3](https://mp3mymp3.digitalliquid.com/), [Wavosaur](https://www.wavosaur.com/), [Sneedcity](https://github.com/Sneeds-Feed-and-Seed/sneedacity), [Radium](https://users.notam02.no/~kjetism/radium/), [AudioDope](http://www.audiodope.org/index.htm), [FL Studio](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/base64#wiki_fl_studio), [OpenMPT](https://openmpt.org/), [Schism](http://schismtracker.org/), [Radium](https://users.notam02.no/~kjetism/radium/index.php), [WaveBots](https://krasse.itch.io/wavebots-editor), [BandLab](https://www.bandlab.com/)

***

#### Audio Plugins 

**[/r/CrackedPluginsX](https://www.reddit.com/r/CrackedPluginsX/)**, [OpenAudio](https://github.com/webprofusion/OpenAudio), [/u/BitterApple69 Plugins](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/base64#wiki_.2Fu.2Fbitterapple69_plugins), [FreeVSTPlugins](https://freevstplugins.net/), [KVRAudio](https://www.kvraudio.com/plugins/the-newest-plugins/free), [PLUGINS4FREE](https://plugins4free.com/), [dskmusic](https://www.dskmusic.com/), [landr](https://blog.landr.com/best-free-vst-plugins/), [native-instruments](https://www.native-instruments.com/en/specials/free-vst-plugins/), [sparta](https://leomccormack.github.io/sparta-site/), [IEM](https://plugins.iem.at/), [PluginTorrent](https://plugintorrent.com/), [/r/PluggnB/](https://www.reddit.com/r/PluggnB/), [Free VST Spreadsheet](https://docs.google.com/spreadsheets/d/1wr0RjPfQvD_VrIivi4U4tsnqMdL78sWOaDUI2Z95R9U/htmlview?fbclid=IwAR3jUwxfkL7aMruLKomutJZ7-H3xjM1X4JX422mSbCgECdt5ugkHtGWlsF8#gid=0), [Plugins Cloud](https://t.me/joinchat/eBPFLPGucTU5YjQ9), [PluginsCloudArchive](https://t.me/plugincloudsarchive), [PluginCloudArchive_docs](https://t.me/pluginclouds_docs), [AudiosTorrent](https://audiostorrent.in/), [VSTs & Packs](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/base64#wiki_vsts_.26amp.3B_packs)

***

#### Audio Servers

**[iBroadcast](https://ibroadcast.com)**, [koel](https://koel.dev/) / [Docker](https://github.com/0xcaff/docker-koel), [Fidbak](https://fidbak.audio/), [MadSonic](https://www.madsonic.org/pages/index.jsp), [Navidrome](https://www.navidrome.org/), [Koozic](https://koozic.net/), [mStream](https://mstream.io/) / [Git](https://github.com/IrosTheBeggar/mStream), [Serviio](https://www.serviio.org/), [Airsonic](https://airsonic.github.io/), [Airsonic Advanced](https://github.com/airsonic-advanced/airsonic-advanced) / [Advanced UI](https://github.com/tamland/airsonic-refix), [SoundGasm](https://soundgasm.net/), [Polaris](https://github.com/agersant/polaris), [Echo](https://github.com/anhthii/Echo), [Black Candy](https://github.com/aidewoode/black_candy), [Mopidy](https://mopidy.com/) / [GitHub](https://github.com/mopidy)

***

#### Audio Synthesizers

[Web Synth V2](http://aikelab.net/websynthv2/), [SuperCollider](https://supercollider.github.io/), [ZynAddSubFX](https://zynaddsubfx.sourceforge.io/), [Surge](https://surge-synthesizer.github.io/), [Dexed](https://asb2m10.github.io/dexed/), [Bespoke](https://www.bespokesynth.com/), [Helm](https://tytel.org/helm/), [TANGUY](http://tanguysynth.com/), [SunVox](https://warmplace.ru/soft/sunvox/), [Sinsy](http://www.sinsy.jp/), [DSoundSoft](http://dsoundsoft.com/), [Hydrogen](http://hydrogen-music.org/), [Ribs](https://hvoyaaudio.itch.io/ribs), [Qasar Beach](https://adamstrange.itch.io/qasarbeach)

***

####  Automation Tools

[integromat](https://www.integromat.com/), [zapier](https://zapier.com/), [Automate.io](https://automate.io/), [huginn](https://github.com/huginn/huginn), [ifttt](https://ifttt.com/), [Microsoft Flow](https://flow.microsoft.com/), [n8n](https://n8n.io/), [automatio](https://automatio.co/), [Bardeen](https://www.bardeen.ai/), [Browserflow](https://browserflow.app/), [rrweb](https://www.rrweb.io/) / [GitHub](https://github.com/rrweb-io/rrweb)

***

#### Auto Text Expander 

[Firefox](https://addons.mozilla.org/en-US/firefox/addon/auto-text-expander/) / [Chrome](https://chrome.google.com/webstore/detail/auto-text-expander-for-go/iibninhmiggehlcdolcilmhacighjamp?hl=en)

***

#### Background Removers 

[Remove.bg](https://www.remove.bg/) / [Gimp](https://github.com/manu12121999/RemoveBG-GIMP), [Remove Background](https://pixlr.com/remove-background/), [Rembg](https://github.com/danielgatis/rembg), [Adobe BG Remover](https://www.adobe.com/express/feature/image/remove-background), [bgremover](https://icons8.com/bgremover), [Removal.ai](https://removal.ai/upload/), [Trace](https://www.stickermule.com/trace), [BackgroundCut](https://backgroundcut.co/), [Retoucher](https://retoucher.online/), [Erase-BG](https://www.erase.bg/en/upload), [FocoClippings](https://www.fococlipping.com/), [fotor](https://www.fotor.com/features/background-remover), [ClippingsMagic](https://clippingmagic.com/), [BGEraser](https://bgeraser.com/)

***

#### BetterDiscord Tools

[Plugins](https://betterdiscord.app/plugins) / [Addons](https://github.com/QbDesu/BetterDiscordAddons) / [Themes](https://www.limeshark.dev/editor), [2](https://bdeditor.dev/) / [Support](https://discord.gg/0Tmfo5ZbORCRqbAd), [2](https://discord.gg/sbA3xCJ) / [Animated PFP](https://discord.gg/xzwKqwvQcP) / [Alt DevilBroPlugins](https://github.com/BD-MemorySeal/DevilBro-Alternatives/tree/distribution) / [Discord](https://discord.gg/6hkKNa4MRN) / [Account Switcher](https://github.com/l0c4lh057/AccountSwitcher)

***

#### Browser EBook Readers

[fViewer](https://www.fviewer.com/), [Reader View](https://add0n.com/chrome-reader-view.html) / [2](https://mybrowseraddon.com/reader-view.html), [Tranquility](https://addons.mozilla.org/en-GB/firefox/addon/tranquility-1/), [EpubPress](https://epub.press/), [ePubReader](https://www.epubread.com/en/), [Mercury](https://mercury.postlight.com/), [LoudReader](https://www.loudreader.com/), [ReadWok](https://readwok.com/), [2read](https://2read.net/), [Reader Mode](https://readermode.io/), [ePub Reader Online](https://www.ofoct.com/viewer/epub-reader-online.html), [ebook.web](https://ttu-ebook.web.app/)

***

#### Browser Startpages

**[WebOas.is](https://weboasis.app/)**, [2](https://ndsamuelson.github.io/weboas-is/), [3](https://oasis.h7x.co/wo/), [4](https://weboasis.mon5termatt.club/) / [Source Code](https://pastebin.com/CczqreS4), **[monknow](https://www.monknow.com/)**, [8bitdash](https://www.8bitdash.com/), [8Bitdashboard](https://8bitdashboard.com/), [Startpage Emporium](https://startpages.github.io/), [Awesome Startpage](https://github.com/jnmcfly/awesome-startpage), [StartTree](https://github.com/Paul-Houser/StartTree), [New Tab Addons](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/storage#wiki_customizable_new_tab_page), [clippingmini](https://www.clippingmini.com/), [klepit](https://www.klepit.com/), [draggo](http://draggo.com/), [atavi](https://atavi.com/), [homepage](https://homepage.ninja/), [bookmarkee](https://www.bookmarkee.com/), [pearltrees](https://www.pearltrees.com/), [lasso](https://www.lasso.net/), [nextcloud](https://apps.nextcloud.com/apps/bookmarks), [cling](https://cling.com/), [symbaloo](https://www.symbaloo.com/), [tixio](https://tixio.io/), [Bento](https://github.com/migueravila/Bento), [ez.lol](https://ez.lol/), [nightly](https://github.com/Harshit-T/nightly), [Protopage](https://www.protopage.com/)

***

#### Bookmark Managers

[saved.io](https://saved.io/), [BookmarkOS](https://bookmarkos.com/), [Bookmarkify](https://bookmarkify.it/), [Patchwork](http://patchworkapp.com/), [start.me](https://start.me/start/int/startpage), [buku](https://github.com/jarun/buku), [Booky](https://booky.io/), [Raindrop](https://raindrop.io/), [WebCrate](https://webcrate.app/), [Unmark](https://unmark.it/), [Diigo](https://diigo.com/), [Papaly](https://papaly.com/), [linkding](https://github.com/sissbruecker/linkding), [linkace](https://www.linkace.org/), [tagpacker](https://tagpacker.com/), [yabs](https://www.yabs.io/), [readthedocs](https://shaarli.readthedocs.io/en/master/), [mission-control](https://mission-control.app/), [histre](https://histre.com/), [brainytab](https://brainytab.com/), [saveforlater](http://saveforlater.com/), [tryzulu](https://tryzulu.com/), [contentle](https://contentle.com/), [clipix](https://www.clipix.com/), [webcull](https://webcull.com/), [colllect](https://colllect.io/), [sqworl](https://sqworl.com/), [trovenow](https://trovenow.com/), [ggather](https://web.ggather.com/), [openoox](https://openoox.com/), [dropmark](https://www.dropmark.com/), [bookmarkme](https://bookmarkme.io/), [bublup](https://www.bublup.com/), [bkmark](https://bkmark.io/)    

**Extensions** 

[MyMark](https://www.mymark.me/), [Sidebery](https://addons.mozilla.org/en-US/firefox/addon/sidebery/), [Bookmarkify](https://addons.mozilla.org/en-US/firefox/addon/bookmarkos/), [Bookmarks Organizer](https://github.com/cadeyrn/bookmarks-organizer), [Omni](https://github.com/alyssaxuu/omni), [Centroly](https://centroly.com/)

***

#### Bulk File Renamers 

[Advanced Renamer](https://www.advancedrenamer.com/), [theRenamer](http://therenamer.com/), [Hydrus](https://hydrusnetwork.github.io/hydrus/), [Bulk Rename Utility](https://www.bulkrenameutility.co.uk/), [mnamer](https://github.com/jkwill87/mnamer), [Szyszka](https://github.com/qarmin/szyszka), [MassiveFileRenamer](https://github.com/IvanRF/MassiveFileRenamer), [Massren](https://github.com/laurent22/massren), [Renamer](https://github.com/Craftplacer/Renamer)

***

#### Calculator Sites

**[Awesome Calculators](https://github.com/xxczaki/awesome-calculators)**, **[WolframAlpha Math](https://www.wolframalpha.com/examples/mathematics)**, **[Omni Calculator](https://www.omnicalculator.com/)**, [RapidTables](https://www.rapidtables.com/),  [Calculator.net](https://www.calculator.net/sitemap.html), [CalculatorSoup](https://www.calculatorsoup.com/), [QuickMath](https://quickmath.com/), [NumberEmpire](https://www.numberempire.com/), [Easy Calculation](https://www.easycalculation.com/), [Calculatorhut](https://www.calculatorhut.com/), [Calculation Calculators](https://calculationcalculator.com/), [calculator.net](https://www.calculator.net/), [JustFreeTools](https://www.justfreetools.com/en/all-calculators), [Calculat.io](https://calculat.io/), [Keisan](https://keisan.casio.com/), [Calculator.com](https://calculator.com/), [Calculator.net](https://calculator.net/), [Online Calculator](https://www.online-calculator.com/), [calculatort](https://calculatort.com/)
Manhua
***

#### Calendars

[calendso](https://calendso.com/) / [2](https://github.com/calendso/calendso), [Calendly](https://calendly.com/), [Zoho](https://www.zoho.com/calendar/), [Outlook Calendar](https://outlook.office.com/calendar/), [Agenda](https://agenda.edo.io/), [Calendar.com](https://www.calendar.com/), [Tweek](https://tweek.so/), [TinyMonth](https://tinymonth.com/), [arlim](https://arl.im/), [Reclaim](https://reclaim.ai/), [Tui.Calendar](https://github.com/nhn/tui.calendar), [Gantt](https://github.com/neuronetio/gantt-schedule-timeline-calendar), [Morgen](https://www.morgen.so/)

***

#### Calibre Libraries

* http://24.13.229.188:8090/
* http://104.131.175.196:8080/
* http://185.215.227.81:8081/
* http://5.9.21.194:8080/
* http://70.88.180.169:8088/
* http://207.237.122.161:8080/

***

#### Calibre Tools

[Libraries](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/storage#wiki_calibre_libraries), [2](https://reddit.com/r/opencalibre) / [Search](https://www.shodan.io/search?query=server%3A+calibre) / [Web App](https://github.com/janeczku/calibre-web)  

***

#### CanvasBlocker

[Firefox](https://addons.mozilla.org/en-US/firefox/addon/canvasblocker/), [Chrome](https://chrome.google.com/webstore/detail/nomnklagbgmgghhjidfhnoelnjfndfpd)

***

#### Character / Word Counters

[CharacterCountOnline](https://www.charactercountonline.com/), [CharacterCounter](https://charactercounter.com/), [CharacterCounterTool](https://charactercounttool.com/), [OnlineEditText](https://onlinetextedit.com/), [LetterCount](https://www.lettercount.com/), [TheWordCounter](https://thewordcounter.com/), [CharCounter](https://charcounter.com/), [CharacterCounter](https://charactercounter.com/ucas), [WordCounter](https://wordcounter.io/), [CharacterCounter](https://charactercounter.nl/)

***

#### Clipboard Managers

[ArsClip](http://www.joejoesoft.com/vcms/97/), [Ditto Clipboard Manager](https://ditto-cp.sourceforge.io/), [clipboardmemo](https://gitlab.com/fabrom/clipboardmemo), [CopyQ](https://hluk.github.io/CopyQ/), [Free Clipboard Viewer](https://freeclipboardviewer.com/), [Clip Angel](https://sourceforge.net/projects/clip-angel/), [xClipper](https://github.com/KaustubhPatange/XClipper), [MultiClipBoardSlots](https://www.softwareok.com/?seite=Microsoft/MultiClipBoardSlots), [Clipboard Canvas](https://github.com/d2dyno1/ClipboardCanvas), [Xtra Clipboard](https://xtra-clipboard.com/), [Control V](https://ctrl.vi/)

***

#### Cloudstream Forks

* https://codeberg.org/QzReborn/SunStream/releases
* https://github.com/Jacekun/csrelease/releases
* https://github.com/Stormunblessed/CloudStream-3/releases
* https://github.com/recloudstream/cloudstream

***

#### Code Editors 

[SpaceVim](https://spacevim.org/), [Onivun](https://onivim.io/), [vimrc](https://github.com/amix/vimrc), [NeoVim](https://neovim.io/) / [Frontend](https://github.com/rohit-px2/nvui) / [Motions](https://github.com/ggandor/lightspeed.nvim), [Vim](https://www.vim.org/), [Emacs](https://www.gnu.org/software/emacs/) / [Docs](https://www.emacsdocs.org/), [Lite XL](https://lite-xl.github.io/), [Kakoune](http://kakoune.org/), [Brackets](http://brackets.io/), [Micro Editor](https://micro-editor.github.io/index.html), [BlueFish](http://bluefish.openoffice.nl/index.html), [KomodoEdit](https://github.com/Komodo/KomodoEdit), [TextAdept](https://foicica.com/textadept), [SpaceMacs](http://spacemacs.org/), [Notepad2](https://www.flos-freeware.ch/notepad2.html), [Sublime Text](https://www.sublimetext.com/), [Atom](https://atom.io/), [CudaText](https://cudatext.github.io/) / [Git](https://github.com/Alexey-T/CudaText), [Light Table](http://lighttable.com/), [4coder](https://4coder.itch.io/4coder), [lapce](https://lapce.dev/) / [GitHub](https://github.com/lapce/lapce), [Warp](https://www.warp.dev/), [AvaloniaUI](https://avaloniaui.net/), [MassCode](https://masscode.io/), [libvim](https://github.com/onivim/libvim), [amp](https://github.com/jmacdonald/amp)

**Mac Code Editors**

[Vim](https://github.com/macvim-dev/macvim), [CodeEdit](https://github.com/CodeEditApp/CodeEdit)

**Online Code Editors**

[JDFiddle](https://jsfiddle.net/), [W3Schools](https://www.w3schools.com/tryit/trycompiler.asp?filename=demo_python), [CollabEdit](http://collabedit.com/), [Portacode](https://portacode.com/), [IDE One](https://www.ideone.com/), [SoloLearn](https://www.sololearn.com/) / [Playground](https://code.sololearn.com/), [JSFiddle](https://jsfiddle.net/), [PlayCode](https://playcode.io/) 

***

####Color Palette Generators

[Colormind](http://colormind.io/), [SchemeColor](https://www.schemecolor.com/), [MyColor](https://mycolor.space/), [MaterialPalette](https://www.materialpalette.com/), [Adobe Colors](https://color.adobe.com/), [0to255](https://www.0to255.com/), [0xrgb](http://0xrgb.com/), [bootflat](https://bootflat.github.io/color-picker.html), [brandcolors](https://brandcolors.net/), [colorfulgradients](https://colorfulgradients.tumblr.com/), [colourlovers](https://www.colourlovers.com/), [webkul](https://webkul.github.io/coolhue/), [flatuicolors](https://flatuicolors.com/), [materialui](https://materialui.co/colors/), [ColorHunt](https://colorhunt.co/), [colorswall](https://colorswall.com/), [pigment](https://pigment.shapefactory.co/), [Color Palette Generator](http://www.patorjk.com/color-palette-generator/), [colourcode](https://www.toptal.com/designers/colourcode/), [colorscales](http://www.colorscales.com/), [colors.lol](https://colors.lol/), [Color Pallete](http://www.degraeve.com/color-palette), [colorbox](https://colorbox.io/), [colors.eva](https://colors.eva.design/), [hihayk](https://hihayk.github.io/scale/), [calcolor](https://calcolor.co/), [colorlisa](http://www.colorlisa.com/), [cohesive-colors](https://javier.xyz/cohesive-colors/), [colorleap](https://colorleap.app/), [colorhuddle](https://colorhuddle.co/), [Coolors](https://coolors.co/), [uicolors](https://uicolors.app/create), [randoma11y](https://randoma11y.com/), [pywal](https://github.com/dylanaraps/pywal), [Color Wheeel](https://color.adobe.com/create/color-wheel), [ColorKit Palette Generator](https://colorkit.co/color-palette-generator/)

***

#### Collaboration Platforms

[Doozy](https://doozy.live/), [Zulip](https://zulip.com/), [Miro](https://miro.com/),[Mattermost](https://mattermost.org/), [Twake](https://twake.app/), [Asana](https://asana.com/), [Freedcamp](https://freedcamp.com/), [Lumeer](https://www.lumeer.io/), [Slab](https://slab.com/), [TipiCalls](https://tipicalls.com/), [Focalboard](https://www.focalboard.com/), [Wekan](https://wekan.github.io/), [Kanboard](https://kanboard.org/), [Skiff](https://www.skiff.org/), [Mural](https://www.mural.co/), [Dendron](https://www.dendron.so/), [LucidChart](https://www.lucidchart.com/), [Trello](https://trello.com/), [Planka](https://planka.app/), [TaskCafe](https://github.com/JordanKnott/taskcafe) 

***

#### Color Pickers

[Colordot](http://color.hailpixel.com/), [Sorted Colors](https://enes.in/sorted-colors/), [spencerhamm](https://chroma.spencerhamm.com/), [color.adobe](https://color.adobe.com/explore), [colorhexpicker](https://www.colorhexpicker.com/), [obscuredetour](https://color.obscuredetour.com/), [colorkit](https://colorkit.io/), [colorpicker](https://colorpicker.fr/), [culrs](https://www.culrs.com/), [colorwise](https://colorwise.io/), [geenes](https://geenes.app/welcome), [image-color](https://image-color.com/), [instant-eyedropper](http://instant-eyedropper.com/), [khroma](http://khroma.co/), [colorpicker](https://annystudio.com/software/colorpicker/), [materialpalettes](https://materialpalettes.com/), [picular](https://picular.co/), [react-color](http://casesandberg.github.io/react-color/), [viz-palette](https://projects.susielu.com/viz-palette), [leonardocolor](https://leonardocolor.io/), [Any11](http://clrs.cc/a11y/), [imagecolorpicker](https://imagecolorpicker.com/), [cccolor](https://fffuel.co/cccolor/), [Instant Eyedropper](https://github.com/miaupaw/instant-eyedropper), [ColorKit Color Picker](https://colorkit.co/color-picker/)

***

#### Cooking YouTube Channels

* [Binging with Babish](https://www.youtube.com/channel/UCJHA_jMfCvEnv-3kRjTCQXw)
* [JamieOliver](https://www.youtube.com/user/JamieOliver)
* [Bon Appetit](https://www.youtube.com/user/BonAppetitDotCom)
* [Mythical Kitchen](https://www.youtube.com/user/rhettandlink4)
* [Peaceful Cuisine](https://www.youtube.com/user/ryoya1983) 
* [Seonkyoung Longest](https://www.youtube.com/user/SeonkyoungLongest)
* [You Suck At Cooking](https://youtube.com/c/yousuckatcooking)
* [NinosHome](https://www.youtube.com/c/NinosHome/)
* [Aragusea](https://youtube.com/user/aragusea) 
* [Jocondesbaking](https://m.youtube.com/c/%EC%A1%B0%EA%BD%81%EB%93%9CJocondesbaking) 
* [Ruby Ka Kitchen](https://www.youtube.com/channel/UCMhx-uS3O-G_6_lTrYmDKLw)

***

#### Copy Google Drives

[gdrive-copy](https://github.com/ericyd/gdrive-copy), [googledrive-copy-downloader](https://github.com/jonathanTIE/googledrive-copy-downloader), [TgFolderClone](https://github.com/Loli-Killer/TgFolderClone), [Telegram-CloneBot](https://github.com/jagrit007/Telegram-CloneBot), [Copy Folder](https://chrome.google.com/webstore/detail/copy-folder/kfbicpdhiofpicipfggljdhjokjblnhl), [GDrive-Clone](https://github.com/alx-xlx/gdrive-clone), [Telegram Bots](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/storage#wiki_telegram_file_tools)

***

#### Conversational Chatbots

[Replika](https://replika.ai/), [Mitsuku](https://www.pandorabots.com/mitsuku/), [cleverbot](https://www.cleverbot.com/), [eviebot](https://www.eviebot.com/en/), [Kajiwoto](https://kajiwoto.com/) (ai builder), [Talk-Bot](http://www.frontiernet.net/~wcowart/index.shtml), [Madam Zena](http://www.madamzena.com/)

***

#### Command Line Shells

* zsh - https://www.zsh.org/
* zsh Tools - [Auto Suggest](https://github.com/zsh-users/zsh-autosuggestions) / [Customization](https://ohmyz.sh/) / [Theme](https://github.com/romkatv/powerlevel10k) / [Auto Setup](https://github.com/gustavohellwig/gh-zsh) / [Rich Framework](https://github.com/sorin-ionescu/prezto)
* Fish - https://fishshell.com/
* bash - https://www.gnu.org/software/bash/ (Preinstalled on most distros)
* elvish - https://elv.sh/
* es - https://wryun.github.io/es-shell/
* ion - https://github.com/redox-os/ion
* yash - https://yash.osdn.jp/
* xonsh - https://xon.sh/
* nushell - https://github.com/nushell/nushell 

***

#### Compression Programs

**[Conversion Tutorial Index](https://fileforums.com/showthread.php?t=96782)**, **[7-zip](https://www.7-zip.org/)** / [Fork](https://github.com/M2Team/NanaZip) / [Colab](https://github.com/dropcreations/7zip-in-Google-Colab) / [Dark](https://github.com/huanrenfeng/7zipDarkmode) / [Benchmarks](https://s1.hoffart.de/7zip-bench/), [win-rar](https://www.win-rar.com/) / [Licenses](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/base64#wiki_winrar_licenses) / [Remove Popup](http://cooltricksb.blogspot.com/2015/03/how-to-remove-40-days-trial-period.html?m=1), [SuperCompression](https://supercompression.ru/), [peazip](https://peazip.github.io/), [hamstersoft](https://hamstersoft.com/), [Unzip Online](https://unzip-online.com/en), [kgbarchiver](https://github.com/RandallFlagg/kgbarchiver), [Pigz](https://zlib.net/pigz/), [GNU Gzip](http://www.gnu.org/software/gzip/), [ezyZip](https://www.ezyzip.com/), [FreeARC](https://sourceforge.net/projects/freearc/) / [FreeARC 0.666](https://www68.zippyshare.com/v/qZUpSdVT/file.html), [UltraARC](https://www.fileforums.com/showpost.php?p=476660&postcount=1135), [p7zip](https://github.com/jinfeihan57/p7zip), [Razorx](https://fileforums.com/showthread.php?t=103577&highlight=Razorx), [DZip](http://speeddemosarchive.com/dzip/), [FileOptimizer](https://nikkhokkho.sourceforge.io/static.php?page=FileOptimizer), [bzip2](http://sourceware.org/bzip2/), [bandizip](http://www.bandisoft.com/bandizip/), [tugzip](http://www.tugzip.com/), [objectfixzip](https://www.essentialdatatools.com/products/objectfixzip/) (repair zip), [Benchmark](https://github.com/powturbo/TurboBench), [7-Zip-zstd](https://github.com/mcmilk/7-Zip-zstd), [Unrar.online](https://unrar.online/), [izarc](https://www.izarc.org/), [zipextractor](https://zipextractor.app/), [zipware](https://www.zipware.org/), [winzip](https://www.winzip.com/)

***

#### Covers / Posters

[The Poster Database](https://theposterdb.com/), [covercentury](https://www.covercentury.com/), [covrik](http://www.covrik.com/), [dvd-covers](https://www.dvd-covers.org/), [cover-addict](https://www.cover-addict.com/), [Gaming Alexandria](https://www.gamingalexandria.com/), [BoxEqualArt](http://boxequalsart.com/), [poster-man](http://www.poster-man.com/), [dlhcollections](https://www.dlhcollections.com/index.html), [postercollector](https://postercollector.co.uk/), [moviepostersgallery](https://www.moviepostersgallery.com/), [filmonpaper](https://www.filmonpaper.com/blog/), [gametdb](https://www.gametdb.com/), [Joblo](https://www.joblo.com/movie-posters/), [MoviePosterPorn](https://www.reddit.com/r/MoviePosterPorn/), [andydecarli](http://andydecarli.com/Video%20Games/Collection/), [impawards](http://www.impawards.com/), [moviemania](https://www.moviemania.io/), [Bendodson](https://bendodson.com/projects/itunes-artwork-finder/) / [2](https://bendodson.com/projects/apple-tv-movies-artwork-finder/), [FanArt](https://fanart.tv/)

**Album Art** 

**[MH Covers](https://covers.musichoarders.xyz), [AMOGUS](https://github.com/R3AP3/amogus)**, [iTunes Artwork Grabber](https://artwork.themoshcrypt.net/), [Album Art Downloader](https://sourceforge.net/projects/album-art/), [kunst](https://github.com/sdushantha/kunst) 

***

#### Customizable New Tab Page

[StartPage](https://github.com/deepjyoti30/startpage), [NightTab](https://github.com/zombieFox/nightTab), [hexagonTab](https://github.com/zombieFox/hexagonTab), [CaretTab](https://www.carettab.com/), [mesmerized](https://mesmerized.me/), [Bonjourr](https://bonjourr.fr/), [Perfect Home](https://github.com/perfect-things/perfect-home), [yet another speed dial](https://github.com/conceptualspace/yet-another-speed-dial), [Tabliss](https://tabliss.io/), [Epiboard](https://github.com/Alexays/Epiboard), [Infinity New Tab](https://en.infinitynewtab.com/), [b2ntp](https://d3ward.github.io/b2ntp/) 

[Custom Start Page](https://github.com/midnitefox/Nord-Theme-Ports-and-Assets/tree/main/custom-start-page) - Terminal Style Start Page
[Tabiverse](https://tabiverse.com/) - Universe New Tab Page / [Discord](https://discord.gg/MUgRGwE
[Tabs with a View](https://www.withaview.co/ext/) - Virtual Sights New Tab Page
[Minecraft Weather New Tab](https://github.com/sawyerpollard/Minecraft-Weather-New-Tab) - Weather Based Minecraft New Tab Page

***

#### Custom Rich Discord Presence

[CustomRP](https://www.customrp.xyz/), [EasyRP](https://github.com/Pizzabelly/EasyRP), [RPCEngine](https://github.com/qoobes/rpcengine), [discord-custom-rich-presence](https://github.com/HyperBeasty/discord-custom-rich-presence), [CustomDiscordRPC](https://github.com/PryosCode/CustomDiscordRPC), [Discord-CustomRP](https://github.com/maximmax42/Discord-CustomRP), [Discord RPC Client](https://github.com/Metalloriff/discord-rpc-client), [Discord-Rich-Presence](https://github.com/BlobbyDev/Discord-Rich-Presence), [Discord RPC](https://github.com/discord/discord-rpc), [DiscordRPCMaker](https://drpcm.t1c.dev/)

***

#### Design Resources 

[design-resources-for-developers](https://github.com/bradtraversy/design-resources-for-developers), [Freebies.ByPeople](http://freebies.bypeople.com/), [ImCreator](http://www.imcreator.com/free), [DesignBundles](https://designbundles.net/free-design-resources), [DesignResources](https://designresourc.es/), [UIOnline](https://uionline.io/), [psddd](https://psddd.co/), [GraphicBurger](https://graphicburger.com/), [GraphicsFuel](https://www.graphicsfuel.com/), [Pixeden](https://www.pixeden.com/), [SketchRepo](https://sketchrepo.com/), [Interfaces](https://interfacer.xyz/), [Freebiesbug](http://freebiesbug.com/), [Sketch App Sources](https://www.sketchappsources.com/), [FreebiesUI](https://freebiesui.com/), [Envato Elements Collection](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/base64#wiki_envato_elements_collection), [CreativeFabrica](https://www.creativefabrica.com/freebies/), [Toools.design](https://www.toools.design/), [Evernote.Design](https://www.evernote.design/), [gfxtra31](https://www.gfxtra31.com/), [xsgames](https://xsgames.co/devassets/), [design.dev](https://design.dev/), [uistore](https://www.uistore.design/), [charco](https://www.charco.design/), [craftwork](https://craftwork.design/freebies/), [pixelbuddha](https://pixelbuddha.net/)

***

#### Developer Tools

**[FreeForDevs](https://drgraph.cf/freefordevs)**, [Development Resources](https://github.com/sunilkumarvalmiki/Anonymous-Developemnt-Resources), [free-for.dev](https://free-for.dev/), [DevToys](https://devtoys.app/) / [GitHub](https://github.com/veler/DevToys), [JetBrains](https://jetbrains.com/) / [Trial Script](https://gist.github.com/Gkhnzdmr/29fe3f1c4cf3d3984df4cf380e490074) / [License Server](https://github.com/crazy-max/docker-jetbrains-license-server), [SmallDev.tools](https://smalldev.tools/), [WebdevHome](https://webdevhome.github.io/), [Eclipse](https://www.eclipse.org/), [DevBox](https://intab.io/resources/), [Free Dev stuff](https://freestuff.dev/), [Tiny Tools](https://tinytools.directory/), [CleanCSS](https://www.cleancss.com/), [Dev Resources](https://www.devresourc.es/), [Developer-Tools-and-Resources](https://github.com/IliasHad/Developer-Tools-and-Resources), [FreeForMatter](https://freeformatter.com/), [utilities-online](https://utilities-online.info/), [online-toolz](https://online-toolz.com/), [string-functions](https://string-functions.com/), [onlinestringtools](https://onlinestringtools.com/), [convertstring](https://convertstring.com/), [CodersTool](https://www.coderstool.com/), [Free-for-students](https://shalvah.me/Free-for-students/) / [Github](https://github.com/shalvah/Free-for-students), [coderstoolbox](https://coderstoolbox.net/)

***

#### Discord Embed Generators

[Discohook](https://discohook.org/), [Rauf's Embed Generator](https://embed.rauf.wtf), [discord.club](https://discord.club/embedg/), [0x71](https://em.0x71.cc/), [Webhook Gold](https://webhook.discord.gold/), [PSDiscord](https://github.com/EvotecIT/PSDiscord), [Rauf's Embed Generator](https://test.rauf.workers.dev/) 

***

#### Discord Server / Bot Lists

[Disboard](https://disboard.org/), [DiscordLabs](https://www.discordlabs.org/), [RovelStars](https://discord.rovelstars.com/), [DiscordServers](https://discordservers.com/), [Discord Street](https://discord.st/), [discordlist.io](https://discordlist.io/), [DiscordServers.me](https://discordservers.me/), [Discords](https://discords.com/), [Discord Me](https://discord.me/), [Disforge](https://disforge.com/), [FindADiscord](https://findadiscord.com/)

**Bots** 

[BotBlock](https://botblock.org/), [Top.gg](https://top.gg/), [Bots on Discord](https://bots.ondiscord.xyz/), [Discord Bots Labs](https://bots.discordlabs.org/), [Discord Bots](https://discord.bots.gg/), [Top Bots](https://s.advaith.io/topbots), [motiondevelopment](https://www.motiondevelopment.top/), [infinitybotlist](https://infinitybotlist.com/), [fateslist](https://fateslist.xyz/), [discordservices](https://discordservices.net/), [discordlist](https://discordlist.space/), [discordbots](https://discordbots.co/), [discordbots](https://discordbots.app/), [discordbotlist](https://discordbotlist.com/), [discord.boats](https://discord.boats/), [discord-botlist](https://discord-botlist.eu/), [carbonitex](https://www.carbonitex.net/), [botlist](https://botlist.me/), [blist](https://blist.xyz/), [bladelist](https://bladelist.gg/), [topcord](https://topcord.xyz/), [yabl](https://yabl.xyz/), [wonderbotlist](https://wonderbotlist.com/), [voidbots](https://voidbots.net/), [void.yt](https://void.yt/)

***

#### Disk Usage Analyzers

[WizTree](https://wiztreefree.com/), [WinDirStat](https://windirstat.net/), [baobab](https://github.com/GNOME/baobab), [2](https://gitlab.gnome.org/GNOME/baobab), [HDSentinel](https://www.hdsentinel.com/), [Space Sniffer](http://www.uderzo.it/main_products/space_sniffer/), [CrystalDiskInfo](https://crystalmark.info/en/software/crystaldiskinfo/), [Macrorit Partition Expert](https://macrorit.com/partition-magic-manager/partition-expert-download.html), [Disk Space Saver](https://qiplex.com/software/disk-space-saver/), [gdu](https://github.com/dundee/gdu), [Dua CLI](https://github.com/Byron/dua-cli)

***

#### DNS Filters

[DNS for Family](https://dnsforfamily.com/), [CleanBrowsing](https://cleanbrowsing.org/filters/), [personalDNSfilter](https://zenz-solutions.de/personaldnsfilter/), [hBlock](https://github.com/hectorm/hblock), [someonewhocares](https://someonewhocares.org/hosts/), [winhelp2002](https://winhelp2002.mvps.org/hosts.htm), [Hosts](https://github.com/StevenBlack/hosts), [Spamhaus](https://www.spamhaus.org/), [1Hosts](https://o0.pages.dev/) / [GitHub](https://github.com/badmojr/1Hosts), [NXFilter](https://nxfilter.org/) 

***

#### DOS Games

[DOSGamesLibrary](https://www.dosgamesarchive.com/), [DOSBox](https://www.dosbox.com/), [DOS Haven](http://www.doshaven.eu/), [The Software Library](https://archive.org/details/softwarelibrary_msdos), [Best Old Games](http://www.bestoldgames.net/eng/), [DosGames](https://dosgames.com/), [PlayDOSGames](https://www.playdosgames.com/), [DOS Haven](http://www.doshaven.eu/), [ClassicDOSGames](https://www.classicdosgames.com/), [AbandonwareDOS](https://www.abandonwaredos.com/), [DOSGames](https://www.dosgames.com/), [zczc](https://dos.zczc.cz/) (Chinese)

***

#### Down Site Checkers

**[Down for Everyone or Just Me](https://downforeveryoneorjustme.com/)**, **[IsItDownRightNow](https://www.isitdownrightnow.com/)**, [IsThisServiceDown](https://istheservicedown.com/), [down.com](https://down.com/), [DownDetector](https://downdetector.com/), [websitedown](http://www.websitedown.info/), [isitup](https://isitup.org/)

***

#### Email Clients

[thunderbird](https://www.thunderbird.net/en-US/), [BetterBird](https://www.betterbird.eu/), [ElectronMail](https://github.com/vladimiry/ElectronMail), [k9mail](https://k9mail.app/), [getmailspring](https://getmailspring.com/) / [Theme](https://github.com/topics/mailspring-theme), [bluemail](https://www.bluemail.me/), [claws-mail](https://www.claws-mail.org/), [emclient](https://www.emclient.com/), [rainloop](http://www.rainloop.net/), [roundcube](https://roundcube.net/), [spikenow](https://www.spikenow.com/), [canarymail](https://canarymail.io/), [twobird](https://www.twobird.com/), [kanmail](https://kanmail.io/), [Outlook](https://outlook.live.com/owa/) / [Tools](https://github.com/eksperience/KnockOutlook)

***

#### Email Forwarding

**[DDG Email Protection](https://duckduckgo.com/email/)**, [Forward Email](https://forwardemail.net/), [SimpleLogin](https://simplelogin.io/), [Firefox Relay](https://relay.firefox.com/), [spamgourmet](https://www.spamgourmet.com/index.pl), [Burner Mail](https://burnermail.io/), [scr.im](http://scr.im/), [Mailsac](https://mailsac.com/), [AnonAddy](https://anonaddy.com/), [AltMails](https://altmails.com/), [SpamCage](https://www.spamcage.com/), [YopMail](https://yopmail.com/en/)

**Telegram Bots**

[FakemailBot](https://t.me/FakemailBot), [DropmailBot](https://t.me/DropmailBot), [ccgen_robot](https://t.me/ccgen_robot) 

**Extensions**

[Mailvelope](https://mailvelope.com/)

***

####  Email Sites

[Dispostable](https://www.dispostable.com/), [GMX](https://gmx.com/), [German GMX](https://gmx.net/), [Mail.com](https://www.mail.com/), [1337.no](https://www.1337.no/)

***

#### Encode / Decode URLs

**[Universal Encoding Tool](https://unenc.com/)**, **[Txtmoji](https://txtmoji.com/)**, [Online Tools](https://emn178.github.io/online-tools/index.html), [Dencode](https://dencode.com/), [AES-256](https://secretmessages.online/) / [2](https://encipher.it/), [UTF8](https://onlineutf8tools.com/), [PubKey](https://pubkey.pm/), [Age Online](https://age-online.com/), [Universal Online Cyrillic Decoder](https://2cyr.com/decode/?lang=en), [Cryptii](https://cryptii.com/)

**Base 64**

**[Base64 Decode](https://www.base64decode.org/) / [Encode](https://www.base64encode.org/)**, [Base64 E/D](https://apps.maximelafarie.com/base64/), [Encode/Decode](https://toolbox.googleapps.com/apps/encode_decode/), [Base64.guru](https://base64.guru/), [Base64Decoder](https://base64decoder.io/), [URL Decode](https://url-decode.com/), [URL Encode/Decode](https://www.url-encode-decode.com/)

**Base64 Extensions**

[Chrome](https://chrome.google.com/webstore/detail/base64-encoderdecoder/afdannbjainhcddbjjlhamdgnojibeoi) / [2](https://chrome.google.com/webstore/detail/base64-decode-copy/llcfmnginbnmkeddkjjellcimmffjdcf), [Firefox](https://addons.mozilla.org/en-US/firefox/addon/base64-decoder/), [Opera](https://addons.opera.com/en/extensions/details/base64-encode-and-decode/)

***

#### Encrypted Android Messengers

[Threema](https://mirrorace.com/m/3DIja), [Status](https://status.im/), [Signal](https://github.com/mollyim/mollyim-android) / [2](https://langis.cloudfrancois.fr/) / [3](https://play.google.com/store/apps/details?id=org.thoughtcrime.securesms) / [4](https://getsession.org/) / [5](https://www.twinhelix.com/apps/signal-foss/), [Confide](https://play.google.com/store/apps/details?id=cm.confide.android), [Anonymous Messenger](https://f-droid.org/en/packages/com.dx.anonymousmessenger/), [ChatSecure](https://ballinger.io/apps/chatsecure/), [Snikket](https://www.f-droid.org/en/packages/org.snikket.android/), [RetroShare](https://f-droid.org/en/packages/org.retroshare.android.qml_app/), [BiP](https://bip.com/en/), [Olvid](https://olvid.io/en/), [Berty](https://berty.tech/), [OpenKeyChain](https://www.openkeychain.org/), [Dust](https://www.usedust.com/), [Fireside Messenger](https://newnode.com/), [Kontalk](https://www.kontalk.org/), [Wire](https://github.com/wireapp/wire-android)

*** 

#### Encrypted Email Services

**[ProtonMail](https://protonmail.com/)** / [Client](https://github.com/Steccas/ProtonClient) / [.onion](https://protonirockerxow.onion/), [Enigmail](https://www.enigmail.net/index.php/en/), [Private-Mail](https://privatemail.com/), [ShazzleMail](https://shazzlemail.com/), [Mailfence](https://mailfence.com/), [OnionMail](https://en.onionmail.info/), [secMail (tor)](http://secmailw453j7piv.onion/src/login.php), [TorBox (tor)](http://torbox3uiot6wchz.onion/), [sigaintevyh2rzvw](http://sigaintevyh2rzvw.onion/), [Tilda](https://www.tildamail.com/), [Disroot](https://disroot.org/en/services/email), [Tutanota](https://tutanota.com/), [GMX](https://www.gmx.com/), [NeoMailBox](https://www.neomailbox.com/), [CounterMail](https://countermail.com/), [mailpile](https://www.mailpile.is/), [MSGSafe](https://www.msgsafe.io/), [SecureNym](http://www.securenym.net), [TheHelm](https://thehelm.com/), [OnMail](https://www.onmail.com/), [mailpile](https://www.mailpile.is/), [Skiff](https://skiff.org/mail), [DNMX](https://dnmx.org/)

***

#### Encrypted Messengers

**[Signal](https://signal.org/)**, [RetroShare](https://retroshare.cc/), [Off-the-Record](https://otr.cypherpunks.ca/), [Session](https://getsession.org/), [Demonsaw](https://www.demonsaw.com/), [Bitmessage](https://wiki.bitmessage.org/Main_Page) / [Reference Client](https://github.com/Bitmessage/PyBitmessage), [Enigma](https://enigma-reloaded.github.io/enigma-reloaded), [Mirage](https://github.com/mirukana/mirage), [Keybase](https://keybase.io/) / [.onion](http://fncuwbiisyh6ak3i.onion/), [CWTCH](https://cwtch.im/), [Bip](https://bip.com/en/), [Simplex](https://simplex.chat/), [Emberclear](https://emberclear.io/), [Matrix](https://matrix.org/) / [Cinny](https://cinny.in/), [Commune](https://commune.chat/), [Mesh](https://mesh.im/), [Utopia](https://utopia-ecosystem.com/), [CoyIM](https://coy.im/), [Shad0w](https://www.shad0w.io/), [Speek](https://speek.network/) / [Github](https://github.com/speek-app/speek), [Anonymous Messenger](https://www.anonymousmessenger.ly/)

**Matrix Home Servers**

* [Conduit](https://gitlab.com/famedly/conduit)
* [Matrix Servers](https://joinmatrix.org/servers/)
* [publiclist.anchel](https://archive.md/4xZE4) 
* [Tatsumoto Ren](https://tatsumoto-ren.github.io/blog/list-of-matrix-servers.html)
* [Public Servers](https://wiki.asra.gr/en:public_servers) 
* [List of Matrix Servers](https://tatsumoto.neocities.org/blog/list-of-matrix-servers.html)

***

#### Encrypted XMPP Servers

[Server List](https://xmpp.net/directory.php) / [2](https://xmpp-servers.404.city/), [Creep](https://creep.im/), [Hot Chilli](https://www.hot-chilli.eu/jabber/), [XMPP.jp](https://xmpp.jp/) / [xmpp.is](https://xmpp.is/), [webchat.disroot](https://webchat.disroot.org/), [snopyta](https://snopyta.org/service/xmpp/), [dismail](https://dismail.de/), [blah](https://blah.im/), [xabber](https://www.xabber.com/), [Gajim](https://gajim.org/), [404.city](http://404.city/)

***

#### External Subs Player

**[Penguin](https://github.com/carsonip/Penguin-Subtitle-Player)**, [Subtitle-Buddy](https://github.com/vincemann/Subtitle-Buddy), [Greenfish](https://www.softpedia.com/get/Multimedia/Video/Other-VIDEO-Tools/Greenfish-Subtitle-Player.shtml), [SRTViewer](https://sourceforge.net/projects/srtviewer/), [SubtitlePlayer](https://sourceforge.net/projects/subtitleplayer/), [JustSubsPlayer](https://archive.codeplex.com/?p=justsubsplayer), [FreeSubtitlePlayer](https://sourceforge.net/projects/freesubtitleplayer/) 

***

#### Flash Player Tools

* [How to Download & Play Flash Games](https://i.imgur.com/T6huIGF.png), [2](https://www.wikihow.com/Download-a-Flash-Game)
* [Ruffle](https://ruffle.rs/) or [AwayFL](https://github.com/awayfl) - Flash Emulator 
* [swf2js](https://swf2js.com/en/) - JavaScript Flash Player Emulator
* [Flash Browser](https://flash.pm/) / [Git](https://github.com/radubirsan/FlashBrowser) / [Discord](https://discord.com/invite/aeaq4Vbqr6) or [Basilisk](https://archive.org/details/basilisk-portable-with-flash) - Flash Player Browser
* [SuperNova](https://www.getsupernova.com/) or [VidKidz](https://vidkidz.github.io/) - Browser Flash Player
* [Lightspark](https://lightspark.github.io/) - Open-Source Flash Player
* [CleanFlash](https://gitlab.com/cleanflash/installer) - Open-Source Flash Player / [Archive](https://web.archive.org/web/20210923173709/https://github.com/CleanFlash/installer/releases/tag/v1.5)
* [FlashPatch](https://github.com/darktohka/FlashPatch) - Adobe Flash Fix
* [Animate Archive](https://animatearchive.neocities.org/), [Flash Player 32](https://archive.org/details/flashplayer_old), [Clean Flash Builds](https://github.com/darktohka/clean-flash-builds) or [FlashPlayerArchive](https://archive.org/details/flashplayerarchive) - Flash Player Archive
* [JPEXS Decompiler](https://github.com/jindrapetrik/jpexs-decompiler) - Flash Decompiler
* [swf2exe](https://sourceforge.net/projects/swf2exe/) - SWF to EXE Converter
* [swf-to-exe](http://swf-to-exe.com/) - SWF to EXE Online Converter

***

#### F2P Games 

**[FreeToGame](https://www.freetogame.com/games)**, [Free Game Sites](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/misc#wiki_.25BA_free_stuff), [Acid Play](https://acid-play.com/), [/v/'s recommended games wiki](https://vsrecommendedgames.fandom.com/wiki/Freeware_Games)

***

#### Fun Indexes

[Neal.fun](https://neal.fun/), [AIDN](https://aidn.jp/), [Neave](https://codepen.io/neave) / [2](https://neave.com/), [BoredHumans](http://boredhumans.com/), [puissant](https://sandwichpuissant.net/), [ThisIsMyWebsiteNow](http://www.thisismywebsitenow.com/), [Mr.doob](https://mrdoob.com/), [Bimble Space](https://in.bimble.space/toys), [Creative Tech Guy](https://creativetechguy.com/), [Just For Fun](https://justforfun.io/), [Andrew Marsh](http://andrewmarsh.com/software), [JenniferDewalt](https://jenniferdewalt.com/), [Chrome Experiments](https://www.chromeexperiments.com/), [0x2a](https://0x2a.re/), [yezi](https://yezi.itch.io/), [topster](https://topster.net/)

***

#### Free DNS Servers

* https://www.wikileaks.org/wiki/Alternative_DNS
* https://www.cloudns.net/
* https://dns.he.net/
* https://www.dnspod.com/
* https://www.luadns.com/
* https://dynu.com/
* https://www.1984.is/product/freedns/
* https://www.namecheap.com/domains/freedns/
* https://zilore.com/en/dns
* https://docs.glauca.digital/hexdns/
* https://www.zoneedit.com/free-dns/
* https://www.dnsabr.com/
* https://dns.sb/
* https://github.com/dns-sb/dns.sb
* http://bestdns.org/
* https://public-dns.info/

***

#### Free VPN Configs

* https://courvix.com/ / [Discord](https://discord.gg/ZP47YRdn83)
* https://www.racevpn.com/
* https://www.greenssh.com/
* https://cyberssh.com/vpn/config
* https://www.sshmonth.com/
* https://www.vpnjantit.com/
* https://pisovpn.com
* https://www.lionssh.com/
* https://www.sshocean.com/
* https://www.vpnhack.com/ 
* https://www.monthlyssh.com/ 
* https://www.dynamicssh.com/ 
* https://www.freevpn.us/ 
* https://www.sshocean.net/ 
* https://www.cloudssh.us/ 
* https://www.fullssh.com/ 
* https://starssh.com/ 
* https://www.skyssh.co/ 
* https://unlissh.com/
* https://www.sshinjector.net/ 
* https://www.sshdropbear.net/ 
* https://www.portssh.com/ 
* https://www.jetssh.com/ 
* https://www.goodssh.com/ 
* https://www.ssh-free.com/ 
* https://cloudssh.net/ 
* https://www.contassh.com/ 
* https://sshkit.com/
* https://www.flyssh.com/
* https://www.sshssl.com/
* https://www.jagoanssh.com/
* https://spotssh.com/
* http://criarssh.com/
* https://dewassh.net/
* https://ciscossh.com/
* https://digitalssh.net/
* https://sshaccess.com/
* https://interssh.com/
* https://www.speedssh.com/
* http://www.sshudp.com/
* https://www.fastssh.com/
* https://createssh.com/
* https://freesslvpn.us/
* https://sharevpn.org/
* https://www.mytunneling.com/
* https://www.squid-proxy.net/
* https://www.jrtunnel.com/
* https://opentunnel.net/
* https://howdy.id/
* https://openinternetaccess.com/

***

#### Free Webhosting Sites

**[netlify](https://www.netlify.com/)**,  **[heroku](https://www.heroku.com/)**, [profreehost](https://profreehost.com/), [000webhost](https://www.000webhost.com/), [infinityfree](https://infinityfree.net/), [openshift](https://www.openshift.com/), [vercel](https://vercel.com/) /  [2](https://vercel.app/), [GitHub Pages](https://pages.github.com/), [surge](https://surge.sh/), [firebase](https://firebase.google.com/products/hosting), [openode](https://github.com/openode-io), [workers.dev](https://workers.cloudflare.com/), [cloudaccess](https://www.cloudaccess.net/), [Gitlab Pages](https://docs.gitlab.com/ee/user/project/pages/index.html), [glitch](https://glitch.com/), [biz.nf](https://www.biz.nf/), [coolify](https://coolify.io/), [wix](https://www.wix.com/), [byet.host](https://byet.host/free-hosting), [webs](https://www.webs.com/), [weebly](https://www.weebly.com/in), [yola](https://www.yola.com/), [wordpress](https://wordpress.com/) / [2](https://wordpress.org/), [fosshost](https://fosshost.org/), [jimdo](https://www.jimdo.com/), [awardspace](https://www.awardspace.com/), [pythonanywhere](https://www.pythonanywhere.com/), [droppages](https://droppages.com/), [Zeronet](https://cheapskatesguide.org/articles/zeronet-site.html), [Zeronet 2](https://zeronet.io/docs/site_development/getting_started/), [ibm cloud](https://www.ibm.com/cloud/free), [hubzilla](https://zotlabs.org/page/zotlabs/home), [site123](https://www.site123.com/), [hostbreak](https://hostbreak.com/web-hosting/free), [moodlecloud](https://moodlecloud.com/), [tilda](https://tilda.cc/), [paiza.cloud](https://paiza.cloud/), [boomla](https://boomla.com/), [BitBucket](https://support.atlassian.com/bitbucket-cloud/docs/publishing-a-website-on-bitbucket-cloud/), [repl.it](https://docs.repl.it/repls/web-hosting), [render](https://render.com/), [Fleek](https://fleek.co/), [stormkit](https://www.stormkit.io/), [hostman](https://hostman.com/), [freehosting](https://freehosting.host/), [gearhost](https://www.gearhost.com/), [freewebhostingarea](https://www.freewebhostingarea.com/), [freenom](http://freenom.com/) / [Script](https://github.com/mkorthof/freenom-script), [milkshake](https://milkshake.app/), [ikoula](https://www.ikoula.com/), [fanspace](http://www.fanspace.com/), [dotera](https://dotera.net/), [fc2](https://web.fc2.com/en/), [pages.cloudflare](https://pages.cloudflare.com/), [w3schools](https://www.w3schools.com/spaces/), [freehostia](https://www.freehostia.com/), [olitt](https://www.olitt.com/), [uhostfull](https://www.uhostfull.com/), [atspace](https://www.atspace.com/), [ophosting](https://ophosting.net/), [x10hosting](https://x10hosting.com/), [crystalcloud](https://crystalcloud.xyz/), [lenyxo](https://lenyxo.com/freehosting/), [yunohost](https://yunohost.org/), [1freehosting](https://www.1freehosting.net/), [5gb.club](http://www.5gb.club/free-hosting.php?i=1, [ultifreehosting](https://ultifreehosting.com/), [aeonfree](https://aeonfree.com/), [bravenet](https://www.bravenet.com/)

***

#### File Backup Tools

[Cloning Tools](https://github.com/SpamVerse/Piratezparty/blob/main/Cloning-Tools.md), [BackupPC](https://backuppc.github.io/backuppc/), [TeraCopy](https://www.codesector.com/teracopy), [Ashampoo Backup 202](https://www.ashampoo.com/en/usd/lpa/VNR-1759), [DeltaCopy](http://www.aboutmyip.com/AboutMyXApp/DeltaCopy.jsp), [restic](https://restic.net/) / [GitHub](https://github.com/restic/restic), [UrBackup](https://www.urbackup.org/), [BlobBackup](https://github.com/BlobBackup/BlobBackup), [Paragon](https://www.paragon-software.com/free/br-free/), [ZPaq](http://mattmahoney.net/dc/zpaq.html), [SafeCopy](https://www.elwinsoft.com/safecopy-free.html), [FastCopy](http://fastcopy.jp/), [OCCT](https://www.ocbase.com/), [Aomei](https://www.ubackup.com/), [Veeam](https://www.veeam.com/), [Duplicati](https://www.duplicati.com/), [Borg](https://www.borgbackup.org/), [USBImager](https://bztsrc.gitlab.io/usbimager/)

***

#### File Conversion Tools

**[CloudConvert](https://cloudconvert.com/)**, [File Converter](https://file-converter.org/), [Bear File Converter](https://www.ofoct.com/), [FreeConvert](https://www.freeconvert.com/), [Online Convert](https://www.online-convert.com/), [Convertio](https://convertio.co/), [Zamzar](https://www.zamzar.com/), [Online Converter](https://www.onlineconverter.com/), [Format Factory](http://www.pcfreetime.com/formatfactory/index.php?language=en), [File-Coversion](https://www.files-conversion.com/), [PPT Online](https://www.aspose.app/), [File-Conversion](https://www.files-conversion.com/), [AnyConvert](https://anyconv.com/), [Converter 365](https://www.converter365.com/), [MiConv](https://miconv.com/), [11zon](https://www.11zon.com/), [Webp2JPGjs](https://webp2jpgjs.com/), [Convert Town](https://convert.town/), [ACConvert](https://www.aconvert.com/), [ConvertFiles](https://www.convertfiles.com/), [.to Sites](https://rentry.co/nsq29), [Better Converter](https://better-converter.com/), [xConvert](https://www.xconvert.com/), [conversion-tool](https://www.conversion-tool.com/), [onlineconvertfree](https://onlineconvertfree.com/), [go4convert](https://go4convert.com/), [videoutils](https://www.videoutils.com/), [101convert](https://www.101convert.com/)

**Telegram Bots**

[convrt_bot](https://t.me/convrt_bot), [FileConvertBot](https://t.me/FileConvertBot), [newfileconverterbot](https://t.me/newfileconverterbot), [SmartConverter_bot](https://t.me/SmartConverter_bot), [cloud_convert_bot](https://t.me/cloud_convert_bot), [wololopdfbot](https://t.me/wololopdfbot), [pdfbot](https://t.me/pdfbot), [Gpdfbot](https://t.me/Gpdfbot)

***

#### File Download Managers

* **[JDownloader](https://jdownloader.org/jdownloader2)** / [Dark Theme](https://github.com/Vinylwalk3r/JDownloader-2-Dark-Theme/), [2](https://redd.it/q3xrgj), [3](https://draculatheme.com/jdownloader2) / [Debloat](https://rentry.org/jdownloader2), [2](https://rentry.org/jdownloader2opt) / [Captcha Solver](https://github.com/cracker0dks/CaptchaSolver)
* [Motrix](https://www.motrix.app/) / [Firefox](https://addons.mozilla.org/en-US/firefox/addon/motrixwebextension/) / [Chrome](https://github.com/gautamkrishnar/motrix-webextension/) / [GitHub](https://github.com/agalwood/Motrix)
* [IDM](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/base64#wiki_idm) / [IDMHelper](https://github.com/unamer/IDMHelper) / [Trial Reset](https://github.com/J2TEAM/idm-trial-reset) / [Fix](https://libredd.it/r/Piracy/comments/fe8l96/idm_trial_reset_not_working_anymore_what_now/fjmxjdk/)
* [XDM](https://github.com/subhra74/xdm), [2](https://subhra74.github.io/xdm/)
* [pyLoad](https://pyload.net/)
* [wfdownloader](https://www.wfdownloader.xyz/)
* [Mipony](https://www.mipony.net/)
* [SpeedBit](http://www.speedbit.com/) 
* [FlashGet](http://www.flashget.com/index_en.html)
* [FileCXX](https://filecxx.com/)
* [Tucan Manager](https://www.tucaneando.com/)
* [Ninja Download Manager](https://ninjadownloadmanager.com/)
* [Internet Download Accelerator](https://westbyte.com/ida/) 
* [Envy](https://sourceforge.net/projects/getenvy/) - [GitHub](https://github.com/getenvy/envy)
* [AWGG](https://sites.google.com/site/awggproject/) / [GitHub](https://github.com/Nenirey/AWGG)
* [Ant Download Manager](https://antdownloadmanager.com/)
* [Xtreme Downlaod Manager](https://xtremedownloadmanager.com/) 
* [Chrono Download Manager](https://www.chronodownloader.net/) 
* [GetGo Download Manager](http://www.getgosoft.com/) 
* [Download Accelerator Manager](http://www.damdownloader.com/) 
* [FlashGot](https://flashgot.net/)
* [massivedl](https://github.com/dimkouv/massivedl)
* [Neat Download Manager](https://www.neatdownloadmanager.com/)
* [Free Download Manager](https://www.freedownloadmanager.org/), [2](https://sourceforge.net/projects/freedownload/) / [Addon](https://github.com/meowcateatrat/elephant)
* [uGet](https://ugetdm.com/) / [Addon](https://github.com/ugetdm/uget-integrator)
* [Persepolis](https://persepolisdm.github.io/)
* [DownZemAll](https://setvisible.github.io/DownZemAll/)

***

#### File Recovery Tools

[ZAR Recovery](https://www.z-a-recovery.com/), [R-Undelete](https://www.r-undelete.com/Download.shtml), [PhotoRec](https://www.cgsecurity.org/wiki/PhotoRec), [StellarInfo](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/base64#wiki_stellarinfo), [Windows File Recovery](https://www.microsoft.com/en-us/p/windows-file-recovery/9n26s50ln705), [DMDE](https://dmde.com/download.html), [Recuva](https://www.ccleaner.com/recuva), [TestDisk](https://www.cgsecurity.org/wiki/TestDisk_Download)

***

#### File Sharing Tools

**Cloud Storage** 

**[GDrive](https://drive.google.com/)**, **[mega](https://mega.nz/)** / [GitHub](https://github.com/meganz), [dropbox](https://www.dropbox.com/) / [Client](https://github.com/SamSchott/maestral), [disk.yandex](https://disk.yandex.com/), [TeledriveApp](https://teledriveapp.com/), [mediafire](https://www.mediafire.com/), [unlimcloud](https://www.unlimcloud.cloud/), [terabox](https://terabox.com/), [icedrive](https://icedrive.net/), [trainbit](https://trainbit.com/), [degoo](https://degoo.com/), [alfafile](https://www.alfafile.net/), [aliyundrive](https://www.aliyundrive.com/), [backblaze](https://www.backblaze.com/), [perkeep](https://perkeep.org/), [filen](https://filen.io/), [internxt](https://internxt.com/), [MrOwl](https://www.mrowl.com/), [storj](https://www.storj.io/), [T-Drive](https://www.microsoft.com/en-in/p/t-drive/9mvd1pkdtxsn?rtc=1&activetab=pivot:overviewtab), [PCloud](https://www.pcloud.com/), [myDrive](https://mydrive-storage.com/), [KodCloud](https://kodcloud.com/), [UsersCloud](https://userscloud.com/), [File2Share](https://www.file2share.us/), [Infinity Upload](https://infinity-upload.com/), [Blackhole](https://blackhole.run/)

**Multi Host Uploaders**

**[Z-o-o-m](https://z-o-o-m.eu/)**, [MirrorAce](https://mirrorace.com/), [MultiUp](https://multiup.eu/) / [2](https://multiup.org/), [Mirrorcreator](https://www.mirrored.to/), [PlowShare](https://github.com/mcrapet/plowshare)

**File Hosts**

**[File Sharing Host List](https://dirtywarez.org/cat/filehost)**, **[anonfiles](https://anonfiles.com/)** / [donate](https://anonfiles.com/contribute), [mixdrop](https://mixdrop.co/), [bashupload](https://bashupload.com/), [sharedrop](https://www.sharedrop.io/), [xkcd949](http://xkcd949.com/), [wetransfer](https://wetransfer.com/), [justbeamit](https://justbeamit.com/), [krakenfiles](https://krakenfiles.com/), [lufi](https://upload.disroot.org/), [share.riseup](https://share.riseup.net/), [ufile](https://ufile.io/), [put.re](https://put.re/), [Station307](https://www.station307.com/), [envelop](https://envelop.app/), [swisstransfer](https://www.swisstransfer.com/en), [Bayfiles](https://bayfiles.com/), [FireLoad](https://www.fireload.com/), [cyberdrop](https://cyberdrop.me/), [Cum.zone](https://thecum.zone/), [tresorit](https://send.tresorit.com/) / [2](https://web.tresorit.com/), [pixeldrain](https://pixeldrain.com/), [SecureHa](https://securesha.re/), [dropmb](https://dropmb.com/), [zippyshare](https://www.zippyshare.com/), [catbox](https://catbox.moe/), [wormhole](https://wormhole.app/), [demo.lufi](https://demo.lufi.io/), [filewhopper](https://filewhopper.com/), [filedropper](https://www.filedropper.com/),  [clicknupload](https://clicknupload.co/), [tusfiles](https://tusfiles.com/), [gofile](https://gofile.io/), [takemetospace](https://take-me-to.space/), [safe.0x0](https://safe.0x0.la/), [iizu](https://iizu.dev/), [awoo](https://awoo.cafe/), [anonvodka](https://files.anonvodka.xyz/), [transferfile](https://www.transferfile.io/) [racaty](https://racaty.net/), [hexupload](https://www.hexupload.net/), [netnaijafiles](https://www.netnaijafiles.xyz/), [gachimuchi](https://manly.gachimuchi.men/), [myonri](https://i.myonri.me/), [msafe](https://msafe.i0.tf/), [btrfs](https://i.btrfs.no/), [fuckingweeb](https://fuckingweeb.site/), [safe.vikavo](https://safe.vikavo.lt/), [imouto](https://imouto.kawaii.su/), [edisk](https://www.edisk.cz/), [ttm](https://ttm.sh/), [youdbox](https://youdbox.com/), [send-anywhere](https://send-anywhere.com/), [1fichier](https://1fichier.com/), [9xupload](https://9xupload.asia/), [indishare](https://www.indishare.org/), [desiupload](https://dl1.desiupload.to/), [uploadflix](https://uploadflix.org/), [filestore](http://filestore.to/), [uploadraja](http://uploadraja.com/), [doodrive](https://doodrive.com/), [download.gg](https://download.gg/), [megaup](https://megaup.net/), [upload.ee](https://www.upload.ee/), [dropapk](https://dropapk.to/), [tusfiles](https://tusfiles.com/), [upload.vaa.red](https://upload.vaa.red/), [teknik](https://upload.teknik.io/), [starfiles](https://starfiles.co/), [opacity](https://www.opacity.io/), [send](https://gitlab.com/timvisee/send) / [instances](https://gitlab.com/timvisee/send-instances), [Gokapi](https://github.com/Forceu/Gokapi), [zofile](https://www.zofile.com/), [skytransfer](https://skytransfer.hns.siasky.net/), [vault.ooo](https://vault.ooo/), [blackhost](https://blackhost.xyz/?id=fup), [pipe](https://miroware.io/pipe/), [ninjashare](https://ninjashare.to/), [transfer](https://transfer.sh/), [workupload](https://workupload.com/), [sendspace](https://www.sendspace.com/), [secufiles](https://secufiles.com/index), [uploadboy](http://uploadboy.com/), [toffeeshare](https://toffeeshare.com/), [decentrafile](https://decentrafile.com/), [file.io](https://www.file.io/), [thgss](http://thgss.com/), [onuploads](http://www.onuploads.com/), [moepantsu](https://www.moepantsu.com/), [pomf](https://pomf.lain.la/), [cockfile](https://cockfile.com/), [uguu](https://uguu.se/), [uguu](https://uguu.se/), [qu.ax](https://qu.ax/), [fileditch](https://fileditch.com/), [volkor](https://volkor.me/), [easyupload](https://www.easyupload.io/), [cloudghost](https://www.cloudghost.net/), [filebin](https://filebin.net/), [tiny-files](https://tiny-files.com/), [up-4ever](https://www.up-4ever.org/), [easyupload](https://easyupload.io/), [fromsmash](https://fromsmash.com/), [androiddownload](https://www.androiddownload.net/), [prefiles](https://www.prefiles.com/), [fileblade](https://www.fileblade.com/), [usersdownload](https://www.usersdownload.com/), [fshare](https://www.fshare.vn/), [sharry](https://eikek.github.io/sharry/), [bunkr](https://bunkr.is/), [anoxinon](https://share.anoxinon.de/), [filefactory](https://www.filefactory.com/), [rapidshare](https://rapidshare.io/), [jptorrent](https://www.jptorrent.org/), [batshare](http://batshare.net/), [95.215.205.103](http://95.215.205.103/), [meerodrop](https://www.meerodrop.com/), [filehosting](https://www.filehosting.org/), [depositFiles](https://depositfiles.com/), [FastShare](https://fastshare.cz/), [sendbig](https://www.sendbig.com/), [filemail](https://www.filemail.com/), [sharefast](https://sharefast.me/), [fileconvoy](https://www.fileconvoy.com/), [shareupld](https://shareupld.com/), [anarkrypto](https://anarkrypto.github.io/upload-files-to-ipfs-from-browser-panel/public/), [My-Files](https://my-files.su/), [filesharego](https://www.filesharego.com/), [filedit](https://filedit.ch/), [fileditch](https://fileditch.com/), [fileaxa](https://fileaxa.com/?op=upload_form), [bowfile](https://bowfile.com/), [evoload](https://evoload.io/), [manyuploading](https://manyuploading.com/), [fex](https://fex.net/), [oshi](https://oshi.at/), [chomikuj](https://chomikuj.pl/), [sharemods](https://sharemods.com/), [2shared](https://2shared.com/), [sabercathost](https://sabercathost.com/), [dropsend](https://dropsend.com/), [filetransfer](https://filetransfer.io/), [sendfile.su](http://sendfile.su/), [dropmefiles](http://dropmefiles.com/), [lagout](https://file.lagout.org/, [file-upload](https://www.file-upload.net/en/), [file.coffee](https://file.coffee/), [Midi](https://midi.moe/), [expirebox](http://expirebox.com/), [fastupload](https://fastupload.io/en), [hitfile](https://hitfile.net/), [file-post](https://file-post.net/)

**File Sync / Network Share**

[dropbox](https://www.dropbox.com/) / [Client](https://github.com/SamSchott/maestral), [keybase](https://book.keybase.io/docs/files), [file.pizza](https://file.pizza/), [syncthing](https://syncthing.net/), [onionshare](https://onionshare.org/), [OwnCloud](https://owncloud.com/), [MLDonkey](https://github.com/ygrek/mldonkey), [Slate](https://slate.host/), [etesync](https://www.etesync.com/), [WinSCP](https://winscp.net/eng/index.php), [freefilesync](https://freefilesync.org/), [allwaysync](https://allwaysync.com/), [sharik](https://github.com/marchellodev/sharik), [Simple.Savr](https://www.ssavr.com/), [FileBrowser](https://filebrowser.org/), [Snapdrop](https://snapdrop.net/), [KDEConnect](https://kdeconnect.kde.org/), [Resilio](https://www.resilio.com/individuals/), [croc](https://f-droid.org/packages/com.github.howeyc.crocgui), [Ziggs](https://ziggs.io/), [dsynchronize](http://www.dimio.altervista.org/eng/dsynchronize/dsynchronize.html), [landrop](https://landrop.app/), [uploadtransfer](https://uploadtransfer.com/), [Surge](https://getsurge.io/), [odin](https://github.com/odinapp/odin), [brig](https://github.com/sahib/brig), [saladroom](https://saladroom.net/), [passfile](https://passfile.me/), [blymp.io](https://blymp.io/) / [GitHub](https://github.com/vantezzen/blymp-io), [drop.lol](https://drop.lol/) / [GitHub](https://github.com/mat-sz/filedrop-web), [sendfiles](https://sendfiles.online/), [Blaze](https://blaze.vercel.app/) / [GitHub](https://github.com/blenderskool/blaze), [XD-Torrent](https://xd-torrent.github.io/), [lightning](https://lightning-share.vercel.app/), [croc](https://github.com/schollz/croc), [Simple-Storage](https://github.com/ducheng0/Simple-Storage), [RDrop](https://rdrop.link/), [webdrop](https://webdrop.space/), [MyAirBridge](https://www.myairbridge.com/), [Sprend](https://sprend.com/), [JumboMail](https://www.jumbomail.me/), [PlusTransfer](https://www.plustransfer.com/), [SmartFTP](https://www.smartftp.com/), [Wing FTP](https://www.wftpserver.com/), [Xlight](https://xlightftpd.com/), [uschovna](https://www.uschovna.cz/), [posilej](https://posilej.cz/), [filetransfer](https://filetransfer.kpn.com/)

**Android File Sync**

[croc](https://f-droid.org/packages/com.github.howeyc.crocgui), [Snapdrop Android](https://github.com/fm-sys/snapdrop-android), [Clipt](https://play.google.com/store/apps/details?id=studio.onelab.clipboard), [MyPhoneExplorer](https://www.fjsoft.at/), [Leaf Explorer](https://github.com/Shiv-Shambhu/Leaf-Explorer), [xShare](https://github.com/tsudoko/xshare), [SyncThing](https://github.com/Catfriend1/syncthing-android)

**SkyNet**

[Skynet](https://skydrain.net/), [2](https://siasky.net/)

*** 

#### FMovies Clones

* [FlixHQ](https://flixhq.net/), [2](https://flixhq.ru/)
* [FBox](https://www1.fbox.to/), [2](https://www3.fbox.to/), [3](https://www4.fbox.to/)
* [HuruWatch](https://hurawatch.com/), [2](https://hurawatch.ru/), [3](https://hurawatch.at/)
* [Movies7](https://movies7.to/), [2](https://www2.movies7.to/), [3](https://movies7.io/)
* [Flixtor](https://flixtor.one/)
* [BFlix](https://bflix.ru/), [2](https://bflix.io/), [3](https://bflix.gg/)
* [SWatchseries.ru](https://www2.swatchseries.ru/)
* [watchmovieshd](https://watchmovieshd.ru/)
* [HDToday](https://hdtoday.ru/)
* [tvshows88](https://tvshows88.com/)
* [yesmovies.bar](https://yesmovies.bar/), [2](https://yesmovies.at)

***

#### Forest 

[Firefox](https://addons.mozilla.org/en-US/firefox/addon/forest-stay-focused-be-present/) / [Chrome](https://chrome.google.com/webstore/detail/forest-stay-focused-be-pr/kjacjjdnoddnpbbcjilcajfhhbdhkpgk)

***

#### Game Download CSE

* **[Game Download CSE](https://cse.google.com/cse?cx=006516753008110874046:cbjowp5sdqg)**
* [Rave Search](https://idleendeavor.github.io/gamesearch/) / [2](https://ravegamesearch.pages.dev/)
* [Rezi Search](https://rezi.one/)
* [Bonneteer](https://bonneteer.herokuapp.com/)
* [/r/PiratedGames CSE](https://cse.google.com/cse?cx=20c2a3e5f702049aa)

***

#### Gameboy Roms

* [Gameboy Drives](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/base64#wiki_gameboy_roms)
* [merwanachibet](http://merwanachibet.net/gameboy-roms.html)
* [Unreleased Gameboy Games](https://ufile.io/70vmpyng)

***

#### Game Engines

**[Game Engine Collection](https://github.com/collections/game-engines)**, [Godot](https://godotengine.org/), [Defold](https://defold.com/), [Cave Engine](https://unidaystudio.itch.io/cave-engine), [Engine Bevy](https://bevyengine.org/), [OpenXRay](https://github.com/OpenXRay), [ursina engine](https://www.ursinaengine.org/), [cryengine](https://www.cryengine.com/), [stride3d](https://www.stride3d.net/) / [GitHub](https://github.com/stride3d/stride), [armory3d](https://armory3d.org/) / [GitHub](https://github.com/armory3d/armory), [torque3d](https://torque3d.org/) / [GitHub](https://github.com/TorqueGameEngines/Torque3D), [Torque2D](https://github.com/TorqueGameEngines/Torque2D), [cocos](https://www.cocos.com/en/) / [GitHub](https://github.com/cocos2d/cocos2d-x), [starling](https://gamua.com/starling/) / [GitHub](https://github.com/Gamua/Starling-Framework), [AtomicGameEngine ](https://github.com/AtomicGameEngine/AtomicGameEngine)

***

#### Game Libraries / Launcher

**[Playnite](https://playnite.link/)** / [Extensions](https://github.com/darklinkpower/PlayniteExtensionsCollection), **[GoG Galaxy](https://www.gog.com/galaxy)**, [Launchbox](https://www.launchbox-app.com/), [GameHub](https://tkashkin.tk/projects/gamehub/) / [GitHub](https://github.com/tkashkin/GameHub), [Arc](https://www.arcgames.com/en/about/client), [Gnome Games](https://wiki.gnome.org/Apps/Games)

***

#### Game Mods

**[ModDB](https://moddb.com/)**, [Nexus Mods](https://www.nexusmods.com/) / [Redirect Skip](https://greasyfork.org/en/scripts/394039), [ZagruzkaMods](https://zagruzkamods.com/), [NextGenUpdate](https://www.nextgenupdate.com/), [ModWorkshop](https://modworkshop.net/), [Video Game Mods](https://videogamemods.com/), [Silent's Blog](https://cookieplmonster.github.io/mods/index/), [WabbaJack](https://www.wabbajack.org/) / [Discord](https://discord.com/invite/wabbajack), [GameFront](https://gamefront.com/), [GameJunkie](https://www.gamejunkie.pro/), [VIP Mods](https://www.vip-mods.com/), [top-mods.ru](https://top-mods.ru/), [vip-mods.ru](https://vip-mods.ru/), [Top Mods](https://www.top-mods.com/), [CurseForge](https://www.curseforge.com/), [Mods Gamer](https://www.mods-gamer.ru/), [GameJunkie](https://www.gamejunkie.ru/)

***

#### German Telegram Movie Downloads

[Deutsche Filme](https://t.me/deutsche_filme_german_movies), [GERMAN MOVIES](https://t.me/german_movie_channel)

***

#### Git Projects

* [/r/coolgitlabprojects](https://reddit.com/r/coolgitlabprojects) - GitLab Project Indexes
* [git:logs](https://www.gitlogs.com/), [Awesome Made by Russians](https://github.com/igoradamenko/awesome-made-by-russians), [Awesome Made by Brazilians](https://github.com/felipefialho/awesome-made-by-brazilians), [awesome-opensource-apps](https://github.com/unicodeveloper/awesome-opensource-apps), [opensauced](https://hot.opensauced.pizza/), [Awesome Stars](https://githubmemory.com/repo/abhijithvijayan/awesome-stars), [LibHunt](https://www.libhunt.com/), [RepoHunt](https://repo-hunt.signalnerve.workers.dev/), [/r/coolgithubprojects](https://reddit.com/r/coolgithubprojects) - Github Project Indexes
* [Active Github Forks](https://techgaun.github.io/active-forks/) - List of active github forks
* [Lovely Forks](https://github.com/musically-ut/lovely-forks) - View a Repositories Forks 
* [Git Search Engine](https://zzollo.co/) - Search GitHub, GitLab etc.
* [OSAlternative](http://www.osalternative.com/) - Git Project Search

***

#### Google Drive Search

[Movies](https://databasegdriveplayer.co/movie.php), [TV](https://databasegdriveplayer.co/series.php), [Anime](https://databasegdriveplayer.co/anime.php), [KDrama](https://databasegdriveplayer.co/drama.php)

***

#### Google Piracy Discussion Groups

* https://techy-transistor.notion.site/Team-drives-ab7ebffc1e5040b5b5362e9d70fca4d5
* https://groups.google.com/g/hkteamdrive1group
* https://groups.google.com/g/torrent-drive
* https://groups.google.com/forum/#!forum/sammytorrents
* https://groups.google.com/forum/embed/?place=forum/seedboxsl
* https://groups.google.com/g/team-drive99
* https://groups.google.com/g/roshanstgbot
* https://groups.google.com/g/zanime
* https://groups.google.com/g/rdrivelinks

***

#### GoldMovies Clones

* [series9.fun](https://series9.fun/)
* [CMovies](https://cmovies.ac/)

***

#### Grammar Check

**[Scribens](https://www.scribens.com/)**, [Wordtune](https://www.wordtune.com/), [HemingwayApp](http://hemingwayapp.com/), [Grammark](https://grammark.org/), [SlickWrite](https://www.slickwrite.com/), [Ginger Software](https://www.gingersoftware.com/grammarcheck), [LanguageTool](https://languagetool.org/), [Grammarly](https://www.grammarly.com/), [Grammica](https://grammica.com/), [Ludwig](https://ludwig.guru/), [Scribbr](https://www.scribbr.com/), [Writer](https://writer.com/), [WordCounter](https://wordcounter.net/), [RewriteTools](https://www.rewritertools.com/), [TextGears](https://textgears.com/check-grammar-online), [PolishMyWriting](https://www.polishmywriting.com/) , [Reverso Spellcheck](https://www.reverso.net/spell-checker/english-spelling-grammar/), [spellcheckplus](https://spellcheckplus.com/), [GrammarCheck](https://www.grammarcheck.net/) 

***

#### Graphic Design Tools

**[Canva Pro](https://teletype.in/@blooem/canvapro)**, [Design Cap](https://www.designcap.com/), [Gravit Designer](https://www.designer.io/), [lunacy](https://icons8.com/lunacy), [Desygner](https://desygner.com/), [Canva](http://canva.com/), [Stencil](https://getstencil.com/), [Design Studio](https://designstudio.smallseotools.com/), [Snappa](https://snappa.com/), [FotoJet](https://www.fotojet.com/), [Emaze](https://www.emaze.com/), [ArtBoard](https://artboard.studio/), [Glitterly](https://glitterly.app/), [VistaCreate](https://create.vista.com/), [PosterMyWall](https://www.postermywall.com/), [Pixelied](https://pixelied.com/), [blush]( https://blush.design/)

***

#### Hide YouTube Shorts

**Extensions**

[shorts-deflector](https://addons.mozilla.org/en-US/firefox/addon/shorts-deflector/) or [youtube-shorts-block](https://addons.mozilla.org/en-US/firefox/addon/youtube-shorts-block/)

**Scripts**

[yt-anti-shorts](https://github.com/YukisCoffee/yt-anti-shorts) or [youtube-shorts](https://letsblock.it/filters/youtube-shorts)

***

#### HiMovies Clones

* https://www2.theshit.me/
* https://www2.6movies.net/
* https://www2.movieorca.com/
* https://xmovies8.fun/
* https://ww22.watchfilm.net/
* https://swatchseries.is/
* https://www1.movierot.com/
* https://www.actvid.com/
* https://hdtoday.tv/ 
* https://www.tikmovies.com/
* https://moviesjoy.plus/
* https://dopebox.to/
* https://fboxtv.com/
* https://movies2watch.cc/ 
* https://movies2watch.tv/
* https://watchseriestv.top/
* https://moviestowatch.tv/
* https://favhd.net/
* https://www3.hdseries.cc/ 
* https://fmoviesgo.to/
* https://hdtoday.cc/
* https://tinyzonetv.to/
* https://www4.musichq.net/
* https://aa01.to/
* https://www6.f2movies.to/
* https://putlockers.llc/
* https://2kmovie.cc/
* https://himovies.top/
* https://www.sflix.pro/
* https://sflix.to/
* https://cineb.net/
* https://www.divicast.com/
* https://kk01.net/
* https://www1.moviecrumbs.net/
* https://flixtor.gg/
* https://theflixer.tv/
* https://myflixer.link/
* https://myflixer.to/
* https://myflixer.pw/
* https://myflixer.com/
* https://myflixertv.to/
* https://myflixer.it/
* https://ainiesta.com/
* https://iomovies.top/
* https://www3.f2movies.to/
* https://www1.bemovies.to/
* https://ev01.to/
* https://www3.watchserieshd.ru/
* https://flixhd.cc/
* https://www.iwatchfreestreams.to/
* https://www3.musichq.net/
* https://www1.zoechip.com/
* https://zoechip.org/
* https://www1.attacker.tv/
* https://quitt.net/
* https://www1.seeingblind.net/
* https://www6.123moviesgo.tv/
* https://123moviestv.net/
* https://moviecracker.net/
* https://fmovieshd.vip/
* https://moviesjoy.to/
* https://www.redbeltmovie.com/
* https://fullmoviehd4k.com/
* https://cataz.net/ 
* https://tinyzonetv.to/
* https://tinyzonetv.cc/
* https://tinyzonetv.to/
* https://www.showboxmovies.net/
* https://www.watch4freemovies.com/
* https://www2.filmlicious.net/
* https://www.fullmoviefilm.org/
* https://www.moviekids.tv/
* https://www.freemovies360.com/
* https://yesmovies.mn/
* https://fmovie.ws/
* https://fmovies.hn/ 

***

####  Icon Download Sites

**[Awesome Icons](https://github.com/notlmn/awesome-icons), [Awesome Stock Resources](https://github.com/neutraltone/awesome-stock-resources), [Icon Repositories](https://github.com/search?q=icon)**, [IconFinder](https://www.iconfinder.com/), [IconSeeker](http://www.iconseeker.com/), [Flaticon](https://www.flaticon.com/) / [Downloader](https://flaticon-downloader.beatsnoop.com/) / [2](https://github.com/razoo-choudhary/flaticon-premium), [SVG Repo](https://www.svgrepo.com/), [SimpleIcons](https://simpleicons.org/), [Noun Project](https://thenounproject.com/), [tablericons](https://tablericons.com/), [Gumroad](https://www.google.com/search?q=site%3Agumroad.com+%240+icons), [IconPacks](https://www.iconpacks.net/), [Streamline Icons](https://streamlineicons.com/download/), [game-icons](https://game-icons.net/), [icons8](https://icons8.com/icons), [ikonate](https://ikonate.com/), [iconmonstr](https://iconmonstr.com/), [styled-icons](https://styled-icons.js.org/), [glitter-graphics](http://www.glitter-graphics.com/), [Icon Archive](https://iconarchive.com/), [IconDuck](https://iconduck.com/), [HeroIcons](https://heroicons.com/), [fontawesome](https://fontawesome.com/), [css.gg](https://css.gg/), [EvaIcons](https://akveo.github.io/eva-icons/), [publicicons](https://publicicons.lllllllllllllllll.com/), [getbootstrap](https://icons.getbootstrap.com/), [remixicon](https://remixicon.com/), [IconSets](http://www.iconsets.com/), [coolarchive](http://www.coolarchive.com/), [flexiple](https://2.flexiple.com/scale/all-illustrations), [uispace](https://uispace.net/free-icons), [freeicons](http://freeicons.io/), [Quick Feather Icons](https://quick-feather-icons.vercel.app/), [illlustrations](https://illlustrations.co/), [vector.toolxox](https://vector.toolxox.com/), [icon icons](https://icon-icons.com/), [fontawesome icons](https://fontawesome.com/v5.15/icons), [100 Awesome Icon Sets](https://www.designwall.com/blog/100-awesome-free-icons-sets/), [feathericons](https://feathericons.com/), [IconHub](https://iconhub.io/), [icons-for-free](https://icons-for-free.com/), [RealFaviconGenerator](https://realfavicongenerator.net/), [Material Icons](https://material.io/icons/), [TheForgeSmith](https://icons.theforgesmith.com/), [Basic Icons](https://basicons.xyz/), [CaptainIconWeb](https://mariodelvalle.github.io/CaptainIconWeb/), [entypo](http://www.entypo.com/), [mapsicon](https://github.com/djaiss/mapsicon), [materialui](https://materialui.co/icons/), [iconoir](https://iconoir.com/), [weloveiconfonts](https://weloveiconfonts.com/), [weather-icons](https://erikflowers.github.io/weather-icons/), [typicons](https://www.s-ings.com/typicons/), [topcoat](https://github.com/topcoat/icons), [toicon](https://www.toicon.com/), [standart](https://standart.io/), [stackicons](http://stackicons.com/), [pathlove](https://pathlove.com/icons/), [useiconic](https://useiconic.com/open), [primer](https://primer.style/octicons/), [kudakurage](http://kudakurage.com/ligature_symbols/), [ionic](https://ionic.io/ionicons), [iconstore](https://iconstore.co/), [icomoon](https://icomoon.io/), [zurb](https://zurb.com/playground/foundation-icon-fonts-3), [fontello](https://fontello.com/), [devicons](https://vorillaz.github.io/devicons), [grommet](https://icons.grommet.io/), [ant.design](https://ant.design/components/icon/), [icons modulz](https://icons.modulz.app/), [tabler icons](https://tabler-icons.io/), [iconshock](https://www.iconshock.com/freeicons/), [eos-icons](https://eos-icons.com/), [1001freedownloads](https://www.1001freedownloads.com/), [iconsvg](https://iconsvg.xyz/), [polaris](https://polaris-icons.shopify.com/), [ionicons](https://ionicons.com/), [SuperTinyIcons](https://github.com/edent/SuperTinyIcons), [systemuicons](https://systemuicons.com/), [healthicons](https://healthicons.org/), [iconsplace](https://iconsplace.com/), [icofont](https://icofont.com/icons), [Phosphor Icons](https://phosphoricons.com/) / [Github](https://github.com/phosphor-icons/phosphor-home), [lineicons](https://lineicons.com/), [Icon Drives](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/base64#wiki_icon_drives), [streamlinehq](https://app.streamlinehq.com/icons), [iconify](https://iconify.design/), [heroicons](https://heroicons.dev/), [fluenticons](https://fluenticons.co/), [iconer](https://iconer.app/), [feather.netlify](https://feather.netlify.app/), [jam-icons](https://jam-icons.com/), [dryicons](https://dryicons.com/), [findicons](https://findicons.com/)

***

#### Image Colorization 

[Petalica Paint](https://petalica-paint.pixiv.dev/index_en.html), [Algorithmia](https://demos.algorithmia.com/colorize-photos), [MyHeritage In Color](https://www.myheritage.com/incolor), [9Mail Restoration](https://9may.mail.ru/restoration/?lang=en), [DeOldify](https://github.com/jantic/DeOldify), [playback](https://playback.fm/colorize-photo), [cutout](https://www.cutout.pro/photo-colorizer-black-and-white), [colorize.cc](https://colorize.cc/), [hotpot](https://hotpot.ai/colorize-picture), [Colorizer](https://deepai.org/machine-learning-model/colorizer), [imagecolorizer](https://imagecolorizer.com/), [Palette.fm](https://palette.fm/)

***

#### Image Design Resources

[AvaxGFX](https://www.avaxgfx.com/), [Freeject](https://www.freeject.net/), [PDFTree](https://pngtree.com/), [NitroGFX](https://nitrogfx.pro/), [Designer Candies](https://designercandies.net/category/freebies/), [Poliigon](https://www.poliigon.com/), [PolyHaven](https://polyhaven.com/), [GraphicPear](https://www.graphicpear.com/), [FreeDesignResources](https://freedesignresources.net/), [/r/BLKMARKET](https://reddit.com/r/blkmarket), [GraphixTree](https://graphixtree.com/), [PSDLY](https://www.psdly.com/), [CreativeFabrica](https://send.cm/s/1A/Bundles) / [PW](https://pastebin.com/VW1eEdJa), [creaxy](https://www.creaxy.com/), [CGArchives](https://www.cgarchives.com/),, [SearchGFX](https://searchgfx.com/), [Evernote.Design](https://www.evernote.design/), [Design Resources](https://github.com/MohamedYoussouf/Design-Resources). [Image Design Drives](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/base64#wiki_image_design_drives)

***

#### Image Download Extensions

[Download all Images](https://add0n.com/save-images.html), [Cute Save Button](https://github.com/Dezaimasu/cute-button), [DownAlbum](https://chrome.google.com/webstore/detail/downalbum/cgjnhhjpfcdhbhlcmmjppicjmgfkppok?hl=en), [Cute Save Button](https://github.com/Dezaimasu/cute-button), [Download all Images](https://add0n.com/save-images.html), [Save Images](https://github.com/belaviyo/save-images/), [svgexport](https://svgexport.io/), [svg-grabber](https://chrome.google.com/webstore/detail/svg-grabber-get-all-the-s/ndakggdliegnegeclmfgodmgemdokdmg), [SVG Gobbler](https://github.com/rossmoody/svg-gobbler)

***

#### Image Editing

**Editing Software**

**[Gimp](https://www.gimp.org/)** / [Photoshop UI](https://github.com/Diolinux/PhotoGIMP), [2](https://github.com/cttynul/gimpshop-reloaded), [PhotoDemon](https://github.com/tannerhelland/PhotoDemon), [Paint.net](https://www.getpaint.net/index.html), [Glimpse](https://glimpse-editor.github.io/), [Photoscape](http://www.photoscape.org/), [PhotoFiltre](http://www.photofiltre.com/), [Polarr](https://www.polarr.com/), [ImageMagick](https://imagemagick.org/index.php) / [Scripts](http://www.fmwconcepts.com/imagemagick/index.php), [Pinta Project](https://www.pinta-project.com/), [RawTherapee](https://rawtherapee.com/), [Pixeluvo](http://www.pixeluvo.com/), [Luna Paint](https://marketplace.visualstudio.com/items?itemName=Tyriar.luna-paint) (VS Code), [Glimpse](https://glimpse-editor.org/), [Gimel Studio](https://gimelstudio.github.io/), [Luminar](https://skylum.com/chip-luminar4), [MagickUtils](https://github.com/n00mkrad/magick-utils)

**Online Editors**

**[Photopea](https://www.photopea.com/)**, [Pixlr](https://pixlr.com/), [BeFunky](https://www.befunky.com/), [Resize Pixel](https://www.resizepixel.com/), [FotoFlexer](https://fotoflexer.com/), [Sumopaint](https://www.sumopaint.com/), [Lunapic](https://lunapic.com/), [Polotno Studio](https://studio.polotno.dev/), [OIE](https://www.online-image-editor.com/), [IMG online](https://www.imgonline.com.ua/eng/), [BitMappery](https://www.igorski.nl/application/bitmappery/), [Kapwing](https://www.kapwing.com/), [Photoshop.adobe](https://photoshop.adobe.com/), [ILoveImg](https://www.iloveimg.com/photo-editor), [Panzoid](https://panzoid.com/), [Stet](https://stet.io/), [GifGit](https://www.gifgit.com/), [Polarr](https://photoeditor.polarr.co/), [UpperPix](https://upperpix.com/), [webp2jpg](https://renzhezhilu.github.io/webp2jpg-online/), [Picverse](https://www.picverse.com/), [Image Online](https://pencilsketch.imageonline.co/), [Fotor](https://www.fotor.com/), [PictureEditor](https://www.pictureeditor.com/), [PhotoStack](https://edit.photostack.app/), [Facet](https://facet.ai/), [Peko-Step](https://www.peko-step.com/en/tool/imageeditor.html), [ImageOnline](https://imageonline.co/), [Tom's Editor](https://tomseditor.com/, [CutMyPic](http://www.cutmypic.com/), [edit.photo](https://edit.photo/), [Image Resizer](https://www.image-resizer.eu/), [Miditone](https://midtone.app/)

***

####  Image hosting / Processing 

**Hosting** 

[WebOasis IPFS](https://weboasis.app/ipfs/), [IMGrPost](https://imgrpost.com/), [ImgBB](https://imgbb.com/), [Shutterfly](https://www.shutterfly.com/), [Imgur](https://imgur.com/) / [Frontend](https://rimgo.bus-hit.me/), [2](https://git.voidnet.tech/kev/imgin), [3](https://codeberg.org/video-prize-ranch/rimgo), [4](https://i.bcow.xyz/), [5](https://git.geraldwu.com/gerald/imgrs ), [6](https://git.geraldwu.com/gerald/omgur), [7](https://codeberg.org/3np/rimgu) / [Proxy](https://imgin.voidnet.tech/), [FreeImage.Host](https://freeimage.host/), [snipboard](https://snipboard.io/), [vaa.red](https://upload.vaa.red/), [Postimages](https://postimages.org/), [imgbox](https://imgbox.com/), [pasteboard](http://www.pasteboard.co/), [vgy](https://vgy.me/), [i](https://tikolu.net/i/), [tixte](https://tixte.com/), [gpic](https://gpic.site/), [linkpicture](https://www.linkpicture.com/), [imagebam](https://www.imagebam.com/), [imagevenue](https://www.imagevenue.com/), [ipfs pics](http://ipfs.pics/), [imageserver](https://imageserver.link/), [pixelfed](https://pixelfed.org/), [talaikis](https://ipfs.talaikis.com/upload), [imgchest](https://imgchest.com/), [anhsieuviet](https://anhsieuviet.com/), [ụphinh](https://uphinh.vn/), [upanhtv](https://upanh.tv/), [upanhme](https://upanh.me/), [sendpic](http://sendpic.org/), [pixelfed](https://pixelfed.social/, [Lutim](https://lutim.lagout.org/), [Lensdump](https://lensdump.com/) / [Discord](https://discord.gg/Vuzr6xaaZN), [prnt.sc](https://prnt.sc/)

**Processing**

**[Sirv](https://sirv.com/)**, **[CloudImage](https://www.cloudimage.io/)**, [filestack](https://www.filestack.com/), [imagga](https://imagga.com/), [kraken](https://kraken.io/), [cloudinary](https://cloudinary.com/), [tiny.pictures](https://tiny.pictures/), [zara4](https://zara4.com/), [RawTherapee](https://www.rawtherapee.com/), [Digikam](https://www.digikam.org/)

***

#### Image Upscalers 

[Waifu2x](https://github.com/nagadomi/waifu2x), [Upscayl](https://github.com/upscayl/upscayl), [GigaPixel](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/base64#wiki_gigapixel), [upscaler](https://icons8.com/upscaler), [Bigjpg](https://bigjpg.com/), [Crunch](https://github.com/chrissimpkins/Crunch), [Resizer](https://resizer.in/), [PNG-Upscale](https://github.com/Araxeus/PNG-Upscale), [Cupscale](https://github.com/n00mkrad/cupscale), [Upscaler Stockphotos](https://upscaler.stockphotos.com/), [ImageUpscaler](https://imageupscaler.com/) / [2](https://image-upscaler.beatsnoop.com/), [image upscaler](https://image-upscaler.com/), [CupScale](https://github.com/n00mkrad/cupscale), [Upscale Media](https://www.upscale.media/), [Zyro Upscaler](https://zyro.com/tools/image-upscaler), [Nicescaler](https://jangystudio.itch.io/nicescaler)

**Waifu2x Tools**

[Guide](https://i.imgur.com/55s8sU5.png) / [Colab](https://colab.research.google.com/drive/1RjyCk30cc24ez1-a1Qa3CP3g_yk9AJwq) / [GUI](https://github.com/YukihoAA/waifu2x_snowshell/releases), [2](https://github.com/DeadSix27/waifu2x-converter-cpp), [3](https://waifu2x.booru.pics/), [4](https://waifu2x.pro/), [5](http://waifu2x.udp.jp/), [6](https://waifu2x.org/), [7](https://github.com/AaronFeng753/Waifu2x-Extension-GUI), [8](https://github.com/nihui/waifu2x-ncnn-vulkan)

**ESRGAN Models**

[ESRGAN Models](https://icedrive.net/1/43GNBihZyi), [Upscale Model Database](https://upscale.wiki/wiki/Model_Database), [ESRGAN](https://github.com/JoeyBallentine/ESRGAN)

***

#### Image to Text

[Capture2Text](http://capture2text.sourceforge.net/), [Text Grab](https://github.com/TheJoeFin/Text-Grab), [TextShot](https://github.com/ianzhao05/textshot), [OnlineOCR](https://onlineocr.org/), [IMG2TXT](http://img2txt.com/), [NewOCR](https://www.newocr.com/), [OCR.SPACE](https://ocr.space/), [Project Naptha](https://projectnaptha.com/), [Extract text from image](https://brandfolder.com/workbench/extract-text-from-image), [2ocr](https://2ocr.com/), [ocronline](https://ocronline.info/), [free-online-ocr](http://www.free-online-ocr.com/), [i2ocr](https://www.i2ocr.com/), [ImageToText](https://www.imagetotext.info/), [OnlineOCR](https://www.onlineocr.net/)

***

#### Image Viewers

**[IrfanView](https://www.irfanview.com/)**, [qimgv](https://github.com/easymodo/qimgv), [XnView](https://www.xnview.com/en/), [nomacs](https://nomacs.org/), [ImageGlass](https://imageglass.org/), [PhotoQt](https://github.com/luspi/photoqt), [Win 7 Photos](https://mega.nz/file/94AwRBiZ#ySswvrH88PlmNrLcbmrIZROWVcmLum-N0tAZS31l72U), [PicView](https://github.com/Ruben2776/PicView), [JPEGView](https://github.com/sylikc/jpegview), [Image Eye](https://www.fmjsoft.com/imageeye.html), [qView](https://interversehq.com/qview/), [Quick Picture Viewer](https://moduleart.github.io/quick-picture-viewer/) / [Git](https://github.com/ModuleArt/quick-picture-viewer), [Fragment](https://www.fragmentapp.info/), [qView](https://github.com/jurplel/qView), [HoneyView](https://en.bandisoft.com/honeyview/)

***

#### Interactive Math Sites

**[AoPS Alcumus](https://artofproblemsolving.com/alcumus),** [Cut The Knot](http://www.cut-the-knot.org/), [Mathlets](https://mathlets.org/), [GeoGebra](https://www.geogebra.org/), [Mathspad](https://www.mathspad.co.uk/resources.php?interactives=1) 

***

#### Internet Speed Test

[fast](https://fast.com/) / [CLI](https://github.com/sindresorhus/fast-cli), [LibreSpeed](https://librespeed.org/), [Xfinity Speed Test](https://speedtest.xfinity.com/), [DLS Reports](http://www.dslreports.com/tools), [Bandwidth Place](https://www.bandwidthplace.com/), [Cloudflare](https://speed.cloudflare.com/), [Speedtest](https://www.speedtest.net/), [wifiman](http://wifiman.com/), [Net Speed Meter](https://www.microsoft.com/en-gb/p/app/9nmbx01pxz4l), [PeerFast](https://diegorbaquero.github.io/PeerFast/) (P2P), [Speedtest-Tracker](https://github.com/henrywhitaker3/Speedtest-Tracker), [GoogleFiber](http://speedtest.googlefiber.net/), [speedtestcustom](https://pcmag.speedtestcustom.com/), [SpeedOf.Me](https://speedof.me/), [BroadbandSpeedChecker](https://broadbandspeedchecker.co.uk/), [speed.io](https://speed.io/), [att](https://www.att.com/support/speedtest/), [speedcheck](https://www.speedcheck.org/), [testmyspeed](https://testmyspeed.onl/), [speedtest](https://speedtest.ph/), [testmy](https://testmy.net/), [Meter](https://www.meter.net/), [CIRA](https://performance.cira.ca/)cadence

***

#### Into The Black Hole

[Firefox](https://addons.mozilla.org/en-US/firefox/addon/into-the-black-hole/) / [Chrome](https://chrome.google.com/webstore/detail/into-the-black-hole-true/faeadnfmdfamenfhaipofoffijhlnkif)

***

#### IP Checkers

[My IP Address](https://myipaddress.ru/), [WhatIsMyIPAdress](https://whatismyipaddress.com/), [IPInfoDB](https://ipinfodb.com/), [IP Burger](https://www.ipburger.com/ip/), [NSUpdate](https://www.nsupdate.info/), [IfConfig](https://ifconfig.me/), [elahmad](http://www.elahmad.com/api/), [myip](https://myip.ms/), [WhatIsMyIPLookup](https://whatismyiplookup.com/), [ipturtle](https://ipturtle.com/), [iphorse](https://www.iphorse.com/), [ippig](http://ippig.net/), [ipcow](https://www.ipcow.com/), [ipchicken](https://ipchicken.com/), [who.is](https://who.is/), [ip2location](https://www.ip2location.com/)

***

#### IP / DNS Leak Tests

**IP Leak Tests**

[BrowserLeaks](https://browserleaks.com/), [Astrill](https://rentry.co/astrill), [Comparitech](https://www.comparitech.com/privacy-security-tools/dns-leak-test/), [Netease](https://nstool.netease.com/), [Do I leak?](https://www.doileak.com/), [IPLeak](https://ipleak.org/), [IPLeak.com](https://ipleak.com/)

**DNS Leak Tests**

[DNS Leak Test](https://www.dnsleaktest.com/), [tenta](https://tenta.com/test/), [Bash DNS Test](https://bash.ws/dnsleak) 

***

#### IP / Network Tools

[2ip.io](https://2ip.io/) / [2](https://2ip.me/) / [3](https://2ip.ru/), [IPVoid](https://www.ipvoid.com/), [Hacker Target](https://hackertarget.com/ip-tools/), [ipaddressguide](https://www.ipaddressguide.com/), [ipfingerprints](https://www.ipfingerprints.com/), [centralops](https://centralops.net/), [networkappers](https://www.networkappers.com/), [dnstools](http://www.dnstools.ch/), [intodns](https://www.intodns.com/), [networkappers](https://networkappers.com/), [ipinfo](https://ipinfo.info), [ViewDNS](https://viewdns.info/), [DNSChecker](https://dnschecker.org/all-tools.php), [Dotcom Tools](https://www.dotcom-tools.com/), [Resolve.rs Tools](https://resolve.rs/tools.html), [Webrate](https://webrate.org/), [Website.informer](https://website.informer.com/), [Network Tools](https://network-tools.com/), [WebsiteScoop](https://websitescoop.com/) 

***

#### IPTV Tools

[m3u to txt](https://siptv.eu/converter/) / [M3U Editor](https://m3u4u.com/) / [Dummy EPG](https://github.com/yurividal/dummyepgxml)

****

#### IPTV Playlists

[HLS Cat](https://hlscat.com/), [IPTVCat](https://iptvcat.net/), [DailyIPTVList](https://www.dailyiptvlist.com/ip-tv/), [AllIPTV](https://www.alliptvlinks.com/), [TVLab](https://t.me/tvlab), [IPTV_Sport](https://t.me/iptv_sport), [Leaksat](https://leaksat.com/category/free-iptv/), [GratisIPTV](http://www.gratisiptv.com/), [iptvmate](https://iptvmate.net/), [IPTV](https://www.iptvsource.com/free-ip-tv/), [iptvm3ulist](https://www.iptvm3ulist.com/), [dailym3uiptv](https://dailym3uiptv.com/), [iptv-gratuits](https://iptv-gratuits.com/), [iptvsat](https://iptvsat.info/), [eja.tv](https://eja.tv/), [iptv4sat](https://www.iptv4sat.com/), [iptv-work](https://iptv-work.at.ua/), [xtemus](https://xtemus.com/), [Hacxx-Free-IPTV](http://bit.ly/Hacxx-Free-IPTV), [best.freeiptv](https://best.freeiptv.life/), [index.m3u](https://iptv-org.github.io/iptv/index.m3u)

****

#### IRC Book Sites

* irc://irc.undernet.org/bookz
* irc://irc.irchighway.net/ebooks / [Request Guide](https://i.imgur.com/GvyDh0B.png)

***

#### Jigsaw Puzzles

[jigidi](https://www.jigidi.com/), [jigsawonline](https://jigsawonline.net/), [jigsawplanet](https://www.jigsawplanet.com/), [puzzlefactory](https://puzzlefactory.pl/en), [epuzzle](https://www.epuzzle.info/en), [dkmgames](https://dkmgames.com/Jigsaw/), [jigzone](http://www.jigzone.com/), [jigcardgallery](http://www.jigcardgallery.com/), [justjigsawpuzzles](https://justjigsawpuzzles.com/), [Puzzle Party](https://artsandculture.google.com/experiment/puzzle-party/EwGBPZlIzv0KRw)

***

#### Keyboard Testers

[Key Test](https://en.key-test.ru/), [KeyboardTester](https://www.keyboardtester.com/) / [2](https://keyboardtester.co/), [keyboard-tester](https://keyboard-tester.com/), [keytest](https://keytest.ru/en/) / [2](https://keytest.vn/), [keyboard-test](https://keyboard-test.space/), [keyboardtestt](https://keyboardtestt.com/), [keyboardchecker](https://keyboardchecker.com/), [keyboardtest](https://www.keyboardtest.org/)

***

#### Kodi

* [Kodi](https://kodi.tv/) - Media Server / Streaming App
* [Builds Chart](https://kodiapps.com/builds-chart) - Kodi Builds
* Kodi Addons - [/r/Addons4Kodi](https://reddit.com/r/Addons4Kodi), [Addon Tracker](https://kinkeadtech.com/best-kodi-streaming-addons/) / [2](https://kodiapps.com/addons-chart)
* [MMA](https://www.bestkoditips.com/best-kodi-addons-to-watch-ufc-online/) - MMA App
* [AZNHusband](https://aznhusband.github.io/) / [2](https://github.com/soraxas/aznhusband.github.io/releases) or [cywteow](https://cywteow.github.io/) - KDrama Apps
* Kodi Tools - [IPTV](https://kodi.wiki/view/Add-on:PVR_IPTV_Simple_Client) / [Media Tracker](https://simkl.com/) / [Media Manager](https://github.com/komet/mediaelch) / [Plex](https://github.com/plexinc/plex-for-kodi)

***

#### Location Guard

[Firefox](https://addons.mozilla.org/en-US/firefox/addon/change-geolocation-locguard/) / [2](https://addons.mozilla.org/en-US/firefox/addon/location-guard/), [Chrome](https://chrome.google.com/webstore/detail/change-geolocation-locati/lejoknkbcogjceoniealiipllomkpioe) / [2](https://chrome.google.com/webstore/detail/location-guard/cfohepagpmnodfdmjliccbbigdkfcgia), [Opera](https://addons.opera.com/en-gb/extensions/details/change-geolocation-location-guard/)

***

#### LibGen Tools

[Desktop](https://wiki.mhut.org/software:libgen_desktop) / [Mobile](https://github.com/manuelvargastapia/libgen_mobile_app), [2](https://github.com/FunkyMuse/Aurora) / [Need Seeds](https://phillm.net/libgen-seeds-needed.php) / [Python Script](https://github.com/NadalVRoMa/PyLibGen) / [CLI](https://github.com/carterprince/libby) / [Onion](http://genotypeinczgrxr.onion/) / [Backup](https://redd.it/edwi9b) / [/r/libgen](https://reddit.com/r/libgen)

**Mirrors**

* https://whereislibgen.now.sh/
* http://vertsluisants.fr/index.php?article4/where-scihub-libgen-server-down
* https://sguru.org/libgen-proxy/
* http://libgen.lc/
* http://libgen.li/
* https://libgen.fun/

***

#### Linux Distros 

**[Babbies First Linux](https://wiki.installgentoo.com/index.php/Babbies_First_Linux)**, [ArchiveOS](https://archiveos.org/), [LinuxTracker](https://linuxtracker.org/), [tohoku](http://www.cs.tohoku-gakuin.ac.jp/pub/Linux/), [OpenSourceFeed](https://www.opensourcefeed.org/), [minerswin](http://root3.minerswin.de/ISO/), [Pkgs](https://pkgs.org/), [DistroWatch](https://distrowatch.com/dwres.php?resource=popularity)

***

#### Linux Themes

[Gnome-Look](https://www.gnome-look.org/), [Oomox](https://github.com/themix-project/oomox), [Arc](https://github.com/jnsh/arc-theme), [Numix](https://github.com/numixproject/numix-gtk-theme), [Evopop](https://github.com/solus-project/evopop-gtk-theme), [Flatablous](https://github.com/anmoljagetia/Flatabulous), [Flatablous Arc](https://github.com/andreisergiu98/arc-flatabulous-theme), [Material Ocean](https://github.com/material-ocean/material-ocean), [Ant](https://github.com/EliverLara/Ant), [xfce-look](https://www.xfce-look.org/) 

***

#### Live Webcams

[EarthCam](https://www.earthcam.com/), [Explore](https://explore.org/), [Opentopia](http://www.opentopia.com/), [The Webcam Network](https://www.the-webcam-network.com/), [OpenStreetCam](https://openstreetcam.org/map), [WebcamGalore](https://www.webcamgalore.com/), [WebcamTaxi](https://www.webcamtaxi.com/en/), [WorldCams](https://worldcams.tv/), [WorldCam](https://worldcam.eu/), [BalticLiveCam](https://balticlivecam.com/), [SkylineWebcams](https://www.skylinewebcams.com/en.html), [CamStreaner](https://camstreamer.com/live), [/r/controllablewebcams](https://reddit.com/r/controllablewebcams) / [Discord](https://discord.gg/wdjtevG), [CamVista](https://www.camvista.com/), [Fisgonia](http://www.fisgonia.com/), [PicTimo](https://www.pictimo.com/), [WXYZWebcams](http://wxyzwebcams.com/) [snoweye](https://www.snoweye.com/), [camscape](https://www.camscape.com/), [whatsupcams](https://www.whatsupcams.com/), [worldcam](https://www.worldcam.pl/), [gobefore](https://gobefore.me/), [webcamhopper](https://www.webcamhopper.com/), [SpiedLife](https://www.spiedlife.com/), [explore.org](https://explore.org/livecams), [Windy Webcams](https://www.windy.com/-Webcams/webcams), [Insecam](http://www.insecam.org/en/), [Airport Webcams](https://airportwebcams.net/) (Airports), [TFLJamCams](https://www.tfljamcams.net/), [seattlesouthside](https://www.seattlesouthside.com/live-webcams-around-seattle/), [portugal-live](https://www.portugal-live.net/en/webcams.html), [livecamcroatia](https://www.livecamcroatia.com/en), [myrtlebeach](https://www.myrtlebeach.com/webcams/), [sootoday](https://www.sootoday.com/webcams), [interlochen](https://www.interlochen.org/webcasts/live-webcams), [whitehouse cam](https://whitehouse.gov1.info/webcam/), [yellowstone cam](https://www.nps.gov/yell/learn/photosmultimedia/webcams.htm), [carowinds](https://www.carowinds.com/live-video), [zellamsee](https://www.zellamsee-kaprun.com/en/live/webcams), [wpri](https://www.wpri.com/live-cams/), [hdontap](https://hdontap.com/), [floridakeyswebcams](https://floridakeyswebcams.tv/), [earthtv](https://www.earthtv.com/en), [geocam](https://www.geocam.ru/en/), [livefromiceland](https://livefromiceland.is/), [world-cam](https://en.world-cam.ru/), [mangolinkworld](https://www.mangolinkworld.com/), [mylivestreams](https://www.mylivestreams.com/live-streaming-cams/), [spain-grancanaria](https://www.spain-grancanaria.com/en/images-videos/webcams.html), [visitlondon](https://www.visitlondon.com/things-to-do/sightseeing/london-attraction/webcams-of-london), [ctsfl](https://www.ctsfl.us/cams/), [aruba](https://www.aruba.com/us/live-webcams-and-channels), [fogcam](http://www.fogcam.org/), [bigrigtravels](http://bigrigtravels.com/), [bigtexan](http://bigtexan.com/live-stream/), [lochness](http://www.lochness.co.uk/livecam/), [abbeyroad](https://www.abbeyroad.com/crossing), [camsecure](https://www.camsecure.co.uk/Camsecure_Live_Demo_Index.html), [ISS](https://www.nasa.gov/multimedia/nasatv/iss_ustream.html)

**Animal Cams**

[Monterey Bay Aquarium](https://www.montereybayaquarium.org/animals/live-cams), [Curlie Webcam Animals](https://curlie.org/en/Computers/Internet/On_the_Web/Webcams/Animals), [San Diego Zoo](https://zoo.sandiegozoo.org/live-cams), [Zqoo.org](https://www.zoo.org/webcams), [AnimalsLife](https://animalslife.net/), [Africam](https://www.africam.com/wildlife/live-african-wildlife-safari-streams), [NationalZoo](https://nationalzoo.si.edu/webcams), [BirdCams](https://birdcams.live/), [CritterYard](http://critteryard.com/), [AquariumOfPacific](http://www.aquariumofpacific.org/exhibits/webcams)

***

#### M3U Players

[hlsplayer](https://www.hlsplayer.net/), [PlaylistEditorTV](https://github.com/Isayso/PlaylistEditorTV), [ustvgo-iptv](https://github.com/interlark/ustvgo-iptv)

***

#### M4UFree Clones

[M4uFree](http://m4ufree.tv) / [2](https://ww1.m4ufree.tv/), [Streamm4u](http://streamm4u.com) / [2](https://streamm4u.ws/), [m4ufree.to](https://m4ufree.to/), [m4uhd](https://m4uhd.tv/) / [2](https://m4uhd.cc/) 

***

#### Magic / Esoteric Telegram Ebooks

* https://t.me/magZtore
* https://t.me/ocultarias
* https://t.me/WonderlandLibraryOfMagicBooks
* https://t.me/spiritualbooks
* https://t.me/spiritualitybooks
* https://t.me/synchroncity1111

***

#### Manga Download Bots

[HakuNeko](https://github.com/manga-download/hakuneko), [Comics Downloader](https://github.com/Girbons/comics-downloader), [FMD](https://sourceforge.net/projects/fmd/), [MangaRipper](https://github.com/NguyenDanPhuong/MangaRipper), [Comic-DL](https://github.com/Xonshiz/comic-dl), [work_crawler](https://github.com/kanasimi/work_crawler/blob/master/document/README.en-US.md), [Free Manga Downloader](https://sourceforge.net/projects/newfmd/), [mangadownbot](https://t.me/mangadownbot), [MangaBot](http://mangabot.github.io/), [MangaRipper](https://www.softpedia.com/get/Internet/Download-Managers/MangaRipper.shtml), [Manga Downloader](https://www.redsquirrel87.altervista.org/doku.php/manga-downloader), [AnimeClassroom](https://github.com/justdvnsh/AnimeClassroom), [HDoujinDownloader](https://github.com/HDoujinDownloader/HDoujinDownloader), [FMD2](https://github.com/dazedcat19/FMD2), [mangadesk](https://github.com/darylhjd/mangadesk), [mdownloader](https://github.com/Rudoal/mdownloader), [mangapy](https://pypi.org/project/mangapy/), [manga2mobi](https://github.com/KevCui/manga2mobi), [Akianonymus](https://github.com/Akianonymus/mangadl-bash), [simple-manga-downloader](https://github.com/Kanjirito/simple-manga-downloader), [mangodl](https://github.com/Gyro7/mangodl), [anime-dl](https://github.com/vrienstudios/anime-dl) / [2](https://github.com/vrienstudios/anime-dl), [manga-py](https://github.com/manga-py/manga-py), [mangal](https://github.com/metafates/mangal), [comicMaker](https://github.com/gunjannandy/comicMaker), [LittleWeeb](https://littleweeb.github.io/)

***

#### Manhua / Manhwa Manga

* https://toonily.com/
* https://manhwa18.net/
* https://manhuafast.com/
* https://manhwakool.com/
* https://manhuascan.io/
* https://manhwatop.com/
* https://www.instamanhwa.com/
* https://manhwa365.com/
* https://manhwa68.com/
* https://zinmanga.com/
* https://manhwaworld.com/
* https://manhwatop.com/
* https://comickiba.com
* https://readmanhwa.com/en/
* https://manhwaz.com/
* https://manhwafull.com/
* https://www.topmanhua.com/
* https://manhuas.net/
* https://manhuaes.com/
* https://manhuadragon.com/
* https://manhuahot.com/
* https://todaymic.com
* https://manhuazone.com/
* https://manhuaga.com/
* https://teenmanhua.com/

***

#### Manually Scrape Sites

Add the following commands to a search to manually scrape each site. 

**Try on [google](https://www.google.com/), [duckduckgo](https://duckduckgo.com/), [yandex](https://yandex.com) & [yahoo.](https://search.yahoo.com/web)**

`site:vup.to`

`site:vidlox.me`

`site:videobin.co`

`site:vidoza.net`

`site:vk.com`

`site:drive.google.com`

`-inurl:(htm|html|php|pls|txt) intitle:index.of “last modified” (mp4|wma|aac|avi)`(Archive Scrape)

***

#### Media Servers

* **[Plex](https://www.plex.tv/)** 
* **Plex Tools** - /r/plexshares / [Media Sync](https://synclounge.tv/) / [Mount GDrive](https://github.com/plexdrive/plexdrive), [2](https://docs.usbx.me/books/rclone/page/rclone-vfs-and-mergerfs-setup
Hosters: https://pastebin.com/AUqx5N3X) / [Hosters](https://pastebin.com/AUqx5N3X) / [Setup Guide](https://redd.it/ma1hlm), [2](https://hoarding.me/) / [Plex Pass](https://github.com/binhex/arch-plexpass) / [User Requests](https://overseerr.dev/) / [Monitor](https://tautulli.com/)
* **[Jellyfin](https://jellyfin.org/)**
* **Jellyfin Tools** - /r/JellyfinShares / [Anime Plugin](https://github.com/jellyfin-archive/jellyfin-plugin-anime) / [Live Sports](https://github.com/axelmierczuk/sportyfin) / [Desktop Client](https://github.com/jellyfin/jellyfin-media-player) / [Android](https://github.com/jarnedemeulemeester/findroid) / [Last.fm](https://github.com/jesseward/jellyfin-plugin-lastfm) / [Playlist Export](https://github.com/pyluyten/jellyfin_playlist_exporter) / [Customization Guide](https://youtu.be/F85qMyBeiDI) / [Themes](https://jellyfin.org/docs/general/clients/css-customization.html#community-themes) / [Minimal Skin](https://github.com/prayag17/JellySkin) / [Setup Guide](https://www.fuzzygrim.com/posts/media-server)
* [Autodownload Tools](https://redd.it/hbwnb2) - Companion Apps for Media Servers
* [Emby](https://emby.media/) + /r/EmbyShares
* [Universal Media Server](https://www.universalmediaserver.com/)
* [OSMC](https://osmc.tv/)
* [Olaris](https://gitlab.com/olaris/olaris-server/tree/master)
* [Subsonic](http://www.subsonic.org/) 
* [Kawaii-Player](https://github.com/kanishka-linux/kawaii-player)
* [Streama](https://github.com/streamaserver/streama)
* [Gerbera](https://gerbera.io/)
* [Serviio](https://www.serviio.org/)
* [Dim](https://github.com/Dusk-Labs/dim) 
* [WatchIt](https://github.com/ZorrillosDev/watchit-app) 
* [Rygel](https://wiki.gnome.org/Projects/Rygel)
* [MiniDLNA](https://sourceforge.net/projects/minidlna/)
* [SimpleDLNA](https://nmaier.github.io/simpleDLNA/) 
* [Frames](https://github.com/Eleven-am/frames) - GDrive Server
* [Kodi](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/storage#wiki_kodi)
* [Vigilio](https://vigilio.tugcan.net/) - [GitHub](https://github.com/tugcanolgun/vigilio)
* [ErsatzTV](https://ersatztv.org/) - Live Channel Media Server
* [dizqueTV](https://github.com/vexorian/dizquetv) - Live Channel Media Server
* [xTeVe](https://github.com/xteve-project/xTeVe) - Plex / Emby M3U Proxy 
* [Organizr](https://github.com/causefx/Organizr) - Media Server Manager
* [Autoscan](https://github.com/Cloudbox/autoscan) - Real-Time Plex & Emby File Changes
* [Ombi](https://ombi.io/) - Plex / Emby User Request Management
* [TRaSH Guides](https://trash-guides.info/) or [The Complete Guide](https://redd.it/pqsomd) - Video Server Setup Guides
* [Archon Wiki](https://github.com/Protektor-Desura/Archon/wiki/Compare-Media-Servers) - Media Server Comparisons

***

#### Mind Mapping

**[Logseq](https://logseq.com/)**, [MindMup](https://www.mindmup.com/), [FreeMind](http://freemind.sourceforge.net/wiki/index.php/Main_Page), [Kinopio](https://kinopio.club/), [Mindomo](https://www.mindomo.com/), [Yuque](https://www.yuque.com/), [MindMapp](https://mindmapp.cedoor.dev/app), [are.na](https://www.are.na/), [Domino](https://kool.tools/domino), [GitMind](https://gitmind.com/), [xTiles](https://xtiles.app/en)

**Collaborative Mind Mapping**

[Coggle](https://coggle.it/), [CardSmith](https://cardsmith.co/), [Memrey](https://www.memrey.com/), [MindMeister](https://www.mindmeister.com/)

***

#### Minecraft Mods

[NordicGames](https://github.com/NordicGamerFE/usefulmods), [CurseForge](https://www.curseforge.com/minecraft/mc-mods), [Planet Minecraft](https://www.planetminecraft.com/), [Modrinth](https://modrinth.com/), [MC Archive](https://mcarchive.net/), [Alternatives](https://microcontrollersdev.github.io/Alternatives/)

***

#### Minecraft Optimization Mods

**[Fabulously Optimised](https://github.com/Fabulously-Optimized/fabulously-optimized)**, [OptiFine](https://optifine.net/), [Sodium](https://modrinth.com/mod/sodium) / [Indium](https://github.com/comp500/Indium/) / [Extra](https://modrinth.com/mod/sodium-extra), [Phosphor](https://modrinth.com/mod/phosphor), [Ferrite Core](https://modrinth.com/mod/ferrite-core), [Caffeine](https://github.com/CaffeineMC), [Lithium](https://modrinth.com/mod/lithium), [Ares](https://www.aresclient.com/), [MinecraftTweaker](https://minecrafttweaker.net/), [VulkanMod](https://github.com/xCollateral/VulkanMod)

***

#### Minecraft Servers 

[MineColab](https://colab.research.google.com/github/thecoder-001/MineColab/blob/master/MineColab.ipynb) / [GitHub](https://github.com/thecoder-001/MineColab), [MineFort](https://minefort.com/), [Minehut](https://www.minehut.com/), [ScalaCube](https://scalacube.com/), [PloudOS](https://ploudos.com/), [Aternos](https://aternos.org/), [FreeMCServer](https://freemcserver.net/) / [uBO Filter](https://pastebin.com/C2aiXG8p), [Cuberite](https://cuberite.org/)

***

#### Mouse Gestures

[FoxyGestures (firefox)](https://github.com/marklieberman/foxygestures), [Gesturefy (firefox)](https://github.com/Robbendebiene/Gesturefy), [CrxMouse (chrome)](https://crxmouse.com/), [Simple Gesture (firefox)](https://github.com/utubo/firefox-simple_gesture) 

***

#### Modded Minecraft Launchers

**[PolyMC](https://polymc.github.io/)**/ [Offline Mode](https://github.com/fn2006/PollyMC), **[Lunar Client](https://www.lunarclient.com/)** / [Lite](https://github.com/Nilsen84/lunar-client-qt) / [Colors](https://github.com/couleur-tweak-tips/Moony) / [Socket](https://solarsocket.solartweaks.com/), **[UltimMC](https://github.com/AfoninZ/UltimMC)**, **[SkLauncher](https://skmedix.pl/sklauncher)**, [MultiMC](https://multimc.org/), [GDLauncher](https://gdevs.io/), [Badlion](https://www.badlion.net/), [OG tLauncher](https://tlaun.ch/), [HMCL](https://github.com/huanghongxun/HMCL), [TechnicPack](https://www.technicpack.net/), [ATLauncher](https://atlauncher.com/), [RPMLauncher](https://github.com/RPMTW/RPMLauncher), [LabyMod](https://www.labymod.net/), [Crystal Launcher](https://crystal-launcher.net/), [PollyMC](https://github.com/fn2006/PollyMC)

***

#### Multi Image Tool Sites

[WebOasis Editors](https://weboasis.app/editors/), [Hotot](https://hotpot.ai/), [RedKetchup](https://redketchup.io/), [VertexShare](https://vertexshare.com/), [ImageConvert](https://imageconvert.org/), [MyPhotoFilter](https://www.myphotofilter.com/), [Img2Go](https://www.img2go.com/), [BrandFolder](https://brandfolder.com/workbench-suite), [fffuel](https://fffuel.co/), [ImgLarger](https://imglarger.com/), [Convertmyimage](https://convert-my-image.com/), [SocialBook](https://socialbook.io/), [Mara](https://mara.photos/), [StitchTool](https://www.jdeploy.com/~stitchtool) / [GitHub](https://github.com/Aeonss/StitchTool/), [Bloggif](https://en.bloggif.com/video), [BatchWatermark](https://batchwatermark.com/), [FastStone](https://www.faststone.org/index.htm), [ConvertImage](https://convertimage.net/), [PicWish](https://picwish.com/), [onlinejpgtools](https://onlinejpgtools.com/)

***

#### Multireddits 

[Explore All Multireddits](https://www.reddit.com/r/multihub/top/?sort=top&t=all), [Piracy](https://www.reddit.com/user/nbatman/m/piracy/) / [2](https://www.reddit.com/user/rekuloustoad/m/the_piracy_feed/) / [3](https://www.reddit.com/user/nanomuto/m/piracyhub/) / [4](https://www.reddit.com/user/goretsky/m/piracy_counterfeit_goods/), [Random](https://www.reddit.com/user/nbatman/m/random/), [Weird YouTube](https://www.reddit.com/user/jarod47/m/wierdpartofyoutube/), [Streaming](https://www.reddit.com/user/nbatman/m/streaming/) / [2](https://www.reddit.com/user/asmailes/m/fullmoviesandtv/), [Cord Free TV](https://www.reddit.com/user/efidol/m/cordfreetv/), [Piracy Leaks](https://www.reddit.com/user/nbatman/m/leaks/), [News](https://www.reddit.com/user/nbatman/m/news/), [Tech](https://old.reddit.com/user/goretsky/m/win_itpro/), [Left](https://www.reddit.com/user/nbatman/m/left/) / [2](https://www.reddit.com/user/nbatman/m/left_2/), [Conspiracy](https://www.reddit.com/user/nbatman/m/conspiracy/), [Aliens](https://www.reddit.com/user/nbatman/m/aliens/), [Paranormal](https://www.reddit.com/user/nbatman/m/paranormal/), [Metaphysics](https://www.reddit.com/user/nbatman/m/metaphysics/), [Countries](https://www.reddit.com/user/sneaky5erpent/m/countries/) / [2](https://www.reddit.com/user/sneaky5erpent/m/countries2/), [International AskARedditor](https://www.reddit.com/user/sneaky5erpent/m/ask_people_nationality/), [Text Only](https://www.reddit.com/user/aokaga/m/stories)

***

#### Multi Site Cloud Storage Managers

* **[Air Explorer](https://airexplorer.net/en/)**
* **[RaiDrive](https://www.raidrive.com/)**
* **[RClone](https://rclone.org/)** - [Heroku](https://github.com/The-Antrax/heroku-buildpack-rclone-mod) / [WebUI](https://github.com/rclone/rclone-webui-react) / [GUI](https://github.com/kapitainsky/RcloneBrowser) / [Colab](https://colab.research.google.com/github/szyha/RcloneLabArchive/blob/master/RcloneLab.ipynb) / [Telegram](https://t.me/rclonexbot) / [Mirror Manager](https://github.com/Syzygianinfern0/RClone-Mirror-Manager) / [Transfer Tool](https://github.com/TheCaduceus/Multi-Cloud-Transfer-Tool)
* **[gclone](https://github.com/AndreVuillemot160/gclone)**, [2](https://github.com/donwa/gclone), [3](https://github.com/dogbutcat/gclone) / [Guide](https://telegra.ph/Gclone-Guide-for-Windows-07-20) / [Telegram](https://github.com/wrenfairbank/telegram_gcloner) / [Bot](https://github.com/MsGsuite/CloneBot) / [Discord Bot](https://github.com/Rekulous/CloneCord-bot) / [Colab](https://github.com/Rekulous/GCloneLab), [2](https://colab.research.google.com/github/Rekulous/GCloneLab/blob/main/GCloneLab.ipynb)
* [Koofr](https://koofr.eu/) 
* [MultCloud](https://www.multcloud.com/)
* [MSP360](https://www.msp360.com/explorer.aspx)

***

#### Multi Site Video Downloaders

**Sites / Programs**

**[9xbuddy](https://9xbuddy.org/)** / [2](https://9xbuddy.com/), [savieo](https://savieo.com/), [AllTube Download](https://alltubedownload.net/), [grabanymedia](https://grabanymedia.altervista.org/), [TubeOffline](https://www.tubeoffline.com/), [clipconverter](https://www.clipconverter.cc/2/), [clipgrab](https://clipgrab.org/), [4kdownload](https://www.4kdownload.com/), [bitdownloader](https://bitdownloader.io/), [you-get](https://you-get.org/), [annie](https://github.com/iawia002/annie), [catchvideo](https://catchvideo.net/), [Catch-Tube](https://catch.tube/), [SaveVideo.me](http://savevideo.me/?lang=en), [LocoDownloader](https://locoloader.com/), [Yout](https://yout.com/), [Keepv.id](https://keepv.id/), [downloader-ui](https://github.com/Mqlhaha/downloader-ui), [connectvip](https://connectvip.store/), [Vividl](https://vividl.sourceforge.io/), [ddownloader](https://ddownloader.com/), [pastedownload](https://pastedownload.com/), [weibomiaopai](https://weibomiaopai.com/download-video-parser.php), [gramvio](https://www.gramvio.com/), [tubeninja](https://www.tubeninja.net/), [savethevideo](https://www.savethevideo.com/), [qvideodownloader](https://qvideodownloader.com/), [dodoconverter](https://www.dodoconverter.com/), [zasasa](http://www.zasasa.com/), [ytvideodownloader](https://ytvideodownloader.net/), [ByClickDownloader](https://www.byclickdownloader.com/), [Lux](https://github.com/iawia002/lux), [superparse](https://superparse.com/), [SCrawler](https://github.com/AAndyProgram/SCrawler), [GrabFrom](https://www.grabfrom.com/), [cobalt](https://co.wukko.me/), [VDYoutube](https://vdyoutube.com/)

**Extensions**

**[Download Helper](http://www.downloadhelper.net/)**, [Video Downloader](https://provd.net/), [AddonCrop](https://addoncrop.com/en-3/?uid=36515318), [Cococut](https://cococut.net/), [skyload](http://skyload.io/), [SVD](https://chrome.google.com/webstore/detail/svd-video-downloader/jbialncfijnjojchcmhfmjgjggbbdghb/related?hl=en), [Video Downloader Professional](https://chrome.google.com/webstore/detail/video-downloader-professi/dlpiaeofjhnjeckpjcbhmnifdejoikpa)

***

#### Multi Text Tool Sites

**[TextFixer](https://www.textfixer.com/)**, **[OnlineTextTools](https://onlinetexttools.com/)**, [TextCleaner](https://textcleaner.net/), [English Tools](https://www.englishtools.org/), [Text Reverse](https://www.textreverse.com/), [Text Mechanic](https://textmechanic.com/), [Smodin](https://smodin.io/), [DrAssignment](https://www.drassignment.com/), [Word Hippo](https://www.wordhippo.com/), [I Love It](https://www.iloveit.net/tool/), [ToggleCase](http://www.togglecase.com/), [ConvertCase](https://convertcase.net/), [ConvertertoGenerator](https://convertertogenerator.com/), [qwerty.dev](https://qwerty.dev/), [onlinecaseconvert](https://onlinecaseconvert.com/), [MadeInText](https://www.madeintext.com/), [TitleCapitalize](https://titlecapitalize.com/)

***

#### Multi Tool Sites

[PineTools](https://pinetools.com/), [123Apps](https://123apps.com/), [iTools](http://itools.com/), [Framasoft](https://framasoft.org/), [Browserling Tools](https://www.browserling.com/tools/), [Dan's Tools](https://www.danstools.com/), [WebBrowserTools](https://webbrowsertools.com/), [CyberChef](https://gchq.github.io/CyberChef/), [ManyTools](https://manytools.org/), [Comment Picker](https://commentpicker.com/other-tools.php), [OSINT Combine](https://www.osintcombine.com/tools), [MxToolbox](https://mxtoolbox.com/NetworkTools.aspx), [Rumkin](https://rumkin.com/tools/), [Sumo](https://sumo.app/), [Melobytes](https://melobytes.com/en), [PatorJK](https://www.patorjk.com/), [UnitPedia](https://unitpedia.com/), [prepostseo](https://prepostseo.com/), [Digital Methods](https://wiki.digitalmethods.net/Dmi/ToolDatabase), [Flippity](https://www.flippity.net/), [AppsCyborg](https://appscyborg.com/), [JNCK Media](https://jnckmedia.com/), [BlackHost](http://www.blackhost.xyz/), [BfoTool](https://bfotool.com/), [SeoMagnifier](https://seomagnifier.com/), [Romanr](http://www.romanr.info/), [Prepostseo](https://www.prepostseo.com/), [Useful](https://useful.tools/), [Semi Colon](https://www.semicolonworld.com/webtools), [FreeToolOnline](https://freetoolonline.com/), [10015.io](https://10015.io/), [JMMG Tools](https://tools.jmmgc.com/), [0wx.org](https://www.0wx.org/), [tinywow](https://tinywow.com/), [Self Publishing Titans](https://tools.selfpublishingtitans.com/), [Inettools](https://inettools.net/), [TuckTools](https://www.tucktools.com/), [Ian Coleman](https://iancoleman.io/), [Toolki](https://toolki.com/), [Media.io](https://www.media.io/), [URL Decode](https://url-decode.com/cat/all), [Onlitools](https://www.onlitools.com/), [ChatONS](https://entraide.chatons.org/en/, [FreeToolOnline](https://freetoolonline.com/tags.html), [goonlinetools](https://goonlinetools.com/), [garyshood](https://www.garyshood.com/)

***

####  Music Libraries / Players

**Multi-System**

**[Foobar2000](https://www.foobar2000.org/)**, [AIMP](http://www.aimp.ru/?do=lang&lng=en), [Roon](https://rutracker.org/forum/tracker.php?nm=roon), [iTunes](https://www.apple.com/itunes/), [Winamp](https://winamp.com/) / [2](https://www.majorgeeks.com/files/details/winamp_5_full.html) / [Updates](https://getwacup.com/), [MusicBee](https://getmusicbee.com/), [Clementine](https://www.clementine-player.org/), [Audacious](https://audacious-media-player.org/), [OvoPlayer](http://ovoplayer.altervista.org/), [Dopamine](http://www.digimezzo.com/software/dopamine/), [Strawberry](https://www.strawberrymusicplayer.org/), [Exaile](https://exaile.org/), [JakJuk](http://www.jajuk.info/), [Amarok](https://amarok.kde.org/), [VOX](https://vox.rocks/windows-music-player), [Hysolid](https://www.hysolid.com/), [aidoru](https://github.com/ffwff/aidoru), [Melodie](https://feugy.github.io/melodie/), [Modular Player](https://www.deviantart.com/jaxoriginals/art/ModularPlayers-v1-3-886577256), [goMP](https://github.com/aditya-K2/goMP), [hyperchroma](https://hyperchroma.app/), [NCurses](https://github.com/ncmpcpp/ncmpcpp), [XMPlay](https://www.un4seen.com/) (Chiptune-Friendly), [guayadeque](https://github.com/anonbeat/guayadeque), [musique](http://flavio.tordini.org/musique), [sonata](https://github.com/multani/sonata), [exaile](http://www.exaile.org/), [quodlibet](https://github.com/quodlibet/quodlibet/), [ario](http://ario-player.sourceforge.net/), [deadbeef](https://deadbeef.sourceforge.io/), [groovebasin](https://github.com/andrewrk/groovebasin), [destroyer](https://github.com/mashaal/destroyer), [Ampache](https://ampache.org/) / [GitHub](https://github.com/ampache/ampache), [Harmanoid](https://harmonoid.com/), [MusikCube](https://musikcube.com/)

**Self-Hosted**

[Auddly](https://auddly.app/), [Music Player Daemon](https://www.musicpd.org/)

**Foobar2000 Tools** 

[Components](https://audio-file.org/foobar2000-list-of-components/), [2](https://www.foobar2000.org/components) / [VU Meter](https://audio-file.org/foobar2000-vu-meter-skins-gallery/), [Last.fm Scrobble](https://github.com/gix/foo_scrobble)

**Linux**

[cmus](https://cmus.github.io/), [Tauon Music Box](https://tauonmusicbox.rocks/), [Lollypop](https://wiki.gnome.org/Apps/Lollypop) / [2](https://gitlab.gnome.org/World/lollypop), [Audacious](https://audacious-media-player.org/), [Rhythmbox](https://wiki.gnome.org/Apps/Rhythmbox), [Amberol](https://gitlab.gnome.org/World/amberol), [Subsonic](https://github.com/twostraws/Subsonic), [g4music](https://gitlab.gnome.org/neithern/g4music)

**Mac**

[Cog](https://cogx.org/), [Cider](https://cider.sh/) / [GitHub](https://github.com/ciderapp/Cider)

***

#### Name & Identity Generators

[Fake Data](https://www.fakedata.pro/), [namefake](https://en.namefake.com/), [minirandom](https://minirandom.com/), [namegenerators](http://namegenerators.org/), [online-generator.com](https://online-generator.com/index.php), [igopaygo](https://names.igopaygo.com/), [Fake Name Generator](https://www.fakenamegenerator.com/), [fakepersongenerator](https://www.fakepersongenerator.com/), [datafakegenerator](https://datafakegenerator.com/), [elfqrin](https://www.elfqrin.com/), [fakedetail](https://fakedetail.com/), [fauxid](https://fauxid.com/), [fakexy](https://www.fakexy.com/)

**Address Generators**

[textreverse](https://www.textreverse.com/fake-address-generator.php), [anytexteditor](https://anytexteditor.com/fake-address-generator), [utilities-online](https://www.utilities-online.info/fake-address-generator), [fakeaddresscopy](https://www.fakeaddresscopy.com/ ), [usaddressgenerator](https://usaddressgenerator.com/), [thecompleteseo](https://www.thecompleteseo.com/fake-address-generator)

***

#### News Feed Aggregators

**[WebOasis News](https://weboasis.app/news/)**, **[QotNews](https://news.t0.vc/)**, [spidr](https://spidr.today/), [All Sides](https://www.allsides.com/), [NewsLookup](http://www.newslookup.com/), [NewsNow](https://www.newsnow.co.uk/), [Google News](https://news.google.com/), [freepo.st](https://freepo.st/), [TechMeme](https://www.techmeme.com/m/), [Unfeeder](https://unfeeder.com/), [RealClearPolitics](https://www.realclearpolitics.com/), [Their News](https://www.their.news/), [Twuko](https://www.twuko.com/), [Lobsters](https://lobste.rs/​), [Blazing News](https://blazing-news.herokuapp.com/), [68k News](http://68k.news/), [Readspike](https://readspike.com/), [Popurls](http://popurls.com/), [sumi.news](https://sumi.news/), [Ground News](https://ground.news/), [The Brutalist Report](https://brutalist.report/), [Bastyon](https://bastyon.com/index), [Upstract](https://upstract.com/), [Otherweb](https://otherweb.com/)

***

#### NetU Hosts

* http://www16.0123movies.org/
* https://123movies.dance/
* https://new123movies.la/
* http://www1.123moviesmovies.com/
* https://www2.online123movies.live/
* http://topbestsite.live/
* https://doomovies.ga/
* https://cinehindi.com/
* https://parkslopecannabis.shop/
* https://123movies.gdn/
* https://www.movi.pk/
* https://fffmovies.wtf/
* https://tunemovie.com/
* https://wwv.123movies.day/
* https://wwe.movierulzfree.com/
* https://www4.watchfree.ac/
* http://www2.putlockerstv.org/
* https://www1.movie4u.live/
* https://ww45.movisubmalay.website/
* https://openloadflix.com/
* https://www.hdsaprevodom.com/ 
* https://www1.watchseries.today/
* https://topeuropix.site/
* https://www.peramovies.club/ 
* https://wwv7.watchmoviesonlinepk.com/category/english-movies/page/0

***

#### Note Taking / To Do Apps

[QuickTab](https://quicktab.it/), [Notion](https://www.notion.so/) / [Themes](https://notionthemes.yudax.me/), [AppFlowy](https://www.appflowy.io/) / [GitHub](https://github.com/AppFlowy-IO/AppFlowy), [NoteApps](https://noteapps.info/) (index), [Joplin](https://joplinapp.org/) / [Firefox](https://addons.mozilla.org/en-US/firefox/addon/joplin-web-clipper/) / [Chrome](https://chrome.google.com/webstore/detail/joplin-web-clipper/alofnhikmmkdbbbgpnglcpdollgjjfek?hl=en-GB), [GoogleKeepClone](https://github.com/anselm94/googlekeepclone), [DecksApp](https://decksapp.com/), [TinyList](https://tinylist.app/), [Simplenote](https://simplenote.com/), [SilentNotes](https://www.martinstoeckli.ch/silentnotes/) / [Github](https://github.com/martinstoeckli/SilentNotes), [Standard Notes](https://standardnotes.com/), [QOwnNotes](https://www.qownnotes.org/), [TiddlyWiki](https://tiddlywiki.com/), [Idaesbasic](https://www.github.com/BenHerbst/idaesbasic), [To-Do_App](https://github.com/BigFloppa404/To-Do_App), [Zim Wiki](https://zim-wiki.org/), [Glory Todo Desktop](https://github.com/yessGlory17/glory_todo_desktop), [TickTick](https://www.ticktick.com/), [OpenToDoList](https://gitlab.com/rpdev/opentodolist), [Laverna](https://laverna.cc/), [wikidPad](http://wikidpad.sourceforge.net/), [Turtl](https://turtlapp.com/), [tomboy-ng](https://github.com/tomboy-notes/tomboy-ng), [FromScratch](https://fromscratch.rocks/), [Taskwarrior](https://taskwarrior.org/), [Super Productivity](https://super-productivity.com/), [Rnote](https://github.com/flxzt/rnote), [Fokus](https://fokus-website.netlify.app/), [Planner](https://useplanner.com/), [ToDo R](https://todo-r.com/), [rebel](https://github.com/kumarasinghe/rebel), [NotesMan](https://github.com/OnlyDeLtA/NotesMan/), [Notesnook](https://notesnook.com/), [Write Solo](https://writesolo.com/), [Wri.pe](https://wri.pe/), [Columns](https://columns.app/), [Zenkit](https://zenkit.com/en/suite/), [Vikunja](https://vikunja.io/), [Lorien](https://github.com/mbrlabs/Lorien), [tuxBoard](https://gitlab.com/graele84/tuxboard), [Google keep](https://www.google.com/keep/), [PrimePad](https://primapad.com/), [ZippyJot](https://www.zippyjot.com/), [MemOnNotepad](https://www.memonotepad.com/), [Skiff](https://skiff.org/, [ToDoZero](https://todozero.com/), [DoNotes](https://donotes.co.uk/), [notely](https://github.com/yeukfei02/notely)

**Android To-Do Apps**

[Tasks](https://tasks.org/), [Any.do](https://www.any.do/), [Simpletask](https://f-droid.org/en/packages/nl.mpcjanssen.simpletask), [Orgzly](https://github.com/orgzly/orgzly-android), [Dailly](https://github.com/hydroxion/dailly/)

***

#### Nuke Anything

[Firefox](https://addons.mozilla.org/en-US/firefox/addon/nuke-anything-enhanced/) / [Chrome](https://chrome.google.com/webstore/detail/nuke-anything/ghoehocgoliemjdnbjjcaohgofgpkfgg)

***

#### Office Suites

* **[Microsoft Office DL Guides](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/base64#wiki_microsoft_office_dl_guides)** / [Download](https://tb.rg-adguard.net/public.php) / [Hot Keys](https://i.imgur.com/PE7l9NB.png)
* [LibreOffice](https://www.libreoffice.org/)
* [FreeOffice](https://www.freeoffice.com/en/)
* [Office Tool Plus](https://otp.landian.vip/en-us/)
* [ClickUp](https://clickup.com/)
* [SSuite](https://www.ssuitesoft.com/software/ssuiteexcalibur.htm) 
* [OpenOffice](https://www.openoffice.org)
* [ArcaneOffice](https://arcaneoffice.com/)
* [WPS](https://www.wps.com/)
* [Calligra](https://calligra.org/) 
* [OnlyOffice](https://personal.onlyoffice.com/) - Online Office Suite
* [Office 365 Activators](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/storage#wiki_onedrive_generators)
* [OfficeRTool](https://forums.mydigitallife.net/threads/how-to-support-chat-office-c2r-download-install-activation.62571/) - Office 2016 Activation Tool 

***

#### Onedrive Generators 

* Note these also activate Office 365
* **[https://a1_free365.a1od.workers.dev/](https://a1_free365.a1od.workers.dev/)**
* [free365](https://github.com/KusakabeSi/free365) - Index
* https://xkx.me/
* https://a1.zxd.workers.dev/
* [https://a1_sc.a1od.workers.dev/](https://a1_sc.a1od.workers.dev/)
* https://azzzzzz.lx.workers.dev/
* http://free.stulive.com/
* https://a1.lx.workers.dev/
* https://teams.xkx.me/
* https://od.wasonliu.workers.dev/
* https://onedrive.gdrive.vip/
* https://a1p.xkx.me/
* https://tb.mygindex.workers.dev/
* [https://a1_sc.a1od.workers.dev/#form](https://a1_sc.a1od.workers.dev/#form)
* https://free.kits.workers.dev/#mdui-dialog
* https://freems.1ove.club/ceo/
* https://ms.jim9527.workers.dev/#form
* [90 Day Trial](https://developer.microsoft.com/en-us/microsoft-365/dev-program)

***

#### Online Audio Editors

**[Audioalter](https://audioalter.com/)**, [Wavvy]( https://wavvy.app/), [AudioStudio](https://www.redcoolmedia.net/web-browser-extension-utilities/audio-editor-audiostudio-chrome-firefox-extension), [Audiotool](https://www.audiotool.com/), [SoundTrap](https://www.soundtrap.com/), [BeepBox](https://www.beepbox.co/), [Efflux](https://www.igorski.nl/application/efflux/), [TwistedWave](https://twistedwave.com/online), [AudioToolSet](https://audiotoolset.com/), [OnlineToneGenerator](https://onlinetonegenerator.com/), [AFreeStudio](https://www.afreestudio.com/), [safeaudiokit](https://safeaudiokit.com/)

***

#### Open Directory Search String Builder

[strixx](https://strixx.now.sh/), [lendx](http://lendx.org/), [eyeofjustice](https://www.eyeofjustice.com/od/), [lumpysoft](https://lumpysoft.com/), [opendirsearch](https://opendirsearch.abifog.com/), [Ewasion](https://ewasion.github.io/opendirectory-finder/), [Palined](http://palined.com/search/), [filechef](https://www.filechef.com/), [doyouneedmorehdd](https://doyou.needmorehdd.space/#), [FonetAsk](http://www.fonetask.com/), [Reecemercer](https://open-directories.reecemercer.dev/), [giitit](http://www.giitit.com/), [odfinder](https://odfinder.github.io/), [thuvien](https://thuvien.com/)

***

#### Open Source Intelligence Indexes

**[Awesome OSINT](https://github.com/jivoi/awesome-osint)**, **[AsINT_Collection](https://start.me/p/b5Aow7/asint_collection)**, [OSINT Framework](https://osintframework.com/), [OSINT Essentials](https://www.osintessentials.com/), [OSINT Collection](https://github.com/Ph055a/OSINT_Collection), [OSINT Sources](https://github.com/imuledx/OSINT_sources), [Investigator Tools](https://start.me/p/gyaOJz/investigator-tools), [OSINT Recherche](https://atlas.mindmup.com/digintel/digital_intelligence_training/index.html), [Open Source Intelligence](https://start.me/p/gy0NXp/open-source-intelligence-osint), [geoint](https://start.me/p/W1kDAj/geoint), [OSINT Tools](https://start.me/p/wMdQMQ/tools), [Sector035](https://sector035.nl/links), [Nixintel's OSINT](https://start.me/p/rx6Qj8/nixintel-s-osint-resource-list), [datajournalism-resources](https://github.com/r3mlab/datajournalism-resources/blob/master/README.md), [UK-OSINT](https://www.uk-osint.net/index.html), [OSINTGeek](https://osintgeek.de/tools), [Awesome-Telegram-OSINT](https://github.com/ItIsMeCall911/Awesome-Telegram-OSINT), [Hackers Arise OSINT](https://www.hackers-arise.com/osint), [osint.link](https://osint.link/), [osinttechniques](https://www.osinttechniques.com/osint-tools.html), [Ressources](https://github.com/tzkuat/Ressources/blob/master/OSINT.md), [whatisosint](https://securitytrails.com/blog/what-is-osint-how-can-i-make-use-of-it), [osintdojo](https://www.osintdojo.com/resources/), [300m](https://300m.com/osint/), [einvestigator](https://www.einvestigator.com/open-source-intelligence-tools/), [researchclinic](http://researchclinic.net/), [toddington](https://www.toddington.com/resources/tii-free-resources-knowledge-base/), [reuser](http://rr.reuser.biz/), [booleanstrings](https://booleanstrings.com/tools/), [coreysdigs](https://www.coreysdigs.com/take-action/must-have-tools-for-digging-videos-podcasts/), [Bellingcat](https://docs.google.com/spreadsheets/d/18rtqh8EG2q1xBo2cLNyhIDuK9jrPGwYr9DI2UncoqJQ/), [cProject Owl](https://discord.gg/projectowl), [RedTeam-Resources](https://github.com/J0hnbX/RedTeam-Resources), [Quick_OSINT_bot](https://t.me/Quick_OSINT_bot), [Awesome Forensics Tools](https://github.com/ivbeg/awesome-forensicstools)

***

#### OS Emulators

* **[Computers Offline](https://dinopirate06.wixsite.com/dynopirate)** - OS Emulator Index
* [Qemu](http://www.qemu-project.org/) - OS Emulator & Virtualization / [iOS Emulator](https://github.com/TrungNguyen1909/qemu-t8030)
* [copy.sh](https://copy.sh/v86/), [OnWorks](https://www.onworks.net/), [simone.computer](https://simone.computer/#/webdesktops), [Hyper-V](https://docs.microsoft.com/en-us/virtualization/hyper-v-on-windows/) or [Virtual Desktop](http://www.virtualdesktop.org/) - Multiple OS Emulators
* [WinXP.now](https://winxp.now.sh/ or [WinXP](https://winxp.vercel.app/) - Windows XP Browser Emulator
* [EmuOS](https://emupedia.org/beta/emuos/), [2](https://emupedia.net/beta/emuos/), [3](https://emuos.net/beta/emuos/), [4](https://emuos.org/beta/emuos/) - Windows 95, 98 & ME Emulator
* [98.js](https://98.js.org/), [Rahul](https://rahul.io/) or [Packard Belle](https://packard-belle.netlify.com/) - Windows 98 Emulator
* [Windows96.net](https://windows96.net/) - Windows 96 Browser Emulator
* [Win95](https://win95.ajf.me/) - Windows 95 Browser Emulator 
* [Windows93](http://www.windows93.net/) - Windows 93 Browser Emulator / Games
* [EmuOS](https://github.com/Emupedia/emupedia.github.io/) - Run Classic Games / Apps In Browser 
* [Windows 1.01](https://classicreload.com/Windows-1-01.html) - Windows 1.01 Browser Emulator 
* [RebornXP](https://rebornxp.js.org/) - Windows XP Browser Emulator
* [SilveOS](https://www.silveos.com/), [AaronOS](https://aaronos.dev/), [Whimsy](https://whimsy.space/), [OS.JS](https://www.os-js.org/), [X-WebDesktop](https://oxoyo.co/X-WebDesktop-Vue/) or [jQuery Desktop](https://desktop.sonspring.com/) - OS Browser Emulator
* [PCE Macplus](https://jamesfriend.com.au/pce-js/pce-js-apps/) - MacOS Browser Emulator 
* [PCE.js](https://jamesfriend.com.au/pce-js/ibmpc-games/) - PCDOS 5 Emulator 
* [Quantum Playground](http://www.quantumplayground.net/) - Quantum Computer Simulator
* [Win11.vercel](https://win11.vercel.app/), [BlueEdge](https://win11.blueedge.me/), [Rajaniraiyn](https://rajaniraiyn.github.io/windows11/) or [Win11 in React](https://win11.blueedge.me/)/ [GitHub](https://github.com/blueedgetechno/win11React) - Online Windows 11 Emulator
* [daedalOS](https://dustinbrett.com/) - Online Windows 10 Emulator
* [felixrieseberg](https://github.com/felixrieseberg/macintosh.js/) - Mac Emulator
* [DistroTest](https://distrotest.net/) or [JSLinux](https://bellard.org/jslinux/) - Linux Browser Emulator

***

#### Panic Button

[Firefox](https://addons.mozilla.org/en-US/firefox/addon/panic-button/) / [Edge](https://microsoftedge.microsoft.com/addons/detail/panic-button/diijhljenjjfegglhjlehppiengdadcb) / [Opera](https://addons.opera.com/en/extensions/details/hide-tabs-panic-button/)

***

#### Password Managers

* **[KeePass](https://keepass.info/)** - [Ports](https://keepass.info/download.html), [2](https://keepassxc.org/) / [Plugins](https://keepass.info/plugins.html) / [Read-Only Functionality](https://subdavis.com/Tusk/) / [CLI](https://github.com/rebkwok/kpcli)
* **[Bitwarden](https://bitwarden.com/)** - [bitwarden_gcloud](https://github.com/dadatuputi/bitwarden_gcloud) / [Server](https://github.com/dani-garcia/vaultwarden) / [GUI](https://github.com/Sife-ops/dmenu_bw)
* [LessPass](https://lesspass.com/)
* [Buttercup](https://buttercup.pw/)
* [Clipperz](https://clipperz.is/)
* [Passman](https://passman.cc/) - [GitHub](https://github.com/nextcloud/passman)
* [KeeWeb](https://keeweb.info/) - [Github](https://github.com/keeweb/keeweb)
* [Spectre](https://spectre.app/)
* [Firefox Lockwise](https://www.mozilla.org/en-US/firefox/lockwise/)
* [UPM](http://upm.sourceforge.net/)
* [Zoho](https://www.zoho.com/vault/)
* [KeepSafe](https://github.com/imshawan/keepsafe-passwordmanager/) - 
* [Password Safe](https://www.pwsafe.org/) or [KDE Wallet Manager](https://userbase.kde.org/KDE_Wallet_Manager) - Password Managing Software 
* [TeamPass](https://teampass.net/) - Collaborative Password Manager 
* [Passbolt](https://www.passbolt.com/) or [PSONO](https://psono.com/) - Self-Hosted Password Manager

***

#### Password-Protected Bookmarks

[Firefox](https://addons.mozilla.org/en-US/firefox/addon/webext-private-bookmarks/), [Chrome](https://chrome.google.com/webstore/detail/private-bookmarks/cbheenbihjdgbmbogbefcgnpfoflhnhl)

***

#### Password Data Breach Check

**[HaveIBeenPwned PW](https://haveibeenpwned.com/Passwords)**, [Intelligence X](https://intelx.io/), [psbdmp](https://psbdmp.ws/), [Dehashed](https://dehashed.com/) or [Spycloud](https://spycloud.com/), [PasswordSearchBot](https://t.me/PasswordSearchBot), [ScatteredSecrets](https://scatteredsecrets.com/)

***

#### Pastebins

**[Pastebin Search](https://cse.google.com/cse?cx=0cd79b819f26af9d0)**, **[Rentry](https://rentry.co/)** / [CLI](https://github.com/radude/rentry), **[Dr.Graph](https://drgraph.cf/)** / [API](https://drgraph.cf/api), **[disroot](https://bin.disroot.org/)**, [TextBin](https://textbin.xyz/), [PrivateBin](https://privatebin.info/directory/), [paste](https://paste.ee/), [JustPaste.it](https://justpaste.it/), [pst.moe](https://pst.moe/), [ZeroBin](http://www.zerobinqmdqd236y.onion/), [Hastebin](https://hastebin.com/), [paste2](https://paste2.org/), [pastelinks](https://pastelink.net/), [anonpaste](https://anonpaste.org/), [paste.shitpost](https://paste.shitpost.to/), [bin.idrix](https://bin.idrix.fr/), [zerobin](https://zerobin.net/), [teknik](https://paste.teknik.io/), [ghostbin](https://ghostbin.com/), [cryptobin](https://cryptobin.co/), [p.ip.fi](https://p.ip.fi/), [paste.mozilla](https://paste.mozilla.org/), [paste.ubuntu](https://paste.ubuntu.com/), [pastebin](https://pastebin.com/), [telegra.ph](https://telegra.ph/), [blackhost](https://blackhost.xyz/?id=pst), [protectedtext](https://www.protectedtext.com/), [Cl1p](https://cl1p.net/), [shortbin](http://bin.shortbin.eu:8080/), [sicp](https://sicp.me/), [throwbin](https://throwbin.in/), [dpaste](https://dpaste.com/), [copydock](https://copydock.vercel.app/paste), [riseup pad](https://pad.riseup.net/), [tempaste](https://tempaste.com/), [zPaste](https://zpaste.net/), [bitbin](https://bitbin.it/), [pastes.io](https://pastes.io/), [cyberdrop bin](https://bin.cyberdrop.me/), [fssquad](https://share.fssquad.com/), [txt](https://txt.fyi/), [peeplink](https://peeplink.in/), [controlc](https://controlc.com/), [katb](https://katb.in/), [paaster](https://paaster.io/), [trushbin](https://trushbin.com/), [nopaste](https://nopaste.ml/), [pastery](https://www.pastery.net/), [privatebin](https://privatebin.net/), [pastebin.pl](https://pastebin.pl/, [paste.gg](https://paste.gg/), [bpa](https://bpa.st/), [0bin](https://0bin.net/), [Spectre](https://pst.klgrth.io/), [pastehub](https://pastehub.net/), [bin](https://bin.gy/), [paste.fo](https://paste.fo/)

***

#### PDF Editors / Toolkits

**Sites**

**[Sejda](https://www.sejda.com/)**, [iLovePDF](https://www.ilovepdf.com/), [Smallpdf](https://smallpdf.com/), [PDF24](https://tools.pdf24.org/en/), [PDFCandy](https://pdfcandy.com/), [SodaPDF](https://online.sodapdf.com/), [PDFonFly](https://pdfonfly.com/), [PDFShelter](https://pdfshelter.com/), [DocHub](https://dochub.com/), [PDFRedizer](https://www.pdfresizer.com/), [PDFRock](https://pdfrock.com/), [FreePDFConvert](http://www.freepdfconvert.com/), [pdf.online](https://pdf.online/), [LightPDF](https://lightpdf.com/), [DeftPDF](https://deftpdf.com/), [AvePDF](https://avepdf.com/), [YupDocs](https://yupdocs.com/), [PDF2Go](https://www.pdf2go.com/), [CleverPDF](https://www.cleverpdf.com/), [PDF4Me](https://www.pdf4me.com/), [PDFForge](https://tools.pdfforge.org/), [MyPDFTools](https://mypdftools.com/), [chromePDF](https://chromepdf.com/), [PDFYeah](https://www.pdfyeah.com/), [EasePDF](https://www.easepdf.com/all-pdf-tools/), [PDFZorro](https://www.pdfzorro.com/), [PDFConverterOnline](https://www.pdfconvertonline.com/)

**Programs** 

**[Acrobat Pro](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/base64#wiki_acrobat_pro)**, [PDFTK](https://www.pdflabs.com/tools/pdftk-the-pdf-toolkit/), [xPDFReader](http://www.xpdfreader.com/), [PDFBox](https://pdfbox.apache.org/), [PDFescape](https://www.pdfescape.com/), [OpenPDF](https://github.com/LibrePDF/OpenPDF), [PDFedit](http://pdfedit.cz/en/index.html), [PDFSharp](http://www.pdfsharp.net/), [PDFSam](https://pdfsam.org/), [Poppler](https://blog.alivate.com.au/poppler-windows/), [PDFCore](https://www.pdfcore.com/), [PDFEraser](https://www.pdferaser.net/), [PDFShaper](https://www.pdfshaper.com/), [PoDoFo](https://sourceforge.net/projects/podofo/), [pdftkb](http://www.angusj.com/pdftkb/), [pdf.online](https://pdf.online/integration), [pdf-analyzer](https://pdf-analyzer.com/mdownloads.html), [PDF Forge](https://www.pdfforge.org/), [PDFInsider](https://pdfinsider.com/), [PDFChef](https://pdfchef.com/online-pdf-tools.html), [Didier Stevens PDF Tools](https://blog.didierstevens.com/programs/pdf-tools/) (CLI)

***

#### Periodic Tables

[Periodic Stats](https://periodicstats.com/), [The Periodic Table Of Elements](https://periodictableofchemicalelements.com/), [Periodic Table](https://periodic-table.io/), [Images-Of-Elements](https://images-of-elements.com/), [Graph Overflow](https://graphoverflow.com/graphs/3d-periodic-table.html), [3D Periodic Table](https://artsexperiments.withgoogle.com/periodic-table/), [PeriodicTableApp](https://periodictableapp.com/), [Periodic Table](https://www.periodic-table.org/), [Ptable](https://ptable.com/)

***

#### Persian Video Download

* These sites host both Persian and English videos. Use [Translator](https://addons.mozilla.org/en-US/firefox/addon/traduzir-paginas-web/).
* [AIOFilm](https://aiofilm.com/) - Movies / TV / Anime
* [DigiMoviez](https://digimoviez.com/) - Movies / TV 
* [PlayStop](https://playstop.ir/) - Movies / TV 

***

#### Personal Link Homepages 

[Ichi](https://ichi.city), [Linktree](https://linktr.ee/), [Beacon](https://beacons.ai/), [MyURLs](https://myurls.co/), [Carrd](https://carrd.co/), [Bio.link](https://bio.link/), [FlowCode](https://www.flowcode.com/page), [Solo.to](https://solo.to/), [Ayo.so](https://ayo.so/), [CreatorSites](https://creatorsites.net/), [ContactInBio](https://www.contactinbio.com/), [Campsite](https://campsite.bio/, [bizzl.ink](https://bizzl.ink/), [Horizon](https://hrzn.bio/)

***

#### Plagiarism Detection

[Grammarly Plagiarism Checker](https://www.grammarly.com/plagiarism-checker), [PaperRater](https://www.paperrater.com/), [Quetext](https://www.quetext.com/), [PlagiarismDetector](http://www.plagiarismdetector.net/), [CopyScape](https://www.copyscape.com/), [PLText](https://pltext.com/), [plagscan](https://www.plagscan.com/), [plagiarismchecker](https://www.plagiarismchecker.co/), [duplichecker](https://www.duplichecker.com/), [writer](https://writer.com/plagiarism-checker/), [unicheck](https://unicheck.com/), [plagiarismsearch](https://plagiarismsearch.com/), [plagiarismcheckerx](https://plagiarismcheckerx.com/), [onlineplagiarismchecker](https://onlineplagiarismchecker.net/), [copyleaks](https://copyleaks.com/), [plagiarismchecker](https://1text.com/plagiarismchecker), [plagium](https://www.plagium.com/) 

***

#### Piracy Site Proxies

[Unblockit](https://unblockit.tv/) / [2](https://unblockit.pages.dev/) / [3](https://unblock_it.gitlab.io/site/) / [4](https://unblockit.how/) / [5](https://unblockit.llc/) / [6](https://unblockit.how/) / [7](https://unblockit.blue/) / [8](https://unblockit.dev/) / [9](https://unblockit.bet/) / [/r/Unblockit](https://www.reddit.com/r/Unblockit/), [Knaben's Proxy List](https://knaben.info/), [nocensor](https://nocensor.biz/), [TorrentMirror](https://www.torrentmirror.net/#proxy-list-container), [unblockninja](https://unblockninja.com/), [uProxy](https://uproxy.to/), [unblocktorrent](https://unblocktorrent.com/), [TorrentBay](https://torrentbay.to/), [unblock.soy](https://unblock.soy/) / [2](https://en-proxy.com/) / [3](https://unb.how/), [piracyproxy](https://piracyproxy.page/), [unblockedfor](https://unblockedfor.me/), [proxybit](https://proxybit.sbs/) / [2](https://www.unblocknow.surf/) / [3](https://www.unbl4you.cyou/) / [4](https://123unblock.world/) / [5](https://mrunblock.bar/) / [6](https://g3g.fun/), [unblocksource](https://unblocksource.net/), [dirproxy](https://dirproxy.cc/), [unblockproject](https://unblockproject.org/)

***

#### Poll Sites 

[PollCode](https://pollcode.com/), [YoPolls](https://www.yopolls.com/), [Polls.fr](https://polls.fr/), [minipoll](https://minipoll.co/), [PickVote](https://pickvote.web.app/), [StrawPoll](https://strawpoll.com/), [framadate](https://framadate.org/), [mobpoll](https://quick.mobpoll.org/), [polltab](https://www.polltab.com/), [voteupapp](https://voteupapp.com/), [polling-app](https://xoyondo.com/polling-app), [star.vote](https://star.vote/), [poal.me](https://poal.me/), [poll.ly](https://poll.ly/), [matepoll](https://www.matepoll.com/index.html), [typeform](https://typeform.com/examples/polls/)

**Live Polling Apps**

[sli.do](https://www.sli.do/), [Feedbackr](https://www.feedbackr.io/), [Trypingo](http://trypingo.com/) 

***

#### Popup Blocker Links

[Popupblocker All](https://addons.mozilla.org/en-US/firefox/addon/popupblockerall/), [Popup Blocker Strict](https://add0n.com/popup-blocker.html) / [GitHub](https://github.com/schomery/popup-blocker), [PopUpOFF](https://romanisthere.github.io/PopUpOFF-Website/index.html), [PopupBlocker](https://github.com/AdguardTeam/PopupBlocker), [Popup & Script Blocker Ultimate](https://popupblocker.ir/), [Poper Blocker](https://poperblocker.com/)

***

#### Portable Apps

[Portapps](https://portapps.io/), [FC Portables](https://www.fcportables.com/), [Portable Freeware](https://www.portablefreeware.com/), [TheHouseOfPortable](https://thehouseofportable.com/), [Windows Portable Apps](https://windowsportableapps.blogspot.com/), [PortableApps](https://portableapps.com/), [Aurelitec](https://www.aurelitec.com/), [Portable4PC](https://portable4pc.com/), [PortableAppZ](https://portableappz.blogspot.com/)

***

#### Portuguese Browser Games

* https://www.clickjogos.com.br/
* https://www.jogos360.com.br/
* https://www.netjogos.com/
* https://www.papajogos.com.br/
* https://www.1001jogos.pt/
* https://www.brincar.pt/
* https://www.jogosde2.com.br/
* http://www.querojogar.com.br/
* https://www.tucajogos.com.br/
* https://lagged.com.br/
* https://www.jogosonlinewx.com.br/

***

#### Portuguese Bibles

* https://www.bibliaon.com/
* https://bo.net.br/
* https://www.bibliacatolica.com.br/
* https://bibliaestudos.com/
* https://novabiblia.com.br/
* https://claret.org.br/biblia
* https://biblia.sbb.org.br/
* https://www.bibliaonline.com.br/
* http://www.receitas-portuguesas.com/
* https://www.jw.org/pt/biblioteca/biblia/biblia-de-estudo/livros/
* https://www.dicionariodenomesproprios.com.br/
* https://www.oracaoefe.com.br/biblia-online/
* [bibliasagradamulher](https://play.google.com/store/apps/details?id=br.com.tunglabs.bibliasagrada.mulher&hl=pt_BR&gl=US) - Bible App

***

#### Portuguese Dictionaries / Thesaurus

* https://dicionario.priberam.org/
* https://michaelis.uol.com.br/
* https://aulete.com.br/
* https://www.lexico.pt/
* https://www.dicio.com.br/
* https://dicionariocriativo.com.br/
* https://www.significados.com.br/
* https://www.significadosesinonimos.com.br/
* https://www.sonhos.com.br/
* https://sonhar.info/
* https://www.sonhosbr.com.br/
* https://www.significadodesonhos.net/
* http://www.achando.info/
* https://conceito.de/
* https://www.dicionariodesimbolos.com.br/
* http://significadodossimbolos.com.br/
* https://www.simbolos.net.br/
* https://www.dicio.com.br/
* https://www.simbolos.com.br/
* https://www.significadodascores.com.br/
* https://www.dicionario-sinonimo.com/
* https://sinonimos-online.com/
* https://www.sol.eti.br/index.html
* https://www.dicionarioinformal.com.br/ (Slang)
* https://www.politize.com.br/dicionario/ (Political)
* https://dicionariojuridico.online/ (Legal)
* http://dicionariomineires.com.br/ (Mining)
* https://www.dicionariofinanceiro.com/ (Financial)
* https://dicionarioindigena.blogspot.com/ (Indigenous)
* https://www.antonimos.com.br/ (Antonyms)
* https://www.sinonimos.com.br/ (Thesaurus)
* https://sinonimos.woxikon.pt/ (Thesaurus) 
* https://www.dicionarioetimologico.com.br/ (Etymologies)
* https://www.conjugacao.com.br/ (Verb Conjugations)

***

#### Portuguese Grammar Tips & Lessons 

* https://portuguesaletra.com/
* https://gramaticaonline.com.br/
* http://www.blogdogramaticando.com/
* https://showdegramatica.blogspot.com/
* https://www.portugues.com.br/
* https://www.soportugues.com.br/
* https://www.gramatica.net.br/
* https://grammarnet.com/

***

#### Portuguese Recipes

[amandocozinhar](https://www.amandocozinhar.com/2016/01/12-livros-de-culinaria-para-baixar.html), [Uniao](https://uniao.com.br/), [varandadobolo](https://varandadobolo.com.br/), [receitasdemais](http://receitasdemais.com.br/), [receitasnotadez](https://receitasnotadez.com.br/), [saborintenso](https://www.saborintenso.com/), [cozinhadonabenta](https://www.cozinhadonabenta.com.br/receitas-dona-benta/), [anamariabraga](https://anamariabraga.globo.com/), [vovopalmirinha](https://vovopalmirinha.com.br/), [gastronomias](http://www.gastronomias.com/receitas/), [tecnonoticias](https://tecnonoticias.com.br/downloads-de-receitas/), [tudoreceitas](https://www.tudoreceitas.com/), [tudogostoso](https://www.tudogostoso.com.br/), [receitasnestle](https://www.receitasnestle.com.br/), [panelinha](https://www.panelinha.com.br/), [receitasdecomida](https://www.receitasdecomida.com.br/), [cybercook](https://cybercook.com.br/), [culinaria](https://culinaria.terra.com.br/), [petiscos](https://www.petiscos.com/), [receitaseduguedes](https://www.receitas.eduguedes.com.br/), [teleculinaria](https://www.teleculinaria.pt/), [dietaereceitas](https://dietaereceitas.com.br/), [receitasdecomidas](https://www.receitasdecomidas.com.br/), [gastronomianobrasil](http://gastronomianobrasil.com.br/), [iserv](http://www.iserv.com.br/culinaria/), [receiteria](https://www.receiteria.com.br/), [comidasimples](https://comidasimples.com.br/), [receitasagora](https://www.receitasagora.com.br/), [cantinhovegetariano](http://www.cantinhovegetariano.com.br/), [Emagrecer](https://emagrecercerto.com/)

***

#### Presentation Tools

[ZoomIt](https://docs.microsoft.com/en-us/sysinternals/downloads/zoomit), [Presentator](https://presentator.io/), [Carnac](http://code52.org/carnac/), [Presen](https://presen-vid.com/), [mentimeter](https://www.mentimeter.com/), [beautiful.ai](https://www.beautiful.ai/), [Fusuma](https://hiroppy.github.io/fusuma/), [Pitch](https://pitch.com/), [Deckdeckgo](https://deckdeckgo.com/), [Zoho Show](https://www.zoho.com/show/), [Webslides](https://webslides.tv/), [Desk](https://www.animaker.com/deck), [Slides](https://slides.com/), [FreeShow](https://freeshow.app/)

* [ScreenRec](https://screenrec.com/) - Screen Presentation Tool
* [Slides](http://maaslalani.com/slides/) - Terminal Presentation Tool / [GitHub](https://github.com/maaslalani/slides)

**Presentation Templates**

[SlidesGo](https://slidesgo.com/), [Showeet](https://www.showeet.com/), [Slides Carnival](https://www.slidescarnival.com/), [SlideShareDownloader](https://slidesharedownloader.ngelmat.net/), [PresentationGO](https://www.presentationgo.com/), [ensa.io](https://ensa.io/), [ThePOPP](https://thepopp.com/)

***

#### Proxy Lists

**[PROXY List](https://github.com/TheSpeedX/PROXY-List)**, [Free-Proxy-List](https://free-proxy-list.net/), [Proxy-Daily](https://proxy-daily.com/), [Cool-Proxy](https://www.cool-proxy.net/), [Proxy-List](https://github.com/Volodichev/proxy-list) / [Telegram](https://t.me/proxy4parsing), [OpenProxyList](https://github.com/roosterkid/openproxylist), [ProxyScrape](https://www.proxyscrape.com/free-proxy-list), [proxy-list](https://github.com/mmpx12/proxy-list), [hide.my proxy list](https://hidemy.name/en/proxy-list/), [FreeProxyLists](https://www.freeproxylists.net/), [ProxyNations](https://www.proxynations.com/), [spys.one](https://spys.one/en/free-proxy-list/), [premproxy](https://www.premproxy.com/list/), [cyber-gateway](https://cyber-gateway.net/get-proxy/free-proxy), [ree-proxy-list](https://free-proxy-list.net/web-proxy.html), [geonode](https://geonode.com/free-proxy-list/), [web-proxylist](http://free-proxy.cz/en/web-proxylist)

***

#### Print Edit WE

[Firefox](https://addons.mozilla.org/en-US/firefox/addon/print-edit-we/) / [Chrome](https://chrome.google.com/webstore/detail/print-edit-we/olnblpmehglpcallpnbgmikjblmkopia)

***

#### Privacy Based Browsers 

**Multi-Platform**

[Hexavalet](https://github.com/Hexavalent-Browser/Hexavalent), [Librewolf](https://gitlab.com/librewolf-community/browser/windows) / [2](https://librewolf.net/), [Librefox](https://github.com/intika/Librefox/), [Netsurf](https://www.netsurf-browser.org/), [Wexond](https://github.com/wexond/desktop), [Otter](https://otter-browser.org/), [BadWolf](https://hacktivis.me/projects/badwolf), [Sphere](https://sphere.tenebris.cc/), [dumb-browser](https://github.com/f32by/dumb-browser), [Breeze](https://github.com/privacyone/breeze-core), [Dot HQ](https://www.dothq.co/) / [Discord](https://invite.gg/dot), [Viper-Browser](https://github.com/LeFroid/Viper-Browser)

**Android**

[Mull](https://divestos.org/fdroid/official?fingerprint=E4BE8D6ABFA4D9D4FEEF03CDDA7FF62A73FD64B75566F6DD4E5E577550BE8467), [DuckDuckGo Privacy Browser](https://duckduckgo.com/app), [BiscuitBrowser](https://github.com/CookieJarApps/BiscuitBrowser), [SmartCookieWeb](https://smartcookieweb.com/), [2](https://github.com/CookieJarApps/SmartCookieWeb-preview) / [YTDL](https://github.com/CookieJarApps/VideoDL), [Privacy Browser](https://f-droid.org/en/packages/com.stoutner.privacybrowser.standard/), [friendly](https://friendly.io/), [InBrowser](https://www.inbrowserapp.com/), [SnapSearch](https://snapsearch.online/), [Mull-Fenix](https://github.com/Divested-Mobile/Mull-Fenix)

***

#### Privacy Guides

[Surveillance Self-Defense](https://ssd.eff.org/), [Defensive Computing Checklist](https://defensivecomputingchecklist.com/), [Security In A Box](https://securityinabox.org/en/), [AvoidTheHack](https://avoidthehack.com/), [Eldritch Data](https://eldritchdata.neocities.org/), [OWASP Cheatsheet](https://cheatsheetseries.owasp.org/index.html), [The Hitchhiker’s Guide](https://anonymousplanet-ng.org/guide.html) / [2](https://raw.githubusercontent.com/Anon-Planet/thgtoa/master/guide.md)

***

#### Privacy Hardened Firefox

* **[user.js Warning](https://i.imgur.com/ZMQJHwC.png)**
* **[ffprofile](https://ffprofile.com/)**
* **[Betterfox](https://github.com/yokoffing/Betterfox)**
* [arkenfox](https://github.com/arkenfox/user.js)
* [pyllyukko](https://github.com/pyllyukko/user.js/)
* [Narsil](https://git.nixnet.services/Narsil/desktop_user.js)
* [Setup Guide](https://brainfucksec.github.io/firefox-hardening-guide) / [Video](https://youtu.be/F7-bW2y6lcI)

***

#### Privacy Tools

**[privacyguides](https://www.privacyguides.org/)**, [Privacy Respecting](https://github.com/nikitavoloboev/privacy-respecting), [Privacy Tools](https://www.privacytools.io/), [Awesome Privacy](https://github.com/pluja/awesome-privacy), [online-tools-for-the-pandemic](https://etherpad.wikimedia.org/p/online-tools-for-the-pandemic), [Privacy Tools List](https://privacytoolslist.com/) / [2](https://chef-koch.bearblog.dev/privacy-tools-list-by-chef-koch/) / [3](https://gitlab.com/ck-s-technology-news/privacy-tools-list-by-cktn), [Snopyta](https://snopyta.org/), [Hostux](https://hostux.network/), [Awesome Security](https://github.com/sbilly/awesome-security), [Security List](https://security-list.js.org/), [Awesome Privacy](https://github.com/KevinColemanInc/awesome-privacy), [Thunix](https://thunix.net/), [Zero Data App](https://0data.app/), [De-google-ify Internet](https://degooglisons-internet.org/en/alternatives/), [Alternative Internet](https://github.com/redecentralize/alternative-internet), [EPIC](https://www.epic.org/privacy/tools.html), [Awesome Windows Security](https://github.com/chryzsh/awesome-windows-security), [Tzkuat Ressources](https://gitlab.com/tzkuat/Ressources), [PrivacySavvy](https://privacysavvy.com/), [The New Oil](https://thenewoil.org/index.html), [awesome-humane-tech](https://github.com/humanetech-community/awesome-humane-tech)

*** 

#### PS4 Roms

* [/r/PkgLinks](https://www.reddit.com/r/PkgLinks/)
* [PKGPS4](https://www.pkgps4.com/)
* [Auctor](https://auctor.tv/) 

***

#### qBitorrent Tools

* [Multi-Connection](https://github.com/qBitMF/qBitMF) / [Screenshot](https://i.imgur.com/CM4H3Jt.png)
* [Plugins](https://github.com/qbittorrent/search-plugins#search-plugins)
* [Enhanced](https://github.com/c0re100/qBittorrent-Enhanced-Edition)
* [Themes](https://github.com/jagannatharjun/qbt-theme) / [Dark Theme](https://draculatheme.com/qbittorrent)
* [iOS Theme](https://github.com/ntoporcov/iQbit/)
* [Docker Build](https://github.com/linuxserver/docker-qbittorrent), [2](https://github.com/binhex/arch-qbittorrentvpn) 
* [Web Client](https://github.com/sobuj53/web_qbittorrent), [2](https://github.com/WDaan/VueTorrent)
* [Mega Upload](https://colab.research.google.com/github/Xavy-13/qbittorrent/blob/main/qBittorrent_MEGA.ipynb)
* [Gdrive Upload](https://colab.research.google.com/github/Xavy-13/qbittorrent/blob/main/qBittorrent.ipynb)
* [API Endpoints](https://rentry.co/qBitEndpoints)

***

#### QR Code Generators

[QR Tiger](https://www.qrcode-tiger.com/), [QRCodeMonkey](https://www.qrcode-monkey.com/), [Logaster](https://www.logaster.com/qr-code-generator/), [qr-code-generator](https://mention.com/en/qr-code-generator/), [amazing-qr](https://github.com/x-hw/amazing-qr), [qr_code_generator](https://www.nirsoft.net/utils/qr_code_generator.html), [QR Code Generator](https://www.the-qrcode-generator.com/), [CodeTwo](https://www.codetwo.com/freeware/qr-code-desktop-reader/)

**Custom QR Code Generators**

[My-Qr.art](https://my-qr.art/), [QRpicture](https://www.qrpicture.com/), [qrcode-generator](https://www.logodesign.net/qrcode-generator)

***

#### Radio Streaming Sites

**[List of Internet Radio Stations](https://en.wikipedia.org/wiki/List_of_Internet_radio_stations)**

**Live Radio** 

[iHeartRadio](https://www.iheart.com/), [Radio.com](https://www.radio.com/stations), [OnlineRadioBox](https://onlineradiobox.com/), [LiveOnlineRadio](https://liveonlineradio.net/), [WebSDR](http://www.websdr.org/), [System Bus Radio](https://fulldecent.github.io/system-bus-radio/), [myTuner](https://mytuner-radio.com/), [Radio Browser](https://www.radio-browser.info/), [Deep Web Radio](http://anonyradixhkgh5myfrkarggfnmdzzhhcgoy2v66uf7sml27to5n2tid.onion/), [Zeno](https://zeno.fm/), [TuneYou](https://tuneyou.com/), [Tvradiotuner](https://tvradiotuner.com/), [Instant.audio](https://instant.audio/), [Radiodeck](https://www.radiodeck.com/), [VRadio](http://www.akouradio.com/), [WorldRadioMap](https://worldradiomap.com/), [Streema](https://streema.com/), [vTuner](https://vtuner.com/setupapp/guide/asp/BrowseStations/startpage.asp), [Radio.net](https://www.radio.net/), [TheOneStopRadio](https://theonestopradio.com/), [Radio Guide](https://www.radioguide.fm/)

**Internet Radio** 

[CoreRadio](https://coreradio.ru/listen), [CMD](https://cmd.to/fm), [lainchan](https://lainchan.org/radio), [JetSetRadio](https://jetsetradio.live/), [LivexLive](https://www.livexlive.com/), [RadioParadise](https://radioparadise.com/), [IndieSHuffle](https://www.indieshuffle.com/), [UpBeat](https://upbeat.pw/), [You42](https://www.you42.com/), [Jango](https://www.jango.com/), [RadioTunes](https://www.radiotunes.com/), [Live365](https://live365.com/), [AccuraRadio](https://www.accuradio.com/), [Radio.dubbeh](https://radio.dubbeh.net/), [lainon.life](https://lainon.life/), [Tilderadio](https://tilderadio.org/), [AnonRadio](https://anonradio.net/), [UpBeat](https://upbeatradio.net/v3/UpBeat.Home) / [Discord](https://upbeat.pw/discord), [Radios.yt](https://radios.yt/), [SomaFM](https://somafm.com/), [ShoutCast](https://directory.shoutcast.com/), [Lain Void](https://lain.void.yt/), [Internet-Radio](https://internet-radio.com/) 

***

#### Random Sites

[StumblingOn](https://stumblingon.com/), [Stumbled](https://stumbled.to/), [BoredButton](https://www.boredbutton.com/), [Sharkle!](https://sharkle.com/), [The Useless Web](https://theuselessweb.com/) / [2](https://theuselessweb.site/), [JumpStick](https://jumpstick.app/), [OpenBulkURL](https://openbulkurl.com/random/), [WebSurfer](https://meow.sadgrl.online/websurfer/), [The Forest](https://theforest.link/), [WhatsMYIP](http://random.whatsmyip.org/), [takeuselesswebsite](http://www.takeuselesswebsite.com/), [Random-Website](https://random-website.com/), [Wilderness Land](https://wilderness.land/)

***

#### Read Paywalled Articles

**[wallabag](https://wallabag.nixnet.services/)**, [Burles](https://burles.co/en/), [Paywall Bypass Index](https://redd.it/rs9ej1), [bypass-paywalls](https://github.com/iamadamdev/bypass-paywalls-chrome#bypass-paywalls), [pocket](https://getpocket.com/), [bypass-paywalls-firefox-clean](https://bitbucket.org/magnolia1234/bypass-paywalls-firefox-clean/src/master/) / [2](https://gitlab.com/magnolia1234/bypass-paywalls-chrome-clean), [12ft](https://12ft.io/), [Hover Paywalls](https://github.com/nathan-149/hover-paywalls-browser-extension), [Demodal](https://github.com/AliasIO/demodal), [medium-unlocker](https://github.com/und3fined/medium-unlocker), [OpenAccessButton](https://openaccessbutton.org/), [RemovePaywalls](https://www.removepaywall.com/)

* [Bypass paywalls for scientific documents](https://greasyfork.org/en/scripts/35521-bypass-paywalls-for-scientific-documents) - Bypass Scientific Document Paywalls 
* [unpaywall](https://unpaywall.org/) - Bypass Scholarly Article Paywalls
* [Medium Unlimited](https://github.com/manojVivek/medium-unlimited) or [Scribe](https://scribe.rip/) - Unlimited Articles on Medium 

***

#### Reddit Alternatives

**[Reddit Alt Index](https://redd.it/oioeot)**, **[Raddle](https://raddle.me/)** / [onion](http://c32zjeghcp5tj3kb72pltz56piei66drc63vkhn5yixiyk4cmerrjtid.onion/), **[Saidit](https://saidit.net/)** [Lemmy](https://lemmy.ml/), [/r/RedditAlternatives](https://reddit.com/r/RedditAlternatives), [notabug](https://notabug.io/), [postmill](https://postmill.xyz/), [Sqwok](https://sqwok.im/), [Ramble](https://ramble.pw/) (Privacy Focused), [Dread](http://dreadytofatroptsdj6io7l3xptbet6onoyno2yv7jicoxknyazubrad.onion/), [kddit](http://kddit.kallist4mcluuxbjnr5p2asdlmdhaos3pcrvhk3fbzmiiiftwg6zncid.onion/), [tildes](https://tildes.net/), [talk](https://www.talk.lol/), [grepless](https://grepless.com/), [communities](https://communities.win/), [20 Things](https://20-things.com/)

***

#### Reddit Desktop Apps

[reditr](http://reditr.com/), [baconit](https://www.microsoft.com/en-us/p/baconit/9wzdncrfj0bc?rtc=1&activetab=pivot:overviewtab), [readit](https://www.microsoft.com/en-us/p/readit/9nblggh189c8?activetab=pivot:overviewtab), [reddit-on-reddhub](https://www.microsoft.com/en-us/p/reddit-on-reddhub/9wzdncrfj9m1?activetab=pivot:overviewtab), [reddplanet](https://www.microsoft.com/en-us/p/reddplanet/9nblggh4s44m?activetab=pivot:overviewtab)

***

#### Reddit Frontends

[xeddit](https://www.xeddit.com/), [Reeddit](https://reedditapp.com/), [libreddit](https://libredd.it/) / [2](https://github.com/spikecodes/libreddit), [Saturnus](https://saturnusapp.com/), [Inccogsnoo](https://incogsnoo.com/), [teddit](https://teddit.net/) / [2](https://codeberg.org/teddit/teddit), [troddit](https://www.troddit.com/), [kddit](https://kddit.kalli.st/)

***

#### Remote Desktop Clients

[Parsec](https://parsec.app/), [RustDesk](https://rustdesk.com/) / [GitHub](https://github.com/rustdesk/rustdesk), [RemoteDesktop](https://remotedesktop.google.com/), [AnyDesk](https://anydesk.com/en), [TeamViewer](https://www.teamviewer.com/en-us/), [NoMachine](https://www.nomachine.com/), [Remmina](https://remmina.org/), [UltraViewer](https://ultraviewer.net/), [SplashTop](https://www.splashtop.com/personal), [MSP360](https://www.msp360.com/remote-desktop/), [Ammyy](https://www.ammyy.com/en/), [Apache Guacamole](https://guacamole.apache.org/), [FreeRDP](https://www.freerdp.com/), [SimpleHelp](https://simple-help.com/), [Myrtille](https://cedrozor.github.io/myrtille/), [Aspia](https://aspia.org/doku.php), [TightVNC](https://www.tightvnc.com/), [getscreen](https://getscreen.me/), [remoteutilities](https://www.remoteutilities.com/), [p2p](https://github.com/miroslavpejic85/p2p), [Pop](https://pop.com/), [UVNC](https://uvnc.com/), [DistantDesktop](https://www.distantdesktop.com/), [RDP](https://github.com/yahya-ait-talb/RDP), [Colab Hacks](https://github.com/PradyumnaKrishna/Colab-Hacks), [ChimeraDesk](https://github.com/morrolinux/ChimeraDesk), [PowerRemoteDesktop](https://github.com/DarkCoderSc/PowerRemoteDesktop), [Lab](https://docs.microsoft.com/en-us/learn/modules/extend-elements-finance-operations/4-exercise?source=learn) or [SharpRDP](https://github.com/0xthirteen/SharpRDP)

***

#### Remove Vocals

[VocalRemover](http://vocalremover.org/) / [GUI](https://github.com/Anjok07/ultimatevocalremovergui) / [2](https://github.com/Anjok07/ultimatevocalremovergui/tree/v5-beta-cml), [PhonicMind](https://phonicmind.com/), [AIVocalRemover](https://aivocalremover.com/), [Ultimate Vocal Remover](https://colab.research.google.com/github/NaJeongMo/Colaboratory-Notebook-for-Ultimate-Vocal-Remover/blob/main/Vocal%20Remover%205_arch.ipynb), [x-minus](https://x-minus.pro/ai), [online-vocal-remover](https://www.notta.ai/en/tools/online-vocal-remover), [VocalRemoverPro](https://vocalremoverpro.com/), [Remove Vocals](https://www.remove-vocals.com/), [vocali](https://vocali.se/en), [voxremover](https://voxremover.com/), [mazmazika](https://www..com/vocalremover), [demixor](https://demixor.com/), [karaoke-maker](http://humtools.com/karaoke-maker/), [mvsep](https://mvsep.com/)

***

#### Restore Classic Google Icons

[Firefox](https://addons.mozilla.org/en-US/firefox/addon/classic-google-icons/), [Chrome](https://chrome.google.com/webstore/detail/restore-old-google-icons/iellnmonjokmoagdlggagdmfjgpiahmb/)

***

#### Resume Makers

**[RX Resume ](https://rx-resume.web.app/)**, [cvmkr](https://cvmkr.com/), [resumonk](https://www.resumonk.com/), [ceev](https://ceev.io/), [creddle](http://creddle.io/), [ineedaresu](https://ineedaresu.me/), [flowcv](https://flowcv.io/), [cv2you](https://cv2you.com/), [cvservant](https://cvservant.com/cv/), [resume-nation](https://resume-nation.github.io/), [sajilocv](https://sajilocv.com/), [resumemaker](https://www.resumemaker.online/), [intelligentcv](https://www.intelligentcv.app/), [cakeresume](https://www.cakeresume.com/), [resumgo](https://www.resumgo.com/), [Reactive Resume](https://rxresu.me/)

***

#### Reverse Image Search

**[Search by Image](https://github.com/dessant/search-by-image)**, [TinEye](https://tineye.com/) / [Extension](https://tineye.com/extensions), [Duplichecker](https://www.duplichecker.com/reverse-image-search.php), [Image Raider](https://infringement.report/api/raider-reverse-image-search/), [ascii2d](https://ascii2d.net/), [iqdb](http://iqdb.org/), [Reverse Image Analyser](https://www.osintcombine.com/reverse-image-analyzer), [same.energy](https://same.energy/), [SauceNao](https://saucenao.com/) / [Extension](https://saucenao.com/tools/), [Yandex Images](https://yandex.com/images/), [VISE](https://www.robots.ox.ac.uk/~vgg/software/vise/), [SmartImage](https://github.com/Decimation/SmartImage), [berify](https://www.berify.com/), [Reverse Image Search](https://www.reverse-image-search.org/), [RevEye](https://github.com/steven2358/reveye), [immerse](https://www.immerse.zone/), [ReverseImageSearch](https://www.reverseimagesearch.com/), [MaxURL](https://qsniyg.github.io/maxurl/)

***

#### Royalty Free Music

[Free Music Archive](https://www.freemusicarchive.org/), [freesoundtrackmusic](https://www.freesoundtrackmusic.com/), [joshwoodward](https://www.joshwoodward.com/), [wowsound](https://wowsound.com/), [epidemicsound](https://www.epidemicsound.com/), [Pixabay Music](https://pixabay.com/music/), [audiomicro](https://www.audiomicro.com/), [Starfrosch](https://starfrosch.com/), [StreamBeats](https://www.streambeats.com/), [Mubert](https://mubert.com/), [ccHound](https://cchound.com/), [MusicScreen](https://www.musicscreen.org/), [FilmMusic](https://www.filmmusic.io/), [FreePD](https://www.freepd.com/), [Fugue](https://icons8.com/music), [EDMRF](https://edmroyaltyfree.net/), [chosic](https://www.chosic.com/free-music/all/), [Anttis Instrumentals](https://www.gamedev.net/news/2000-instrumental-pieces-released-by-anttis-instrumentals-r1135/) / [Torrent](https://drive.google.com/open?id=0ByvAPNATAYsBR0FUczYzWHk3NEU), [Sampld](https://open.sampld.app/), [BLueFoxMusic](https://bluefoxmusic.com/)

***

#### RSS Feed Readers

[FeedReader](http://www.feedreader.com/), [QuiteRSS](https://quiterss.org/), [RSSOwl](http://www.rssowl.org/), [CommaFeed](https://www.commafeed.com/#/welcome), [RSSHub](https://github.com/DIYgod/RSSHub), [spaRSS](https://github.com/Etuldan/spaRSS), [FreshRSS](https://freshrss.org/), [Fluent Reader](https://hyliu.me/fluent-reader/), [Feeder](https://feeder.co/), [The Old Reader](https://theoldreader.com/), [NewsBoat](https://newsboat.org/), [tt-rss](https://tt-rss.org/), [TheFeedReaderBot](https://thefeedreaderbot.com/) (Console), [NewsFlash](https://gitlab.com/news-flash/news_flash_gtk), [Miniflux](https://miniflux.app/), [Photon](https://git.sr.ht/~ghost08/photon), [selfoss](https://selfoss.aditu.de/), [gorss](https://github.com/Lallassu/gorss), [RSS Guard](https://github.com/martinrotter/rssguard), [BringRSS](https://github.com/voussoir/bringrss), [NewsBlur](https://github.com/samuelclay/NewsBlur), [TICKR](https://www.open-tickr.net/), [Osmosfeed](https://github.com/osmoscraft/osmosfeed), [WebFeed](https://taoshu.in/webfeed/turn-browser-into-feed-reader.html)

**Extensions**

[Feedbro](https://nodetics.com/feedbro/), [Brief](https://github.com/brief-rss/brief), [Smart-RSS](https://github.com/SmartRSS/Smart-RSS), [Fraidycat](https://fraidyc.at/)

***

#### Satellite & Street View Maps

**[OrganicMaps](https://organicmaps.app/)**, **[DuckDuckGo](https://duckduckgo.com/?q=maps&ia=web&iaxm=maps)**, [Yandex](https://yandex.com/maps/), [Google](https://www.google.com/maps/), [Satellites.pro](https://satellites.pro/), [Bing](https://www.bing.com/maps), [Wego.Here](https://wego.here.com/), [Terrafly](http://www.terrafly.com/), [EarthExplorer](https://earthexplorer.usgs.gov/), [EarthData](https://search.earthdata.nasa.gov/search), [PortalDeMapas](https://portaldemapas.ibge.gov.br/portal.php#homepage), [Qwant](https://www.qwant.com/maps/), [city2map](https://www.city2map.com/), [Arcane Maps](https://arcanemaps.com/), [MapQuest](https://www.mapquest.com/), [InstantStreetView](https://www.instantstreetview.com/), [ShowMyStreet](https://showmystreet.com/)

***

#### Save Page WE 

[Firefox](https://addons.mozilla.org/en-US/firefox/addon/save-page-we/), [Chrome](https://chrome.google.com/webstore/detail/save-page-we/dhhpefjklgkmgeafimnjhojgjamoafof)

***

#### Scan Files

**[VirusTotal](https://www.virustotal.com/)** / [CLI](https://github.com/VirusTotal/vt-cli), [2](https://virustotal.github.io/vt-cli/) / [Telegram Bot](https://t.me/virus_total_scan_bot) / [Uploader](https://github.com/SamuelTulach/VirusTotalUploader), [Hybrid-Analysis](https://hybrid-analysis.com/), [VirSCAN](https://www.virscan.org/), [Joe Sandbox](https://www.joesandbox.com/), [MetaDefender](https://metadefender.opswat.com/?lang=en), [Fortiguard](https://www.fortiguard.com/faq/onlinescanner), [Jotti](https://virusscan.jotti.org/en), [Virus Desk](https://opentip.kaspersky.com/), [cuckoo](https://cuckoo.cert.ee/), [Antiscan](https://www.antiscan.me/), [MalShare](https://www.malshare.com/)

***

####  Screen Recorders

**[OBS](https://obsproject.com/)** / [Guide](https://youtu.be/7fuFGDFDzUY), [Bandicam](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/base64#wiki_bandicam), [FFmpeg](https://ffmpeg.org/), [Nchsoftware](https://www.nchsoftware.com/capture/), [RecordMyDesktop](http://recordmydesktop.sourceforge.net/about.php), [Screenpresso](https://www.screenpresso.com/), [LiteCam](https://www.litecam.net/en/), [SRERecorder](https://srecorder.com/), [CamStudio](https://camstudio.org/), [EZVid](https://www.ezvid.com/), [Captura](https://mathewsachin.github.io/Captura/), [Kap](https://getkap.co/), [oCam](https://ohsoft.net/eng/ocam/download.php?cate=1002), [WebMCam](https://github.com/michaelmob/WebMCam), [SimpleScreenRecorder](http://www.maartenbaert.be/simplescreenrecorder/), [Kalmuri](https://global.kilho.net/kalmuri/), [Wink](https://www.debugmode.com/wink/), [Vileo](https://lukasbach.github.io/vileo/), [Shar.ec](https://shar.ec/), [Scre.io](https://scre.io/), [Screen Recorder](https://github.com/akon47/ScreenRecorder), [ScreenREC](https://screen-rec.vercel.app/), [RecordCast](https://www.recordcast.com/), [RecordScreen](https://recordscreen.io/), [ScreenApp](https://screenapp.io/), [vokoscreenNG](https://github.com/vkohaupt/vokoscreenNG), [Fluent Screen Recorder](https://github.com/MarcAnt01/Fluent-Screen-Recorder), [Google Screen Recorder](https://toolbox.googleapps.com/apps/screen_recorder/)

**Browser Extensions**

[Screen Recorder](https://mybrowseraddon.com/screen-recorder.html), [Screenity](https://chrome.google.com/webstore/detail/screenity-screen-recorder/kbbdabhdfibnancpjfhlkhafgdilcnji?hl=en), [Nimbus Capture](https://nimbusweb.me/screenshot.php), [Screenshot Capture](https://chrome.google.com/webstore/detail/screenshot-capture/giabbpobpebjfegnpcclkocepcgockkc), [Veed.io](https://chrome.google.com/webstore/detail/screen-webcam-recorder-+/mgipbckfkdcalgbcjmkogjijddnkbecc), [Awesome Screen Recorder](https://chrome.google.com/webstore/detail/awesome-screenshot-and-sc/nlipoenfbbikpbjkfpfillcgkoblgpmj?hl=en) 

***

#### Scroll Anywhere

[Firefox](https://addons.mozilla.org/en-US/firefox/addon/scroll_anywhere/), [Chrome](https://chrome.google.com/webstore/detail/scrollanywhere/jehmdpemhgfgjblpkilmeoafmkhbckhi), [Opera](https://addons.opera.com/en/extensions/details/scrollanywhere/?display=en)

***

#### Scene Release Trackers

* [/r/CrackWatch](https://reddit.com/r/CrackWatch) / [Discord](https://discord.gg/d9StxkknwX)
* [SteamCrackStatus](https://steamcrackedgames.com/) / [Discord](https://discord.com/invite/hrCtqcyHKw)
* [/r/SteamCrackedGames](https://reddit.com/r/SteamCrackedGames)
* [/r/dailyreleases](https://www.reddit.com/r/dailyreleases/)
* [/r/RepackWorld](https://reddit.com/r/RepackWorld)
* [GameStatus](https://gamestatus.info/)
* [fitgirl_repack](https://t.me/fitgirl_repack)

***

#### Searx Instances

[Fuck Off Google](https://search.fuckoffgoogle.net/) / [nixnet](https://searx.nixnet.services/) / [Instance Index](https://searx.space/), [Instance Index 2](https://www.startpage.com/sp/search?q=%22powered%20by%20Searx%22), [searx](https://searx.be/), [tiekoetter](https://searx.tiekoetter.com/)

***

#### Secure Password Generator

[Firefox](https://addons.mozilla.org/en-GB/firefox/addon/secure-password-generator/) / [Chrome](https://chrome.google.com/webstore/detail/secure-password-generator/dapehldnfebpbfpfknddmlhghjlbjhdb?hl=en)

***

#### Send Anonymous Emails

[secure-email](https://www.secure-email.org/), [5ymail](https://www.5ymail.com/), [anonymousemail](https://anonymousemail.me/), [anonymouse](http://anonymouse.org/anonemail.html), [sendanonymousemail](http://www.sendanonymousemail.net/), [send-email](http://send-email.org/), [gilc](http://gilc.org/speech/anonymous/remailer.html), [mytrashmail](http://mytrashmail.com/), [Remailer](https://remailer.paranoici.org/index.php), [MixMaster](http://mixmaster.sourceforge.net/), [mailfreeonline](https://www.mailfreeonline.com/home), [DeadFake](http://deadfake.com/)

***

#### SEO Tools

[CuratedSEOTools](https://github.com/sneg55/curatedseotools), [BulkLink](http://bulklink.org/), [Cliper](https://www.cliper.site/), [websiterankpro](https://www.websiterankpro.com/), [SEO Tools Apps](https://www.seotoolsapps.com/), [SEOCheckFree](https://seocheckfree.com/), [busywithseo](http://busywithseo.com/), [seowagon](http://seowagon.com/), [seotoolnetwork](http://seotoolnetwork.com/), [smallseotoolz](https://smallseotoolz.net/), [smartseotools](http://smartseotools.org/), [seotoolstation](http://seotoolstation.com/), [99WebTools](https://99webtools.com/), [SmallSEOTools](https://smallseotools.com/), [seochecker](https://www.seochecker.it/web-tools), [seotoolscentre](https://seotoolscentre.com/), [sitescorechecker](https://sitescorechecker.com/tools)

**Extensions**

[SEO Minion](https://chrome.google.com/webstore/detail/seo-minion/giihipjfimkajhlcilipnjeohabimjhi?utm_source=chrome-ntp-icon) or [ubersuggest](https://chrome.google.com/webstore/detail/ubersuggest-seo-and-keywo/nmpgaoofmjlimabncmnmnopjabbflegf)

***

#### SFX / Loops

[Adobe Audition Downloads](https://offers.adobe.com/en/na/audition/offers/audition_dlc.html), [Free-Loops](http://free-loops.com/), [FreeSOundEffects](https://www.freesoundeffects.com/), [Freesound](http://freesound.org/), [soundbible](https://soundbible.com/), [flashkit](http://www.flashkit.com/soundfx), [ZapsPlat](https://www.zapsplat.com/), [FindSounds](https://findsounds.com/), [OrangeFreeSounds](https://orangefreesounds.com/), [BBC Sound Effects](https://sound-effects.bbcrewind.co.uk/) / [Downloader](https://github.com/FThompson/BBCSoundDownloader), [looperman](https://www.looperman.com/loops), [sonniss2019](http://ftpmirror.your.org/pub/misc/sonniss2019/), [storyblocks](https://www.storyblocks.com/), [LabChirp](http://labbed.net/software/labchirp/), [Bfxr](https://www.bfxr.net/), [Noizable](https://noizable.media/), [sampleswap](https://sampleswap.org/), [samplefocus](https://samplefocus.com/), [soundpacks](https://soundpacks.com/), [Soundfishing](https://www.soundfishing.eu/), [SampleScope](https://samplescope.app/), [FindSounds](https://www.findsounds.com/), [splice](https://splice.com/), [MeowPad](https://meowpad.me/)

***

#### Sheet Music Sites

* [awesome-sheet-music](https://github.com/ad-si/awesome-sheet-music) 
* [Music Reader](https://music-reader.com/) - Practice Reading Sheet Music
* [/r/sheetmusic](https://reddit.com/r/sheetmusic)
* [8notes](https://www.8notes.com/)
* [imslp](https://imslp.org/wiki/Main_Page)
* [mutopiaproject](https://www.mutopiaproject.org/)
* [sheetsearch](https://www.sheetsearch.com/)
* [Sheet-Music](https://sheet-music.xyz/)
* [sheetmusicfox](http://www.sheetmusicfox.com/)
* [musopen](https://musopen.org/)
* [1230james](https://1230james.xyz/music/) 
* [CosandScores](http://waltercosand.com/CosandScores/)
* [librescore](https://demo.librescore.org/) 
* [Free Scores](https://m.free-scores.com/)
* [torbybrand](https://torbybrand.com/sheet-music/)
* [SheetMusicInternational](https://sheetmusicinternational.com/)
* [SheetMusicForFree](https://sheetmusicforfree.com/)
* [bateristaspt](https://www.bateristaspt.com/membros/drumscores/) 
* [tchunes](https://www.daev.ca/tchunes/)
* [Sheets Piano](https://sheets-piano.ru/) 
* [urresearch](https://urresearch.rochester.edu/viewInstitutionalCollection.action?collectionId=63) 
* [sscm-wlscm](https://www.sscm-wlscm.org/main-catalogue/full-catalogue-list)
* [escholarship](https://escholarship.org/uc/uclamusicscores) 
* [dlib](https://dlib.indiana.edu/variations/scores/) 
* [sscm-wlscm](https://www.sscm-wlscm.org/main-catalogue/full-catalogue-list) 
* [urresearch](https://urresearch.rochester.edu/viewInstitutionalCollection.action?collectionId=63) 
* [diamm](https://www.diamm.ac.uk/) 
* [themorgan](https://www.themorgan.org/music)  
* [unc](https://dc.lib.unc.edu/cdm/landingpage/collection/sheetmusic) 
* [ucla](https://digital.library.ucla.edu/sheetmusic/) 
* [brown](https://library.brown.edu/cds/sheetmusic/afam/about.html) 
* [mozarteum](https://dme.mozarteum.at/DME/nma/nmapub_srch.php?l=2) 
* [sfsma](http://www.sfsma.org/) 
* [digital.library](https://digital.library.unt.edu/explore/collections/VRBR/browse/) 
* [chopin](http://chopin.lib.uchicago.edu/) 
* [indiana](https://dlib.indiana.edu/variations/scores/) 
* [partdav](http://partdav.free.fr/partitions/)
* [PianoSheets](https://github.com/mstty/PianoSheets)
* [rocm](http://www.rocm.org/scores/) 
* [Piano Sheet Music Drive](https://drive.google.com/drive/folders/0BxkQJMTuId4dfkxiM01GYnFBUFdDVmRHMGREM1JKYVdBajJtV2pVSExrS2txT1BOdXlfMUE?resourcekey=0-4uwizkHnsGLakmC-cA173A) / [2](https://drive.google.com/drive/folders/1-hieArroBCq1x6z4GQ_gdFuyEz_Ftvxg)
* [Anime Sheet Music Drive](https://drive.google.com/drive/folders/0B2k9HIXzBEfMVlgxTlhNWThzZkk?resourcekey=0-q0RdwD55Az5S3NigaliZEA)
* [sniff](http://sniff.numachi.com/)
* [FluteTunes](https://www.flutetunes.com/) or [Flue Music](https://drive.google.com/drive/folders/1WMtVRNqLFdEQ4X39Dpof9o5aWGJsdtFe?usp=sharing)
* [cpdl](https://www.cpdl.org/wiki/index.php/Main_Page)
* [Ichigos](https://ichigos.com/)
* [free-scores](https://www.free-scores.com/free-sheet-music.php)
* [bandmusicpdf](https://bandmusicpdf.org/)
* [publicdomainsherpa](http://www.publicdomainsherpa.com/free-sheet-music.html)
* [musescore](https://musescore.org/en) + [Downloader](https://github.com/Xmader/musescore-downloader) 
* [JMSheetMusic](https://t.me/JMSheetMusic) (Jewish Music)

***

#### Site Analytics 

* https://www.openwebanalytics.com/
* https://www.alexa.com/siteinfo
* http://websiteoutlook.com/
* https://umami.is/
* https://matomo.org/
* https://goaccess.io/
* https://count.ly/
* https://ackee.electerious.com/
* https://panelbear.com/
* https://splitbee.io/
* https://www.hotjar.com/
* https://freshlytics.gitbook.io/
* https://www.awstats.org/
* https://counter.dev/
* https://github.com/vesparny/fair-analytics

***

#### Site Legitimacy Check 

**[URL Void](https://www.urlvoid.com/)**, [ThreatStop](https://threatstop.com/checkip), [urlscan.io](https://urlscan.io/), [Scamadviser](https://www.scamadviser.com/), [SiteSheck](https://sitecheck.sucuri.net/), [IsLegitSite](https://www.islegitsite.com/), [scanurl](https://scanurl.net/), [Dr. Web](https://vms.drweb.ru/online/), [Google Safe Browsing](https://transparencyreport.google.com/safe-browsing/search), [Online Link Scan](http://onlinelinkscan.com/)

***

#### SockShare Clones

* https://sockshare.fm/
* https://sockshare.mn/
* https://sockshare1.com/
* https://www4.123movies.net/
* https://www8.putlockers.fm/
* https://0123movies4u.com/
* https://wifimovies.net
* https://www4.xmovies8.fm/
* https://123free.net/
* https://hdzer.com/
* https://watchzer.com/
* https://wat32.tv/
* https://allzer.com/
* https://www.fast32.com/
* https://www1.xmovies8.io/
* https://fastzer.com/ 
* https://moviesonline.fm/
* https://123hulu.com/
* http://gomovies123.watch/
* https://putlocker.vc
* https://123enjoy.net/
* https://www2.putlockers.gs/
* https://www1.putlockers.sh/
* https://www1.moviesin.co/
* https://www2.putlockers.tw/
* https://seriesonline.bz/
* https://www2.putlockers.gy/
* https://www1.fmovies.gs/
* https://www2.putlockers.ws/
* https://primewire.mn/
* https://movieload.net/
* https://fmovie.ac/
* https://5movies.fm/
* https://fmovies.gy/
* https://www1.e123movies.com/
* https://www1.ezlive.tv/
* https://www1.f123movies.com/
* https://kat.mn/

***

#### Song Identification

**Sites / Programs**

[Midomi](https://www.midomi.com/), [AcrCloud](https://www.acrcloud.com/identify-songs-music-recognition-online/), [/r/NameThatSong](https://reddit.com/r/NameThatSong), [Dejavu](https://github.com/worldveil/dejavu) (python), [Audd](https://audd.io/) (api), [MusicRecognizer](https://github.com/NerdSmith/MusicRecognizer), [Mousai](https://github.com/SeaDve/Mousai), [AudioTag](https://audiotag.info/)

**Mobile Apps**

[Shazam](https://www.shazam.com/), [SoundHound](https://www.soundhound.com/soundhound), [Music ID iOS](https://apps.apple.com/app/musicid/id358838909?ign-mpt=uo%3D8)

***

#### Skip Redirect 

**[FastForward](https://fastforward.team/)** / **[Discord](https://discord.gg/RSAf7b5njt)**, **[Link Bypasser](https://github.com/TheCaduceus/Link-Bypasser)** / [TG Bot](https://drlinkbot.t.me/) / [2](https://github.com/TheCaduceus/Link-Bypasser-Bot) **[bypass.vip](https://bypass.vip/)**, [DL Site Scrubber](https://github.com/PrimePlaya24/dl-site-scrubber), [AdsBypasser](https://adsbypasser.github.io/) / [2](https://github.com/adsbypasser/adsbypasser), [skip-redirect](https://addons.mozilla.org/en-US/firefox/addon/skip-redirect/) / [Chrome](https://chrome.google.com/webstore/detail/skip-redirect/jaoafjdoijdconemdmodhbfpianehlon), [krnl-and-linkvertise-bypasser](https://greasyfork.org/en/scripts/427869-krnl-and-linkvertise-bypasser), [Bypass All Shortlinks](https://greasyfork.org/en/scripts/431691-bypass-all-shortlinks), [Linkvertise-Bypasser](https://github.com/venaxyt/Linkvertise-Bypasser), [Linkvertise-Bypass](https://github.com/Lufzys/Linkvertise-Bypass), [TheBypasser](https://thebypasser.com/), [Bypass-Links](https://github.com/amitsingh-007/bypass-links), [Auto link bypasser](https://chrome.google.com/webstore/detail/auto-link-bypasser/doiagnjlaingkmdjlbfalakpnphfmnoh), [Bypasser](https://yuumari.com/bypass/), [short link to direct link](https://t.me/ATBYPASSBOT)

***

#### SMS Verification Sites

[TextNow](https://www.textnow.com/), [Tempophone](https://tempophone.com/), [2ndline](https://www.2ndline.co/), [ReceiveaSMS](https://www.receiveasms.com/), [SMS Receive Free](https://smsreceivefree.com/), [SMS Online](https://sms-online.co/), [GetFreeSMSNUmber](https://getfreesmsnumber.com/), [SMS Receive](http://sms-receive.net/), [Receive SMS Online](https://www.receivesmsonline.net/), [7Sim](http://7sim.net/), [hs3x](https://hs3x.com/), [receivefreesms](http://receivefreesms.com/), [receivesmsonline](https://receivesmsonline.in/), [receive-sms-online](https://receive-sms-online.com/), [smsver](https://www.smsver.com/), [Sellaite](http://sms.sellaite.com/), [Send SMS Now](https://www.sendsmsnow.com/), [Free Online Phone](https://www.freeonlinephone.org/), [SMS Get](http://smsget.net/), [1s2u](https://1s2u.com/), [receivesmsonline.me](http://receivesmsonline.me/), [My Trash Mobile](https://es.mytrashmobile.com/numeros/), [Temp-Mails](https://www.temp-mails.com/), [GlobFone](https://globfone.com/), [receive-sms](https://receive-sms.com/), [freesmsverification](http://freesmsverification.com/), [temp-mails-number](https://www.temp-mails.com/number), [countrycode](https://countrycode.org/), [temp-sms](http://temp-sms.org/), [oksms](https://oksms.org/), [temporary-phone-number](https://temporary-phone-number.com/), [cloakmobile](https://cloakmobile.com/), [pumpsms](http://pumpsms.com/), [spoofbox](https://www.spoofbox.com/en/tool/trash-mobile/number), [onlinesim](http://onlinesim.ru/sms-receive), [smska](https://smska.us/), [receive-sms-online](https://www.receive-sms-online.info/), [smsfinders](https://smsfinders.com/), [receivesms](https://www.receivesms.org/), [numbersfor](http://numbersfor.me/), [mfreesms](https://mfreesms.com/), [phonerator](https://www.martinvigo.com/tools/phonerator/), [fake-sms](https://github.com/Narasimha1997/fake-sms), [yunjisms](https://yunjisms.xyz/), [clearcode](https://clearcode.cn/), [smscodeonline](https://smscodeonline.com/), [lothelper](https://www.lothelper.com/), [xinghai](https://xinghai.party/), [mianfeijiema](https://mianfeijiema.com/, [receivesms](https://www.receivesms.net/), [jiemahao](https://jiemahao.com/), [storytrain](https://www.storytrain.info/), [114sim](http://zg.114sim.com/) / [2](http://www.114sim.com/), [Temp Number](https://temp-number.com/), [sms24](https://www.sms24.me/), [receive-smss](https://receive-smss.com)

**No CC Required Trial Sites**

[esendex](https://www.esendex.co.uk/), [burstsms](https://burstsms.com.au/), [directsms](https://www.directsms.com.au/), [vumber](https://www.vumber.com/)

***

#### Soundcloud Downloaders

[SoundCloud Downloader](https://github.com/NotTobi/soundcloud-dl), [Klickaud](https://www.klickaud.co/), [Local SoundCloud Downloader](https://greasyfork.org/en/scripts/394837-local-soundcloud-downloader), [SoundCloud-Playlist-Sync](https://github.com/erwinkramer/SoundCloud-Playlist-Sync), [Soundcloud-Downloader](https://github.com/Kawaizombi/kawai-scripts/tree/master/projects/soundcloud-downloader), [SCDL](https://addons.mozilla.org/pl/firefox/addon/scdl-soundcloud-downloader/) / [Git](https://github.com/flyingrub/scdl), [sclouddownloader](https://sclouddownloader.net/), [SoundcloudMP3](https://soundcloudmp3.cc/)

***

#### Spanish Anime Telegram

[Animes480pFinalizados](https://t.me/Animes480pFinalizados), [Anime480p_Emision](https://t.me/Anime480p_Emision), [AndrossElLegado](https://t.me/AndrossElLegado), [animes_kawais](https://t.me/animes_kawais), [SimplementeAnime](https://t.me/SimplementeAnime), [animesfinalizadoLSHD](https://t.me/animesfinalizadoLSHD), [AnimeDark17](https://t.me/AnimeDark17)

***

#### Sports Streaming Subs

[/r/MLBStreams](https://www.reddit.com/r/MLBStreams/), [/r/ncaaBBallStreams/](https://www.reddit.com/r/ncaaBBallStreams/), [/r/WWEstreams/](https://www.reddit.com/r/WWEstreams/), [/r/rugbystreams](https://www.reddit.com/r/rugbystreams/)

***

#### Spotify Downloaders

**Legit Downloaders**

[Soggfy](https://github.com/Rafiuth/Soggfy) / [Discord](https://discord.gg/gjqrP5PB8g), [DownOnSpot](https://github.com/oSumAtrIX/DownOnSpot), [CLSpotify](https://agent255.github.io/clspotifyweb/) / [GitHub](https://github.com/agent255/clspotify), [spotify_sync](https://github.com/jbh-cloud/spotify_sync)

**Spotify YouTube Downloaders** 

[Savify](https://github.com/LaurenceRawlings/savify), [Spotify-DL](https://github.com/SathyaBhat/spotify-dl), [Sidify](https://sidify.com/), [spotDL](https://github.com/spotDL/spotify-downloader), [Syncify](https://github.com/FindMalek/Syncify) (Playlists), [FreyrJS](https://github.com/miraclx/freyr-js), [AllToMP3](https://alltomp3.org/), [Spotifast](https://github.com/seroteunine/Spotifast)

**Telegram Bots**

[Spotdlrobot](https://t.me/Spotdlrobot), [Spotify Music Downloader](https://t.me/joinchat/DdR2SUvJPBouSW4QlbJU4g), [pymusicdl](https://github.com/insaiyancvk/pymusicdl), [spotify-dl](https://github.com/SwapnilSoni1999/spotify-dl), [Spotify_downloa_bot](https://t.me/Spotify_downloa_bot) 

**Recorders** 

[Spytify](https://jwallet.github.io/spy-spotify/overview.html) / [GitHub](https://github.com/jwallet/spy-spotify)

***

#### Spotify Tools

[Chat](https://matchify.org/) / [Lyrics](https://versefy.app/) / [Spotify Companion](https://spotifytools.romanello.xyz/) / [Playlist Manager](https://skiley.net/) / [Playlist Words](https://spotifycloud.zamar-roura.com/) / [Dedup](https://spotify-dedup.com/) / [Hotkeys](https://github.com/aleab/toastify) / [Backup](http://www.spotmybackup.com/), [2](https://github.com/watsonbox/exportify) / [Library Size](https://opslagify.deruever.nl/) / [Listening Stats](https://www.statsforspotify.com/), [2](https://volt.fm/), [3](https://spotistats.app/), [4](https://github.com/Yooooomi/your_spotify) / [Song Country Search](https://kira.vercel.app/) / [Account Gen](https://github.com/HamzaAnis/go-spotify-account-generator), [2](https://github.com/davide-acanfora/spotify-account-generator), [3](https://github.com/ALIILAPRO/spotify-account-creator) / [Sync Accounts](https://github.com/yaronzz/SpotifySync) / [Canvas Downloader](https://canvastify.delitefully.com/), [GitHub](https://github.com/Delitefully/spotify-canvas-downloader) / [Export Tracks as Deezer Playlists](https://github.com/XDGFX/spotr)

**Spotify Adblockers**

* **[SpotX](https://github.com/amd64fox/SpotX)**
* [BlockTheSpot](https://github.com/mrpond/BlockTheSpot)
* [spotify-ad-blocker-ezblocker](https://www.ericzhang.me/projects/spotify-ad-blocker-ezblocker/)
* [Unspotify](https://git.tcp.direct/dg/Unspotify)
* [BurntSushi](https://github.com/OpenByteDev/burnt-sushi)
* [Block Ad Host Files](https://gist.github.com/opus-x/3e673a9d5db2a214df05929a4eee6a57), [2](https://github.com/AlfonsoVergara-github/Host-to-block-ads-for-spotify)

**Spotify Themes**

[Colorize](https://colorify.live/) / [Spicetify](https://spicetify.app/) / [CLI](https://github.com/khanhas/spicetify-cli) / [Addons](https://github.com/3raxton/spicetify-custom-apps-and-extensions) / [Discord](https://discord.gg/VnevqPp2Rr) / [Easy Install](https://github.com/OhItsTom/spicetify-easyinstall/) / [Fluent](https://github.com/williamckha/spicetify-fluent)

***

#### Streaming Site CSE

* [Streaming Sites Search](https://cse.google.com/cse?cx=006516753008110874046:cfdhwy9o57g#gsc.tab=0)
* [Streaming Sites Search 2](https://cse.google.com/cse?cx=006516753008110874046:o0mf6t-ugea#gsc.tab=0)
* [Streaming Sites Search 3](https://cse.google.com/cse?cx=98916addbaef8b4b6)
* [Streaming Sites Search 4](https://cse.google.com/cse?cx=0199ade0b25835f2e)

***

#### Stock Photo Sites

**[EveryPixel](https://www.everypixel.com/)**, [500GB Collection](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/base64#wiki_500gb_graphics_collection), [Awesome Stock Resources](https://github.com/neutraltone/awesome-stock-resources), [Png.is](https://png.is/tool/findstock), [Unsplash](https://unsplash.com), [Nohat](https://nohat.cc/), [Pexels](https://www.pexels.com/), [PixaBay](https://pixabay.com/), [PNGIMG (png)](https://pngimg.com/), [StockSnap](https://stocksnap.io/), [allthefreestock](https://allthefreestock.com/), [altphotos](https://altphotos.com/), [chamberofcommerce](https://www.chamberofcommerce.org/findaphoto/), [goodfreephotos](https://www.goodfreephotos.com/), [morguefile](https://morguefile.com/photos), [desirefx](https://www.desirefx.me/category/stock_images/), [icons8](https://icons8.com/illustrations) / [2](https://icons8.com/photos), [gfxmountain](http://gfxmountain.com/stock-photos/), [all-free-download](https://all-free-download.com/free-photos/), [compfight](http://compfight.com/), [freepik](https://www.freepik.com/) / [Drive](https://drive.google.com/drive/folders/1PlgpG_QVXYK82eZgqAxT4I_8UsRUgTa5), [creativity103](http://creativity103.com/), [photopin](http://photopin.com/), [photos8](https://photos8.com/), [reshot](https://www.reshot.com/), [creativecommons](https://search.creativecommons.org/), [DreamsTime](https://www.dreamstime.com/free-photos), [OpenAccess](https://www.si.edu/OpenAccess), [LibreStock](http://librestock.com/), [FreeImages](https://www.freeimages.com/), [PixelMob](https://pixelmob.co/), [StorySet](https://storyset.com/), [behance](https://www.behance.net/), [barnimages](https://barnimages.com/freebies/), [gratisography](http://gratisography.com/), [freeillustrations](http://freeillustrations.xyz/), [beatsnoop](https://downloaders.beatsnoop.com/), [kaboompics](https://kaboompics.com/), [picjumbo](https://picjumbo.com/), [negativespace](https://negativespace.co/), [burst](https://burst.shopify.com/), [barnimages](https://barnimages.com/), [flexiple](https://2.flexiple.com/scale/multi-color-illustrations), [skuawk](https://skuawk.com/index.html), [undraw](https://undraw.co/), [rawpixel](https://www.rawpixel.com/), [drawkit](https://www.drawkit.io/), [cgispread](https://cgispread.com/), [unblast](https://www.unblast.com/), [freedesignfile](https://freedesignfile.com/), [argfx](https://argfx.co/), [pixabay archive](https://web.archive.org/web/20190108204845/https://pixabay.com/en/service/terms/), [pxhere](https://pxhere.com/en/), [skitterphoto](https://skitterphoto.com/), [copyrightfreephotos](http://www.copyrightfreephotos.com/), [libreshot](https://libreshot.com/), [themeisle](https://mystock.themeisle.com/), [pxfuel](https://www.pxfuel.com/), [freestockimages](https://www.freestockimages.ru/free-photos/), [depositphotos](https://depositphotos.com/), [foodiesfeed](https://www.foodiesfeed.com/) (Food), [Illustrations](https://mega.nz/file/d8ES0RxT#r6WMKTc8kdthij76J8f2p0fsTHQZ0GvUxs82olNDLqU), [Objects](https://mega.nz/file/A9ciGb6J#ZermRxtupsNMdFT7JS3myfRKOTuyByqRZpOWWwY-nOM), [Humaaans](https://www.humaaans.com/), [blush](https://blush.design/), [cupcake](https://cupcake.nilssonlee.se/), [bucketlistly](https://www.bucketlistly.blog/photos), [magdeleine](https://magdeleine.co/), [splitshire](https://www.splitshire.com/), [littlevisuals](https://littlevisuals.co/), [picography](https://picography.co/), [stickpng](http://www.stickpng.com), [lifeofpix](https://www.lifeofpix.com/), [freenaturestock](https://freenaturestock.com/), [diverseui](https://diverseui.com/) (Human Faces), [designerspics](http://www.designerspics.com/), [travelcoffeebook](https://travelcoffeebook.com/), [publicdomainarchive](https://publicdomainarchive.com/), [twnsnd](https://nos.twnsnd.co/), [moveast](https://moveast.me/), [focastock](https://focastock.com/), [jeshoots](https://jeshoots.com/), [isorepublic](https://isorepublic.com/), [digitalcollections](https://digitalcollections.nypl.org/), [flickr](https://www.flickr.com/commons), [startupstockphotos](https://startupstockphotos.com/), [shutteroo](https://shutteroo.com/), [photostockeditor](https://photostockeditor.com/), [photober](https://www.photober.com/), [goodstock](https://goodstock.photos/), [freerangestock](https://freerangestock.com/), [thepicpac](https://thepicpac.com/), [streetwill](http://streetwill.co/), [stokpic](https://stokpic.com/), [stockified](https://www.stockified.com/), [splashbase](http://www.splashbase.co/), [snappygoat](https://snappygoat.com/), [realisticshots](https://realisticshots.com/), [pickupimage](https://pickupimage.com/), [jaymantri](https://jaymantri.com/), [freelyphotos](https://www.freelyphotos.com/), [crowthestone](https://crowthestone.tumblr.com/), [cc0](http://cc0.photo/), [albumarium](http://albumarium.com/), [photoeverywhere](http://photoeverywhere.co.uk/), [freejpg](https://en.freejpg.com.ar/), [getrefe](https://getrefe.tumblr.com/), [titania](https://www.titania-foto.com/), [opendoodles](https://www.opendoodles.com/), [woobro](https://woobro.design/), [thestocks](http://thestocks.im/), [sitebuilderreport](https://stockup.sitebuilderreport.com/), [avopix](https://avopix.com/), [openverse](https://wordpress.org/openverse/), [drawkit](https://drawkit.com/), [3D Illustrations](https://3d.khagwal.co/), [3dbay](https://clouddevs.com/3dbay/), [pixeltrue](https://www.pixeltrue.com/free-illustrations), [marker-illustrations](https://usepastel.com/marker-illustrations), [free-gophers-pack](https://github.com/MariaLetta/free-gophers-pack), [vecteezy](https://www.vecteezy.com/free-photos), [deathtothestockphoto](http://deathtothestockphoto.com/), [mmtstock](http://mmtstock.com/), [stockphotos](https://stockphotos.io/), [raumrot](http://raumrot.com/), [glyphs](https://glyphs.co/photos), [tookapic](https://stock.tookapic.com/photos?filter=free), [freenaturestock](http://www.freenaturestock.com/) (Nature), [4freephotos](https://www.4freephotos.com/), [niceillustrations](https://niceillustrations.com/free-illustrations/), [NS-illustration-pack](https://github.com/nsobolewart/NS-illustration-pack), [manypixels](https://www.manypixels.co/gallery), [fresh-folk](https://fresh-folk.com/), [iwaria](https://iwaria.com/), [stockvault](https://www.stockvault.net/), [slon.pics](https://www.slon.pics/), [pikwizard](https://pikwizard.com/), [aerophotostock](https://www.aerophotostock.com/)

**Vectors** 

[vectorportal](https://www.vectorportal.com/), [publicdomainvectors](https://publicdomainvectors.org/), [vecteezy](https://www.vecteezy.com/), [freevectors](http://www.freevectors.org/), [123freevectors](https://www.123freevectors.com/), [freevector](https://www.freevector.com/), [vector](https://vector.me/), [freevectors](https://www.freevectors.net/), [free-vectors](https://free-vectors.com/), [365psd](https://365psd.com/), [vector4free](https://www.vector4free.com/), [ddpanda](https://ddpanda.net/collection/vectors/)

**Telegrams** 

[Shutterstock Premium](https://t.me/shutterstockpremium), [Free Shutterstock](https://t.me/freeshutter), [freestockphotos](https://t.me/freestockphotos), [Shutter](https://t.me/Shutter)

**Downloaders** 

**[GetPaidStock](https://getpaidstock.com/)**, **[Downloader.la](https://downloader.la/)**, [downloaders](https://downloaders.beatsnoop.com/), [sharedvn](https://www.sharedvn.net/), [visualhunt](https://visualhunt.com/), [shutterstock-photo-downloader](https://mytoolz.net/tools/shutterstock-photo-downloader), [istock](https://istock.7xm.xyz/), [ChkCut](https://t.me/+1Sv-rAmiqwVkZTE0)

***

#### Stock Video Sites

**[VidsPlay](https://www.vidsplay.com/)**, [Awesome Stock Resources](https://github.com/neutraltone/awesome-stock-resources), [Mixkit](https://mixkit.co/), [Coverr](http://coverr.co/), [Elements](https://elements.envato.com/), [BeachFrontBroll](http://www.beachfrontbroll.com/), [Videvo](https://www.videvo.net/), [CuteStockFootage](https://cutestockfootage.com/), [VidEezy](https://www.videezy.com/), [Vecteezy](https://www.vecteezy.com/), [Mazwai](https://mazwai.com/), [Pexels Video](https://www.pexels.com/videos/), [Life of Vids](http://www.lifeofvids.com/), [FreeHD](https://vimeo.com/groups/freehd/),  [Elements](https://elements.techtanic.pw/), [veed.io](https://www.veed.io/videos), [DroneStock](https://dronestock.com/), [MotionPlaces](https://www.motionplaces.com/), [cutestockfootage](https://www.cutestockfootage.com/free/), [motionarray](https://motionarray.com/browse/stock-video/?free=true), [mitchmartinez](https://mitchmartinez.com/free-4k-red-epic-stock-footage/), [Dareful](https://dareful.com/)

***

#### Subreddit Discovery

[/r/DiscoverReddit Index](https://www.reddit.com/r/DiscoverReddit/wiki/index), [/r/Serendipity](https://www.reddit.com/r/Serendipity), [/r/ListOfSubreddits](https://www.reddit.com/r/ListOfSubreddits/), [/r/mistyfront](https://www.reddit.com/r/mistyfront/), [/r/wowthissubexists](https://www.reddit.com/r/wowthissubexists/), [/r/findareddit](https://www.reddit.com/r/findareddit/), [/r/trendingsubreddits](https://www.reddit.com/r/trendingsubreddits), [/r/TrendingReddits/](https://www.reddit.com/r/TrendingReddits/), [subreddit_map](http://www.jacobsilterra.com/subreddit_map/network/index.html), [SubredditMentionsGraph](https://dmarx.github.io/SubredditMentionsGraph/network/), [redditviz](http://rhiever.github.io/redditviz/clustered/)

***

#### Summary Generator

[Skimcast](http://www.skimcast.com/), [SummaryGenerator](https://summarygenerator.com/), [Scholarcy](https://www.scholarcy.com) / [Chrome](https://chrome.google.com/webstore/detail/scholarcy-research-paper/oekgknkmgmaehhpegfeioenikocgbcib), [Resoomer](http://www.resoomer.com/), [tl;dr chrome](https://chrome.google.com/webstore/detail/tldr-chrome/khkpnmmnkenbelkljphmpbjgbmobgonn), [SMMRY](https://smmry.com/), [Summari](https://www.summari.com/)

***

#### Switch Homebrew Discord Servers

* https://discord.gg/switchway
* https://discord.gg/pytKu48eMk
* https://discord.gg/EZMAupDvWE
* https://discord.gg/UkwVjft
* https://discord.gg/MfXkAMwW6Z
* https://discord.gg/tuT59S2zcv
* https://discord.gg/dvP2sJu3EA
* https://discord.gg/VAadvt9KFH

***

#### Switch Roms

* [NXBrew](https://nxbrew.com/) - (Scroll past Download Setup buttons)
* [nsw2u](https://nsw2u.in/)
* [XCI NSP](https://www.xcinsp.com/)
* [Switchrls](https://switchrls.co/)
* [NswRoms](https://nswrom.com/)

***

#### Tab Managers 

[OneTab](https://www.one-tab.com/), [Tab Center Reborn](https://framagit.org/ariasuni/tabcenter-reborn), [Tabli](https://www.gettabli.com/), [Simple Tab Groups](https://github.com/drive4ik/simple-tab-groups), [Acid Tabs](https://github.com/jdhayford/acid-tabs-extension), [Tab Stash](https://josh-berry.github.io/tab-stash/)

***

#### TeamDrive Generators

* Note that these can and do get deleted
* https://td.msgsuite.workers.dev/
* https://t.me/MSGuite_SD_Creator_Bot + [Telegram Chat](https://t.me/msgsuitechat)
* https://bdi-generator.hashhackers.com/ (Google Drive Index Code Generator)

***

#### Tech News

[GHacks](https://www.ghacks.net/), [TechURLs](https://techurls.com/), [Tidbits](https://tidbits.live/), [HackNews](https://hackne.ws/), [Ars Technica](https://arstechnica.com/), [Geeks3D](https://www.geeks3d.com/), [BleepingComputer](https://www.bleepingcomputer.com/), [SingularityHub](https://singularityhub.com/), [Toms Hardware](https://www.tomshardware.com/), [Overclock3d](https://overclock3d.net/), [NeoWin](https://www.neowin.net/), [DigitalTrends](https://www.digitaltrends.com/), [Slashdot](https://slashdot.org/)

***

#### Temp Email Sites

**[smailpro](https://smailpro.com/)** (gmail), **[Emailnator](https://www.emailnator.com/)** (gmail), [getnada](https://getnada.com/), [10 Minute Mail](https://temp-mail.org/en/10minutemail), [Temp Mail](https://temp-mail.org/), [cs.email](https://www.cs.email/), [maildrop](https://maildrop.cc/), [mailinator](https://www.mailinator.com/), [mailnesia](https://mailnesia.com/), [10minutemail](https://10minutemail.com/), [spamgourmet](https://www.spamgourmet.com/), [tempmail.ninja](https://tempmail.ninja/), [tempinbox](http://tempinbox.com), [disposable](https://github.com/0x19/disposable), [anonbox](https://anonbox.net/), [youdabomb](https://tempmail.youdabomb.social/), [Generator.email](https://generator.email/), [kuku](https://m.kuku.lu/), [grrmail](http://grrmailb3fxpjbwm.onion/) (tor), [Email on Deck](https://www.emailondeck.com/), [temp-mails](https://www.temp-mails.com/), [Mohmal](https://www.mohmal.com/en), [Mohmal](https://www.mohmal.com/en), [tempmail](https://github.com/sdushantha/tmpmail) (terminal), [Temp Mail](https://rapidapi.com/Privatix/api/temp-mail) (api), [xkx](https://xkx.me/), [33mail](https://33mail.com/), [Guerillamail](https://www.guerrillamail.com/) / [.onion](https://grr.la/mail/grrmailb3fxpjbwm.onion), [edumail](https://edumail.icu/), [cs.email](https://cs.email/), [Mail.tm](https://mail.tm/en), [temporarymail](https://temporarymail.com/), [FakeMailGenerator](http://www.fakemailgenerator.com/), [emailfake](https://emailfake.com/), [tempmailo](https://tempmailo.com/), [10minutesemail](https://10minutesemail.net/), [emailondeck](http://emailondeck.com/), [tempm](https://tempm.com/), [tempail](https://tempail.com/), [tempmailaddress](https://www.tempmailaddress.com/), [eyepaste](http://www.eyepaste.com/), [mintemail](http://www.mintemail.com/), [mytemp](https://mytemp.email/), [sharklasers](https://www.sharklasers.com/), [yopmail](http://www.yopmail.com/en/), [mail.td](https://mail.td/), [dropmail](https://dropmail.me/en/), [cryptogmail](https://cryptogmail.com/), [inboxkitten](https://inboxkitten.com/), [anonymmail](https://anonymmail.net/), [tmailweb](https://tmailweb.com/), [one-off](https://one-off.email/), [another-temp-mail](https://www.another-temp-mail.com/), [tempr](https://tempr.email/en/), [eTempMail](https://etempmail.net/), [fakemail](https://www.fakemail.net/), [throwawaymail](https://www.throwawaymail.com/), [hour](https://www.hour.email/), [harakirimail](https://harakirimail.com/), [33mail](https://www.33mail.com/), [hottempmail](https://hottempmail.com/), [dispomail](https://dispomail.xyz/), [tempmail](https://tempmail.dev/), [email-generator](https://yopmail.com/en/email-generator), [moakt](https://www.moakt.com/), [24mail](http://24mail.chacuo.net/), [linshi-email](https://www.linshi-email.com/), [mail1s](https://en.mail1s.com/), [nolog](https://nolog.email/), [mailmenot](https://www.mailmenot.io/), [gmailcity](https://gmailcity.com/), [haribu](https://haribu.net/), [disposablemail](https://www.disposablemail.com/), [trashmail](https://trashmail.ws/), [emailsensei](http://emailsensei.com/), [emailtemporanee](https://emailtemporanee.com/), [fakermail](https://fakermail.com/), [tempmail-online](https://www.tempmail-online.com/), [abandonmail](https://www.abandonmail.com/), [10minutesmail](http://10minutesmail.com/), [mailtemp](https://mailtemp.top/), [itsmdaily](https://www.itsmdaily.com/10-minute-email-temporary-mail-address/), [rsolution](http://rsolution.be/free-temporary-disposable-email.RSolution), [temporary-email](https://temporary-email.com/), [/tempmail.plus](https://tempmail.plus/en/), [mail-temp](https://mail-temp.com/), [temp-mail](https://temp-mail.us/), [20minutemail](https://www.20minutemail.com/), [easytrashmail](https://www.easytrashmail.com/), [tempmail.de](https://tempmail.de/), [1secmail](https://www.1secmail.com/), [10minutemail](https://www.lite14.us/10minutemail/), [fex](https://fex.plus/en/), [sneya](https://jooko.info/sneya), [email-fake](https://email-fake.com/), [mintemail](https://www.mintemail.com/), [temporary-mail](https://www.temporary-mail.net/), [luxusmail](https://luxusmail.org/), [trashinbox](https://trashinbox.net/), [tempmail](https://tempmail.zone/), [obagg](https://od.obagg.com/), [spambox](https://spambox.xyz/), [mailet](https://mailet.in/), [tempmails](https://tempmails.net/), [receivemail](https://www.receivemail.org/), [rainmail](https://rainmail.xyz/), [gigainbox](https://gigainbox.com/), [tempemail](https://tempemail.co/), [tempsky](https://tempsky.com/), [tempinbox](http://www.tempinbox.com/), [burner](https://burner.kiwi/), [mailpoof](https://mailpoof.com/), [tempmail.altmails](https://tempmail.altmails.com/), [instant-email](https://instant-email.org/), [temp-mail.io](https://temp-mail.io/), [temp-inbox](https://temp-inbox.com/), [minutemailbox](https://www.minutemailbox.com/), [tempmaili](https://tempmaili.com/), [minuteinbox](https://minuteinbox.com/), [emailhippo](https://tools.emailhippo.com/), [emailtemp](https://emailtemp.org/), [hour.emai](https://hour.email/), [tempmailid](https://tempmailid.com/)

**Temp Mail Lists**

[Temp Mail List](https://gist.github.com/michenriksen/8710649), [Disposable Emails Domains](https://github.com/ivolo/disposable-email-domains), [Temp Mail Rentry](https://rentry.co/k2vev), [EmailAddresses](https://www.emailaddresses.com/email_disposable.html), [disposable-emails](https://disposable-emails.github.io/)

**Telegram Temp Mail Bots**

[Trashmail](https://redd.it/gpo1ni), [TrashEmail](https://t.me/trashemail_bot), [TempMail_org_bot](https://t.me/TempMail_org_bot), [tmpmailbot](https://t.me/tmpmailbot), [smtpbot](https://t.me/smtpbot), [temp_mail_bot](https://t.me/temp_mail_bot) 

**Temp Mail Extensions**

[Bloody Vikings!](https://addons.mozilla.org/en-US/firefox/addon/bloody-vikings/), [c0x0](https://c0x0.com), [Temp Mail](https://temp-mail.org/)

***

#### Telegram Anime Downloads

* https://t.me/Anime_Gallery
* https://t.me/anidlws
* https://t.me/AnimeCrunch
* https://t.me/Anime_Library
* https://t.me/Anime_4u_Geng
* https://t.me/for_otaku
* https://t.me/Any_Animebot
* https://t.me/anime_everywhere
* https://t.me/AnimeList
* http://t.me/AUTOxANIME/2
* https://t.me/AutoAnimeBot
* https://t.me/AnimeGuardian_bot
* https://t.me/Hd_Anime_Series
* https://t.me/joinchat/AAAAAFSIbbpvGcBgRC6IKw
* https://t.me/animeze
* https://t.me/AnimeIndexOfficial
* https://t.me/myanimetvbot
* https://t.me/otakulounge
* https://t.me/TGanimehaku 
* https://t.me/animeinc
* https://t.me/AnimeTeleNS
* https://t.me/Animewatching
* https://t.me/anime_a_to_z
* https://t.me/AnimeSeries
* https://t.me/Anime4uGeng_List
* https://t.me/Anime_Flix_Pro
* https://t.me/Animereq45
* https://t.me/Anime_1080p_720p_480p
* https://t.me/Animeworld001
* https://t.me/AnimeRG
* https://t.me/AnimeWorldOngoing
* https://t.me/AnimeFiles
* https://t.me/soulreaperzone
* https://t.me/AnimeFiles
* https://t.me/AnimeKingdomX
* https://t.me/Kingdomofanimeseries
* https://t.me/AnimeMoviesOtaku
* https://t.me/AnimeLibrary_Movies
* https://t.me/animemovies

***

#### Telegram Audiobook Downloads

* https://t.me/BOOK_HOUSE_INTERNATIONAL
* https://t.me/AudiobooksArchive
* https://t.me/eng_audiobooks
* https://t.me/ebookz
* https://t.me/Audiobooks_Collection
* https://t.me/TheBestAudible
* https://t.me/Audiobookclassic
* https://t.me/Audiobookclassic
* https://t.me/audiobookjunkie
* https://t.me/audiobooks_English
* https://t.me/Audiobooks_uk
* https://t.me/blarkhive
* https://t.me/books_in_english_free
* https://t.me/Ebooks_AudioBooks
* https://t.me/eng_audiobooks
* https://t.me/online_audiobooks
* https://t.me/TheAudiobookStop
* https://t.me/UnLibrary 
* https://t.me/audioboookz
* https://t.me/Audoroom
* https://t.me/GroupAudio
* https://t.me/selfhelpaudiobook

***

#### Telegram Audio Download

* [Music Downloader](https://t.me/MusicDownloaderRobot) - FLAC 
* [Joey](https://t.me/joeymusicbot) - FLAC 
* [flacmusics](https://t.me/flacmusics/) - FLAC 
* [flacmusicalbumfree](https://t.me/flacmusicalbumfree/) - FLAC 
* [FLACSong](https://t.me/FLACSong) - FLAC 
* [flacmu5ic](https://t.me/flacmu5ic/) - FLAC 
* [SACDandDSD](https://t.me/SACDandDSD) - FLAC
* [Songscave](https://t.me/songscave) - FLAC
* [FLAC Musik](https://t.me/flacmuzik) - FLAC
* [FLAC Album](https://t.me/FLAC_DSD_LOSSLESS_HIRES) - FLAC
* [Music_Hunters](https://t.me/Music_Hunters)
* [/Music](https://t.me/music)
* [FlacStoreBot](https://t.me/FlacStoreBot) - MP3 / FLAC
* [Musicassistbot](https://t.me/Musicassistbot) - MP3
* [musicder_bot](https://t.me/musicder_bot) - MP3
* [musical_freely](https://t.me/musical_freely) - MP3
* [DeezEmpireBot](https://t.me/DeezEmpireBot) - MP3 / FLAC
* [songspkmusic](https://t.me/songspkmusic) - MP3
* [Spotify™ | DataBase](https://t.me/joinchat/CpMAJhkWaTwk8BVPepASZQ) - MP3 / FLAC
* [bassmuzic](https://t.me/bassmuzic) - MP3
* [MusicsHunterbot](https://t.me/MusicsHunterbot)
* [ClassicalMusicMe](https://t.me/ClassicalMusicMe) - Classical 
* [MeditationRelaxMusic](https://t.me/MeditationRelaxMusic) - Meditation 
* [ElectronicMusicMe](https://t.me/ElectronicMusicMe) - Electronic 
* [DJ Download ME](https://t.me/edmdownloadme) - Electronic
* [BluesJazz](https://t.me/BluesJazz) - Blues / Jazz 

***

#### Telegram Audio Download Bots

* [LyBot](https://t.me/LyBot) - YouTube 
* [YouTube Audio Bot](https://t.me/YtbAudioBot) - YouTube 
* [YouTube Audio Download](https://t.me/YoutubeAudioDownloadBot) - YouTube
* [TidalMusic_DLbot](https://t.me/TidalMusic_DLbot) - Tidal
* [VK Bot](https://t.me/vkmsaverbot) - VK 
* [VKM Bot](https://t.me/vkm_bot) - VK 
* [Meph Bot](https://t.me/mephbot) - VK 
* [vkm4bot](https://t.me/vkm4bot) - VK f
* [vkmusic_bot](https://t.me/vkmusic_bot) - VK
* [yamdbot](https://t.me/yamdbot) - Yandex 
* [MP3 downloader](https://t.me/TG_mp3downloader_bot) - Multi Site 
* [scdlbot](https://t.me/scdlbot) - Multi Site 
* [JioDLBot](https://t.me/JioDLBot) - Multi Site 
* [Song ID](https://t.me/SongIDbot) - Shazam Alike 
* [spotifysavebot](https://t.me/spotifysavebot) - Spotify 

***

#### Telegram Bots

[BotsArchive](https://t.me/BotsArchive), [awesome-telegram](https://github.com/ebertti/awesome-telegram), [awesome-telegram-bots](https://github.com/DenisIzmaylov/awesome-telegram-bots), [awesome-bots](https://github.com/abdelhai/awesome-bots), [awesome-telegram-groups](https://github.com/stkw0/awesome-telegram-groups), [awesome-telegram](https://github.com/serhii-londar/awesome-telegram), [awesome-telegram-lists](https://github.com/lorien/awesome-telegram-lists), [bots](https://telegramic.org/bots/), [botlist](https://t.me/botlist), [TelegramBotsList](https://danyspin97.github.io/TelegramBotsList/), [bots.php](https://www.qwasap.com/en/bots.php), [/r/TelegramBots](https://www.reddit.com/r/TelegramBots/), [telegram-store](https://telegram-store.com/catalog/product-category/bots), [infotelbot](https://botlist.infotelbot.com/) 

***

#### Telegram Deezer Bots

* [vkm_bot](https://t.me/vkm_bot)
* [Song_downloaderbot](https://t.me/Song_downloaderbot)
* [songdl_bot](https://t.me/songdl_bot) 
* [DeezerMusicBot](https://t.me/DeezerMusicBot) 
* [DeezloaderAn0n_bot](https://t.me/DeezloaderAn0n_bot)
* [deezload2bot](https://t.me/deezload2bot)

***

#### Telegram File Tools

* **[DrFileStreamBot](https://t.me/DrFileStreamBot)**,[UploadBots](https://t.me/UploadBots, [File-Sharing-Bot](https://github.com/CodeXBotz/File-Sharing-Bot), [Uploadgram](https://uploadgram.me/) / [Bot](https://t.me/uploadgrammebot), [LinkToFileTGBot](https://t.me/LinkToFileTGBot, [TelegramCloud](https://github.com/iw4p/telegram-cloud), [UploadURL](https://t.me/UploadsRobot) or [UploadDxbot](https://t.me/UploadDxbot) - Upload Files to Telegram
* [GdriveXbot](https://t.me/GdriveXbot), [google-drive-telegram-bot](https://github.com/viperadnan-git/), [HK_upload_bot](https://t.me/HK_driveupload_bot), [gdrive_upload_bot](https://t.me/gdrive_upload_bot), [Python Aria Mirror Bot](https://github.com/lzzy12/python-aria-mirror-bot), [driveuploadbot](https://t.me/driveuploadbot) or [gdriveupme_bot](https://t.me/gdriveupme_bot) - Google Drive Telegram upload bots 
* [Google Drive Bot](https://t.me/Gdriveit_bot) - Google Drive Client in Telegram
* [SearchX](https://github.com/iamLiquidX/SearchX) - Telegram GDrive Search Bot
* [MEGA Uploader X](https://t.me/MegaUploadXbot) or [Mega.nz-Bot](https://github.com/Itz-fork/Mega.nz-Bot) - Remote Mega File Upload Bot
* [OneDrive X](https://t.me/onedrivexbot) - Remote OneDrive File Upload Bot
* [Teledrive](https://github.com/mgilangjanuar/teledrive) - Telegram File Storage
* [Uploader x Bot](https://t.me/uploader_x_bot ) - Telegram Video Upload Bot 
* [Public Link Bot](https://t.me/Tg2extbot), [AIO Uploader](https://t.me/aiouploaderbot) or [GetPublicLinkBot](https://t.me/GetPublicLinkBot), [FileUploaderBot](https://t.me/FileUploaderBot), [filestolinksbot](https://t.me/filestolinksbot), [highspeedlinksbot](https://t.me/highspeedlinksbot), [LinkForFilebot](https://t.me/LinkForFilebot), [MultiUpload-Bot](https://github.com/oVoIndia/MultiUpload-Bot) or [KL_GetPublicUrlBot](https://t.me/KL_GetPublicUrlBot) - Telegram to File Host Upload Bot   
* [mediainforobot](https://t.me/mediainforobot) - Media File Info
* [MediaDownBot](https://t.me/mediadownbot) - Social Media Downloader
* [ILovePDF](https://github.com/nabilanavab/ilovepdf) - Telegram File to PDF Converter 
* [ConvertVideoTGBot](https://t.me/ConvertVideoTGBot), [FileConvertRobot](https://t.me/FileConvertRobot) or [File2videoconvbot](https://t.me/File2videoconvbot) - Video File Converters

***

#### Telegram eBook Download

* https://t.me/Ebooks254
* https://t.me/BOOK_HOUSE_INTERNATIONAL
* https://t.me/Ebooks_Encyclopedia27
* https://t.me/Books_worldd
* https://t.me/Ebooksenglish
* https://t.me/free_ebooks_pdfs
* https://t.me/English_Hindi_Novels_Magazine
* https://t.me/BooksThief
* https://t.me/FreeNovelsGroup
* https://t.me/iBooks_Bot
* https://t.me/booksmania
* https://t.me/livresdomainepublic
* https://t.me/bkcrushfilesbot
* https://t.me/bookdownbot
* https://t.me/ebooksdlbot
* https://t.me/libsan_bot
* https://t.me/alejandriak
* https://t.me/yourlibraries
* https://t.me/TheEbookStop
* https://t.me/bookclub7
* https://t.me/BookCrush
* https://t.me/bookhome3
* https://t.me/BooksStreet
* https://t.me/BookWizardTheNewest
* https://t.me/Dao_Qigong_Taiji_TCM_ebooks
* https://t.me/lib_of_dos_old_vk
* https://t.me/LibrariesofTelegram
* https://t.me/libraryofdos
* [More Telegram eBook Channels](https://duckduckgo.com/?q=site%3At.me+books&ia=web)

***

#### Telegram Video Download

* [Remux_2160P](https://t.me/Remux_2160P) - 4K Movies
* [Rare Films](https://t.me/rarefilms) - Movies 
* [MoviesVerse](https://t.me/MoviesHomeOFFICIALS) - Movies / TV 
* [SeriesArchiveX](https://t.me/SeriesArchiveX) - Movies / TV
* [Rarefilmsbot](https://t.me/Rarefilmsbot) - Movies 
* [Mobile movies request bot](https://t.me/cc_mmrequestbot) - Movies / 480p 
* [AWMHG](https://t.me/all_world_movies_here_group) - Movies
* [MoviesX_support](https://t.me/MoviesX_support) - Movies
* [request_movies_group](https://t.me/request_movies_group) - Movies
* [ZestFlix](https://t.me/+vxfKtaB4sXtmNjY1) - Movies / TV / [Archives](https://t.me/+iuTSrLAp27c4OTE1)
* [TVSeriesArchive](https://t.me/TvSeriesArchive) - TV
* [pre_code](https://t.me/pre_code) - Classic
* [StommeFilms](https://t.me/StommeFilms) - Classic
* [ZwartwitFilms](https://t.me/ZwartwitFilms) - Classic
* [CartoonLibrary](https://t.me/CartoonLibrary) - Cartoons
* [Cartoon_Index](https://t.me/Cartoon_Index) - Cartoons

***

#### Text Adventures

[iFiction](https://www.ifiction.org/) (Index), [IFDB](https://ifdb.org/) (Index), [Ifarchive](https://ifarchive.org/if-archive/games/) (drive), [Pac-Txt](http://www.pactxt.com/), [AI Dungeon](https://play.aidungeon.io/main/landing), [A Dark Room](http://adarkroom.doublespeakgames.com/), [Addventure](http://addventure.com/addventure/), [The Never Ending Quest](https://www.sir-toby.com/extend-a-story/story-1/code/read.php), [The Text Adventure](https://kevan.org/wikitext/), [Seedship](https://philome.la/johnayliff/seedship/play/index.html), [TextAventures](http://textadventures.co.uk/), [Crank](https://faedine.com/games/crank/b39/), [Umbra](https://umbra.avalon-rpg.com/), [Web Adventures](http://www.web-adventures.org/), [WrittenRealms](https://writtenrealms.com/)

***

#### Text / Code Collaboration 

[Google Colaboratory](https://colab.research.google.com/), [Mattermost](https://mattermost.com/), [HackMD](https://hackmd.io/), [Taskade](https://www.taskade.com/), [CryptPad](https://cryptpad.fr/), [Socket](https://socket.io/), [Whimsical](https://whimsical.com/), [Firepad](https://firepad.io/), [Etherpad](https://etherpad.org/), [FidusWriter](https://www.fiduswriter.org/), [overleaf](https://www.overleaf.com/), [RustPad](https://github.com/ekzhang/rustpad)

***

#### Text Editors 

* **[List of Text Editors](https://en.wikipedia.org/wiki/List_of_text_editors)**
* **[Notepad++](https://notepad-plus-plus.org/)**
* [Typora](https://typora.io/)
* [RemNote](https://www.remnote.io/)
* [Foam](https://github.com/foambubble/foam)
* [Xournal++](https://xournalpp.github.io/) - [GitHub](https://github.com/xournalpp/xournalpp)
* [Notepads](https://www.notepadsapp.com/)
* [Xed](https://github.com/linuxmint/xed)
* [Left](https://hundredrabbits.itch.io/left) - [GitHub](https://github.com/hundredrabbits/Left)
* [Nano](https://www.nano-editor.org/)
* [BeefText](https://beeftext.org/)
* [Quill](https://quilljs.com/)
* [Mery](https://www.haijin-boys.com/wiki/)
* [Helix](https://helix-editor.com/) - [GitHub](https://github.com/helix-editor/helix)
* [Fluent](https://www.microsoft.com/en-us/p/fluentpad/9pdcqcb06s91)
* [Notepad](https://notepad.js.org/)
* [Textreme](https://ash-k.itch.io/textreme) - [GitHub](https://github.com/cis-ash/TEXTREME)
* [Geany](https://www.geany.org/)

**Online Text Editors** 

* [TextSlave](https://www.textslave.com/) 
* [Text Mechanic](https://textmechanic.com/)
* [Zen](https://zen.unit.ms/) 
* [NimbleText](https://nimbletext.com/Live) 
* [anotepad](https://anotepad.com/) 
* [takenote](https://takenote.dev/) 
* [onlinenotepad](https://onlinenotepad.org/) 
* [notepad-online.net](https://notepad-online.net/) 
* [AnyTextEditor](https://anytexteditor.com/) 
* [notepad-online.com](https://notepad-online.com/)
* [JustNotePad](https://justnotepad.com/) 
* [TextSlave](https://www.textslave.com/) 
* [Write Box](https://write-box.appspot.com/) 
* [Org](https://orgmode.org/) 

***

#### Text Rephrashing

[QuillBot AI](https://quillbot.com/) / [Premium Unlock](https://github.com/blueagler/QuillBot-Premium-Crack) / [2](https://github.com/razoo-choudhary/quillbot-premium) / [Token](https://pastebin.com/ezkjxWd1), [Rewrite Tool](https://www.rewritetool.net/), [Paraphraz](https://paraphraz.it/), [Rewriter](https://rewriter.tools/), [Spinbot](https://spinbot.com/), [Paraphrasing Tool](https://paraphrasetool.com/), [ArticleReword](https://www.articlereword.com/rewriter/), [Rephrasely](https://rephrasely.com/), [Paraphraser](https://www.paraphraser.io/), [SmartArticleWriter](https://smartarticlerewriter.com/), [Paraphrase-Online](https://paraphrase-online.com/), [articlerewritertool](https://articlerewritertool.com/), [Trubo Spinner](http://script4.prothemes.biz/), [rephraser](https://www.rephraser.net/rewording-tool/), [summarizetool](https://www.summarizetool.com/), [caligonia](http://caligonia.com/a2/rewrite.php), [paraphrasing-tool](http://paraphrasing-tool.com/), [freearticlespinning](http://www.freearticlespinning.com/), [article-spinner](http://free-article-spinner.com/)

***

#### Text to Speech

* [Balabolka](http://balabolka.site/bportable.htm) / [2](http://www.cross-plus-a.com/bportable.htm)
* [15.ai](https://15.ai/)
* [Text To Speech](https://texttospeech.ca/)
* [ttsMP3](https://ttsmp3.com/)
* [Spik](https://www.spik.ai/)
* [TextToMP3](https://www.texttomp3.online/)
* [Vo.codes](https://vo.codes/)
* [Woord](https://www.getwoord.com/) 
* [Speakonia](https://archive.org/details/speakonia_1036)
* [TextToSpeech](https://texttospeech.io/)
* [SAPI4](https://tetyys.com/SAPI4/)
* [LazyPY](https://lazypy.ro/tts/)
* [Vanilla Voice](https://www.vanillavoice.com/)
* [Sam](https://discordier.github.io/sam/), [2](https://simulationcorner.net/index.php?page=sam) / [BetterSam](https://imrane03.github.io/better-sam/)
* [MicrosoftSamOnline](https://lingojam.com/MicrosoftSamOnline)
* [TTSFree](https://ttsfree.com/)
* [Wideo](https://wideo.co/text-to-speech/)
* [VoiceGenerator](https://voicegenerator.io/)
* [Text to Speech Free](https://www.texttospeechfree.com/)
* [Lovo ai](https://www.lovo.ai/) 
* [TextToSpeechRobot](https://texttospeechrobot.com/)
* [SoundofText](https://soundoftext.com/)
* [FreeTTS](https://freetts.com/) 
* [zvukogram](https://zvukogram.com/)
* [Nuance](https://www.nuance.com/de-de/omni-channel-customer-engagement/voice-and-ivr/text-to-speech.html)
* [VoiceMaker](https://www.voicemaker.in/)
* [Uberduck](https://uberduck.ai/) / [Discord](https://discord.gg/ATYWnMu)
* [readloud](https://readloud.net/)
* [NaturalReaders](https://www.naturalreaders.com/online/)
* [TTS](https://github.com/coqui-ai/tts)

***

#### TikTok Video Downloaders

[SnapTik](https://snaptik.app/), [RipTok](https://github.com/adamsatyr/RipTok), [TikMate](https://www.tikmate.online/), [TokDer](https://tokder.org/), [tikmate](https://tikmate.app/), [tikfast](https://tikfast.net/), [SaveTT](https://savett.cc/), [ssstikvideo](https://www.ssstikvideo.com/)

***

#### Tor Search Engines

[Search-Darkweb](https://iaca-darkweb-tools.com/search-darkweb/), [Phobos](http://phobosxilamwcg75xt22id7aywkzol6q6rfl2flipcqoc4e4ahima5id.onion/), [Onions Search](https://onionsearchengine.com/), [OnionLandSearch](https://onionlandsearchengine.com/), [Ahmia](https://ahmia.fi/) / [Git](https://github.com/ahmia/ahmia-site ), [Onion.live](https://onion.live/), [Darkdump](https://github.com/josh0xA/darkdump), [doku](http://ujnkg4uirpaiqejr.onion/doku.php), [VisiTOR](http://visitorfi5kl7q7i.onion/), [Tornet](http://tgs5dkeqkg5hrjjk.onion/), [Torgle](http://torglejzid2cyoqt.onion/), [Tordex](http://tordex7iie7z2wcg.onion/), [Torch](http://xmh57jrzrnw6insl.onion/) / [2](http://26ozf35d2rwtmqbk.onion/), [Tor Search Engine](http://searchcoaupi3csb.onion/) / [2](http://searcherc3uwk535.onion/), [Tor Search](http://torsearchruby56z.onion/), [Torrentz 2](http://torrentzwealmisr.onion/), [Tormax](http://tormaxunodsbvtgo.onion/), [Tor77](http://tor77orrbgejplwp.onion/), [Tor66](http://tor66sezptuu2nta.onion/), [Start](http://kaarvixjxfdy2wv2.onion/), [SearX](http://5plvrsgydwy2sgce.onion/), [Phobos](http://phobosxilamwcg75xt22id7aywkzol6q6rfl2flipcqoc4e4ahima5id.onion/), [OnionLand Search Engine](http://3bbaaaccczcbdddz.onion/), [Onion Search Service](http://oss7wrm7xvoub77o.onion/), [Onion Search Engine](http://5u56fjmxu63xcmbk.onion/) / [2](http://onionf4j3fwqpeo5.onion/), [Onion Center](http://oikgfwfqmqkph4rl.onion/), [Onion Bag](http://onionbagy25be2bg.onion/), [Not Evil](http://hss3uro2hsxfogfq.onion/), [MultiVAC](http://multivacigqzqqon.onion/), [I2P Search](http://i2psesltivefcujc.onion/), [Haystak](http://haystakvxad7wbk5.onion/), [Grams](http://grams7ebnju7gwjl.onion/), [Google.Onion](http://ggonionvhfq7brmj.onion/), [Excavator](http://2fd6cemt4gmccflhm6imvdfvli3nf7zn6rfrwpsy7uhxrgbypvwf5fad.onion/), [Evo Search](http://evo7no6twwwrm63c.onion/), [DDG](http://3g2upl4pq6kufc4m.onion/), [Dark Web Links](http://jdpskjmgy6kk4urv.onion/), [Candle](http://gjobqjj7wyczbqie.onion/), [BTDigg](http://btdiggwzoyrwwbiv.onion/), [Ahmia](http://msydqstlz2kzerdg.onion/), [Tor.Link](https://tor.link/)

***

#### Tor Tools

[Wiki](https://gitlab.torproject.org/tpo/team/-/wikis/home) / [Unblock Tor](https://i.imgur.com/bQStFyI.gifv) / [Anonymity Tips](https://support.torproject.org/#staying-anonymous) / [Leak Scan](https://github.com/s-rah/onionscan) / [IP Test](https://check.torproject.org/) / [Auto IP Switch](https://github.com/seevik2580/tor-ip-changer) / [Access Client](https://dragonfruit.network/onionfruit) / [GitHub](https://github.com/dragonfruitnetwork/onionfruit/) / [Python Controller](http://vt5hknv6sblkgf22.onion/index.html) / [Default Gateway](https://github.com/htrgouvea/nipe) / [Network Script](https://github.com/ruped24/toriptables2) / [Proxy](https://reqrypt.org/tallow.html), [2](https://github.com/basil00/TorWall), [3](https://www.whonix.org/)

***

#### Torrent to GDrive

**Note** - Use throwaway accounts with these

**Collab**

**[OneClickRun](https://colab.research.google.com/github/biplobsd/OneClickRun/blob/master/OneClickRun.ipynb)** / [GitHub](https://github.com/biplobsd/OneClickRun), [Colab-Hacks Bot](https://colab.research.google.com/github/PradyumnaKrishna/Colab-Hacks/blob/master/Torrent%20Downloader/Torrent%20Downloader.ipynb) / [GitHub](https://github.com/PradyumnaKrishna/Colab-Hacks), [MasterColab](https://colab.research.google.com/github/yunooooo/Master-Colab/blob/master/Master-Colab.ipynb%20) / [GitHub](https://github.com/yunooooo/Master-Colab), [QBit to Gdrive](https://colab.research.google.com/github/Xavy-13/qbittorrent/blob/main/qBittorrent.ipynb) / [GitHub](https://github.com/xavy-13/qbittorrent) / [How-To](https://rentry.co/TorrentColab), [Torrent_To_Google_Drive_Downloader](https://colab.research.google.com/github/FKLC/Torrent-To-Google-Drive-Downloader/blob/master/Torrent_To_Google_Drive_Downloader.ipynb)

**Bots** 

[Torrent all-in-one bot](https://github.com/patheticGeek/torrent-aio-bot), [Codemaster](https://github.com/mohitjoshi155/Codemaster), [Mirror-Bot](https://github.com/KenHV/Mirror-Bot), [TorrentLeech](https://github.com/alfianandaa/TorrentLeech-Gdrive), [google-drive-torrent](https://github.com/karl-chan/google-drive-torrent), [torrents-to-google_drive](https://github.com/dabare/torrents-to-google_drive), [EmbetaCloud](https://github.com/Mrigank11/embetacloud), [TorrentMega2GoogleDrive](https://github.com/kakamband/TorrentMega2GoogleDrive), [Torrent-To-Google-Drive-Downloader](https://github.com/puki56/Torrent-To-Google-Drive-Downloader), [Torrents-to-Google-Drive](https://github.com/cheems/Torrents-to-Google-Drive), [Slam MirrorBot](https://github.com/SlamDevs/slam-mirrorbot)

**Telegram Bots**

* https://t.me/TorrentBots (List)
* https://t.me/kltorrents 
* https://t.me/torrent_drive_direct_llinks_bot
* https://t.me/TorrentXbot
* https://t.me/torrentdrive_bot
* https://t.me/tgpublicdrive
* https://t.me/publicdrive
* https://t.me/torrent_2_drive
* https://t.me/torrent_drive
* https://t.me/XtremeCloud 
* https://t.me/torrentbcloudnew
* https://t.me/mirrorLeechTelegramBot
* https://t.me/vipercloud 
* https://t.me/Punishercloud
* https://t.me/KS_LeechStore1
* https://t.me/TorrentLeech_v 
* https://t.me/torrent_mirror_drive
* https://t.me/slfilmtv
* https://t.me/ARTEMiSLeech 
* https://t.me/torrent_uploader
* https://t.me/Punisherdiscussion
* https://t.me/torrent_leech
* https://t.me/RakaPublicLeech
* https://t.me/TorrentPadu
* https://t.me/joinchat/Uq7xK07NNu2v4efS
* https://t.me/torrentogdrive23
* https://t.me/torrent_magnet
* https://t.me/gtorr
* https://t.me/requestinggroup
* https://t.me/UniComTorrent 
* https://t.me/TorrentMir
* https://github.com/yash-dk/TorToolkit-Telegram
* https://pythonrepo.com/repo/ayushteke-slam_aria_mirror_bot_HEROKU
* https://github.com/ogkunald/Torrent-Drive-Telegram-Bot-Using-Colab
* https://t.me/TorrentBots (list)
* https://t.me/TorrentLeechingGroup (list)
* https://t.me/MirrorBots (list) 

*** 

#### Torrentz2 Magnet Links

[Firefox](https://addons.mozilla.org/en-US/firefox/addon/torrentz2-magnet-links/), [Chrome](https://chrome.google.com/webstore/detail/magnet-links-for-torrentz/hkobljcmoojndbempmmgagaphocpmkni), [Userscript](https://greasyfork.org/en/scripts/21547-torrentz2-magnet)

***

#### Tracker Lists

[ngosang](https://ngosang.github.io/trackerslist/) / [2](https://ngosang.github.io/trackerslist/trackers_all.txt), [trackerslist](https://trackerslist.com/) / [2](https://github.com/XIU2/TrackersListCollection), [fossbytes list](https://fossbytes.com/torrent-trackers-list/), [NewTrackOn](https://newtrackon.com/list)

***

#### Translation Sites

[DeepL](https://www.deepl.com/), [Papago](https://papago.naver.com/), [Libretranslate](https://libretranslate.com/) / [2](https://github.com/uav4geo/LibreTranslate), [Translate.com](https://www.translate.com/), [MyMemory](https://mymemory.translated.net/), [Lingva](https://lingva.ml/), [Nice Translator](https://nicetranslator.com/), [Yandex Translator](https://translate.yandex.com/), [Bring Translator](https://www.bing.com/translator), [Reverso](https://www.reverso.net/), [GTranslate](https://git.sr.ht/~yerinalexey/gtranslate), [babelfish](https://www.babelfish.com/), [translation2](https://translation2.paralink.com/), [Free Translations](https://www.freetranslations.org/), [Apertium](https://apertium.org/), [collinsdictionary](https://www.collinsdictionary.com/translator), [online-translator](https://www.online-translator.com/translation), [translation](https://translation.babylon-software.com/), [translatedict](https://www.translatedict.com/), [QTranslate](https://quest-app.appspot.com/), [Systrane Translate](https://www.systran.net/en/translate/), [SimplyTranslate](https://simplytranslate.org/), [Translator.eu](https://www.translator.eu/), [worldlingo](https://www.worldlingo.com/en/), [Translatelocally](https://translatelocally.com/)

***

#### Typing Lessons

**Lessons** - **[TypingSoft](https://typingsoft.com/)** (Index), [keybr](https://www.keybr.com/), [Monkey Type](https://monkeytype.com/), [Typing.com](https://www.typing.com/), [Colemak Academy](https://www.colemak.academy/), [klavaro](https://klavaro.sourceforge.io/), [TIPP10](https://www.tipp10.com/), [RapidTyping](https://rapidtyping.com/), [TypeLit.io](https://www.typelit.io/) (Novels), [Typing Club](https://www.typingclub.com/), [Ratatype](https://www.ratatype.com/), [JustType](http://www.greatis.com/utilities/justtype/), [Rasyti](https://www.blueseal.eu/rasyti/), [SoloTyping](http://solotyping.com/?locale_id=2), [TypeFast](https://typefast.io/), [TypingBolt](https://www.typingbolt.com/), [AmpheType](https://code.google.com/archive/p/amphetype/), [Stamina](https://typingsoft.com/stamina.htm),[goodtyping](https://www.goodtyping.com/),  [Typing-Fingers](http://www.typing-fingers.com/), [Typing Arena](http://www.typingarena.com/), [TheTypingCat](https://thetypingcat.com/), [typing.academy](https://www.typing.academy/), [TechTypingTutor](https://sourceforge.net/projects/tachtypingtutor/), [klavaro](https://sourceforge.net/projects/klavaro/), [TypingTest](https://www.typingtest.com/), [10fastfingers](https://10fastfingers.com/), [onlinetyping](https://onlinetyping.org/), [Thokr](https://github.com/coloradocolby/thokr), [Ttyper](https://github.com/max-niederman/ttyper), [TermTyper](https://github.com/kraanzu/termtyper)

**Games** - [TypeRacer](https://play.typeracer.com/), [ZType](https://zty.pe/), [NitroType](https://www.nitrotype.com/), [Keyma.sh](https://keyma.sh/), [TypeRush](https://www.typerush.com/)

***

#### Twitch Adblockers

**[Purple AdBlock](https://addons.mozilla.org/en-US/firefox/addon/purpleadblock/)**, [TTV LOL](https://chrome.google.com/webstore/detail/ttv-lol/ofbbahodfeppoklmgjiokgfdgcndngjm), [TwitchAdSolutions](https://github.com/pixeltris/TwitchAdSolutions), [VideoAdBlockForTwitch](https://github.com/cleanlock/VideoAdBlockForTwitch), [Adblocker for Twitch - Edge](https://microsoftedge.microsoft.com/addons/detail/adblocker-for-twitch%E2%84%A2/glgpmlmjlaljaddimbgekaepkgbojjdn)

note - You can also enable "Peter Lowe’s Ad and tracking server list" to block twitch ads

***

#### uBlock Filters

**[FilterStalker](https://rentry.co/FilterStalker)**, [yokoffing/filterlists](https://github.com/yokoffing/filterlists), [dbl.oisd.nl](https://oisd.nl/) / [2](https://hosts.oisd.nl/), [FilterLists](https://filterlists.com/), [webannoyances](https://github.com/yourduskquibbles/webannoyances), [fuck fuckadblock](https://bogachenko.github.io/fuckfuckadblock/), [The Block List Project](https://blocklistproject.github.io/Lists/), [ADFILT](https://github.com/DandelionSprout/adfilt), [EasyList](https://easylist.to/) / [Forum](https://forums.lanik.us/), [urlhaus-filter](https://gitlab.com/curben/urlhaus-filter), [iBlocklist](https://www.iblocklist.com/), [LetBlock.it](https://letsblock.it/), [Energized Protection](https://github.com/EnergizedProtection/block), [Additional Undesired Hosts](https://github.com/DRSDavidSoft/additional-hosts), [Noads](https://github.com/deletescape/noads), [PersonalFilterListCollection](https://github.com/kowith337/PersonalFilterListCollection), [my_filter_list](https://github.com/Serdar006/my_filter_list), [fanboy](https://www.fanboy.co.nz/), [CoinBlockerLists](https://zerodot1.gitlab.io/CoinBlockerLists/list_browser_UBO.txt), [NoTracking blocklist](https://github.com/notracking/hosts-blocklists), [d3ward](https://raw.githubusercontent.com/d3ward/toolz/master/src/d3host.txt), [notracking](https://raw.githubusercontent.com/notracking/hosts-blocklists/master/adblock/adblock.txt), [lan-block](https://raw.githubusercontent.com/gwarser/filter-lists/master/lan-block.txt), [developerdan](https://www.github.developerdan.com/hosts/), [scamblocklist](https://raw.githubusercontent.com/durablenapkin/scamblocklist/master/hosts.txt), [NoADS_RU](https://raw.githubusercontent.com/Zalexanninev15/NoADS_RU/main/ads_list.txt), [iploggerfilter](https://github.com/piperun/iploggerfilter), [Anifiltrs](https://github.com/Karmesinrot/Anifiltrs), [GoodbyeAds](https://goodbyeads.weebly.com/), [neodevhost](https://github.com/neodevpro/neodevhost), [jmdugan/blocklists](https://github.com/jmdugan/blocklists), [referrer-spam-list)](https://github.com/matomo-org/referrer-spam-list), [black-mirror](https://github.com/T145/black-mirror), [CombinedPrivacyBlockLists](https://github.com/bongochong/CombinedPrivacyBlockLists), [hblock](https://hblock.molinero.dev/), [spam404](https://www.spam404.com/), [blacklist](https://github.com/anudeepND/blacklist), [energized](https://energized.pro/), [Clear URLs](https://raw.githubusercontent.com/DandelionSprout/adfilt/master/ClearURLs%20for%20uBo/clear_urls_uboified.txt), [TheFuckingList](https://github.com/eded333/TheFuckingList)

* [YouTube Filters](https://github.com/Ewpratten/youtube_ad_blocklist)
* [Facebook Filters](https://www.reddit.com/r/uBlockOrigin/wiki/solutions#wiki_facebook) 

***

#### Udemy Coupons

**[CouponScorpion](https://couponscorpion.com/)**, [discudemy](https://www.discudemy.com/), [bestcouponhunter](https://bestcouponhunter.com/), [Coursevania](https://coursevania.com/), [Learn Viral](https://udemycoupon.learnviral.com/), [BARONIP COUPONS](https://baronip-coupons.blogspot.com/), [Course Time](https://coursetime.net/), [iDownloadCoupon](http://idownloadcoupon.com/), [udemycoupons](https://udemycoupons.me/), [lorebeam](https://www.lorebeam.com/), [coursecouponclub](https://coursecouponclub.com/), [coursekingdom](https://coursekingdom.xyz/), [freebiesglobal](https://freebiesglobal.com/), [real.discount](https://www.real.discount/), [onlinecourses](https://www.onlinecourses.ooo/), [cursosdev](https://cursosdev.com/), [100offdeal](https://100offdeal.online/), [freshercooker](https://www.freshercooker.com/category/courses/), [dailycoursereviews](https://dailycoursereviews.com/)

***

#### URL Unshorteners 

**[urlex](https://urlex.org/)**, **[CheckShortURL](https://checkshorturl.com/)**, [ExpandURL](https://www.expandurl.net/), [Unshorten.it](https://unshorten.it/), [WhereGoes](https://wheregoes.com/), [LongURL](https://longurl.info/), [urlxray](http://urlxray.com/), [unshorten](https://unshorten.me/), [trueurl](http://www.trueurl.net/)

***

#### Userscript Managers

**[Greasymonkey](https://www.greasespot.net/)**, [Tampermonkey](https://www.tampermonkey.net/), [Violentmonkey](https://violentmonkey.github.io/), [Firemonkey](https://addons.mozilla.org/en-US/firefox/addon/firemonkey/) 

***

#### VFX Sites

[FootageCrate](https://footagecrate.com/), [MATESFX](https://www.freevideoeffect.com/), [FreeVideoEffect](https://freevideoeffect.com/), [VideoCoPilot](https://www.videocopilot.net/), [IntroHD](https://www.introhd.net/), [VFXmed](https://www.vfxmed.com/), [VFXDownload](https://www.vfxdownload.net/)

**After Effects**

[ShareAE](https://www.shareae.com/), [HunterAE](https://hunterae.com/), [AEShares](https://aeshares.com/), [AEDownload](https://aedownload.com/), [AERiver](https://aeriver.com/), [CGNullded](https://cgnulled.com/), [Intro HD](https://intro-hd.net/), [AEDownloadPro](https://www.aedownloadpro.com/) [DownAE](https://downae.com/), [Adobe After Effects Collection](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/base64#wiki_adobe_after_effects_collection)

***

#### Video Chat

[Jitsi](https://desktop.jitsi.org/index.html) / [2](https://meet.jit.si/), [Zoom-Clone](https://github.com/Shouraya/Zoom-Clone), [Join.me](https://www.join.me/), [kemeet](https://kemeet.vercel.app/), [WorkshopX](https://workshopx.app/), [MiroTalk](https://mirotalk.up.railway.app/), [p2p.chat](https://p2p.chat/) / [GitHub](https://github.com/tom-james-watson/p2p.chat), [Whereby](https://whereby.com/), [Videolink2me](https://videolink2me.com/), [TinyChat](https://tinychat.com/), [Noysi Meet](https://meet.noysi.com/), [Zipcall](https://meet.questo.ai/), [Talk](https://usetalk.io/) / [GitHub](https://github.com/vasanthv/talk), [iqc](https://icq.com/), [Crewdle](https://crewdle.com/), [Briefing](https://brie.fi/ng), [Airmeet](https://www.airmeet.com/), [Brave Talk](https://brave.com/talk/), [Brave Talk](https://talk.brave.com/), [WebCall](https://timur.mobi/webcall/) / [GitHub](https://github.com/mehrvarz/webcall)

***

#### Video Converters

**[HandBrake](https://handbrake.fr/)** / [Guide](https://www.rapidseedbox.com/blog/guide-to-mastering-handbrake), [XMedia Recode](https://www.xmedia-recode.de/en/), [staxrip](https://github.com/staxrip/staxrip/) / [Guide](https://telegra.ph/HEVC-Encoding-with-StaxRip-Settings-for-best-compression-included-05-12 ), [FastFlix](https://fastflix.org/), [AVC](https://www.any-video-converter.com/), [NEAV1E](https://github.com/Alkl58/NotEnoughAV1Encodes), [MP4.to](https://mp4.to/), [Evano](https://evano.com/online-video-converter), [mp4 Video Converter](https://github.com/mebsic/mp4), [OnlineVideoConverter](https://onlinevideoconverter.party/), [WebmtoMP4](https://webmtomp4.com/), [WebM.to](https://webm.to/), [MakeMKV](https://www.makemkv.com/), [Video2Edit](https://www.video2edit.com/), [Winnydows](https://winnydows.com/en/), [RipBot264](https://www.videohelp.com/software/RipBot264), [MeGUI](https://www.videohelp.com/software/MeGUI), [sickbeard_mp4_automator](https://github.com/mdhiggins/sickbeard_mp4_automator), [automatic-ripping-machine](https://b3n.org/automatic-ripping-machine/), [FastFlix](https://github.com/cdgriffith/FastFlix), [avisynth](http://avisynth.nl/index.php/Main_Page), [ShutterEncode](https://www.shutterencoder.com/en/), [Video Express Converter](https://vc.germanov.dev/), [SafeVideoConverter](https://safevideoconverter.com/), [Av1an](https://github.com/master-of-zen/Av1an), [MediaCoderHQ](http://www.mediacoderhq.com/), [Modfy](https://app.modfy.video/) / [GitHub](https://github.com/modfy), [Seven Converter](http://converter.sevenbytes.com/) / [GitHub](https://github.com/SevenbytesSoftware/SevenConverter), [JS Video Converter](https://js-video-converter.com/), [nmkoder](https://github.com/n00mkrad/nmkoder), [AVS4YOU](https://www.avs4you.com/), [VideoConverter](https://videoconverter.com/)

***

#### Video Resumer

[Firefox](https://addons.mozilla.org/en-US/firefox/addon/video-resumer), [Chrome](https://chrome.google.com/webstore/detail/video-resumer/bongjkoajofkfpofginnhecihgaeldpe) 

***

#### Video Editors

**Programs**

[Olive](https://www.olivevideoeditor.org/), [VirtualDub2](https://sourceforge.net/projects/vdfiltermod/files/), [LosslessCut](https://github.com/mifi/lossless-cut), [DaVinci Resolve](https://www.blackmagicdesign.com/products/davinciresolve), [Shotcut](https://shotcut.org/), [FreeMake](https://www.freemake.com/how_to/free_movie_maker), [EZVid](https://www.ezvid.com/), [OpenShot](https://www.openshot.org/), [Shotcut](https://www.shotcut.org/), [HitFilm](https://fxhome.com/product/hitfilm-express), [kdenlive](https://kdenlive.org/en/), [Lightworks](https://www.lwks.com/), [Windows Movie Maker](https://www.majorgeeks.com/files/details/windows_movie_maker.html) / [2](https://archive.org/details/MM2.1And2.6_201903) / [3](https://archive.org/details/mm26enu_202002), [SimpleMovieMaking](https://simplemoviemaking.com/), [VSDC](http://www.videosoftdev.com/), [Auto-Editor](https://auto-editor.com/) (CLI), [MoviePy](https://zulko.github.io/moviepy/) (Python), [avidemux](http://avidemux.sourceforge.net/), [GOMlab](https://gomlab.com/), [Remotion](https://www.remotion.dev/) / [GitHub](https://github.com/remotion-dev/remotion), [Microsoft 3D Movie Maker](https://github.com/microsoft/Microsoft-3D-Movie-Maker), [MiniTool](https://moviemaker.minitool.com/), [Moovly](https://www.moovly.com/)

**Online Editors**

[Clideo](https://clideo.com/), [Kapwing](https://www.kapwing.com/), [InVideo](https://invideo.io/), [Biteable](https://biteable.com/), [Mastershot](https://mastershot.app/), [Panzoid](https://panzoid.com/), [KeepVid](https://keepvid.com/), [KeepChangeIt](https://keepchangeit.com/), [Flexclip](https://www.flexclip.com/), [veed.io](https://www.veed.io/tools/video-editor), [FastReel](https://www.fastreel.com/), [Convert2Video](https://convert2video.com/), [Video Cutter](https://video-cutter-js.com/), [FlexClip](https://www.flexclip.com/), [Vididoo](https://vididoo.vercel.app/), [VideoToolbox](http://www.videotoolbox.com/), [VideoCandy](https://videocandy.com/), [Animoto](https://animoto.com/), [Flixier](https://editor.flixier.com/), [LayerHub](https://editor.layerhub.io/)

***

#### Video Hosting Sites

[mixdrop](https://mixdrop.co/), [vudeo (8tb)](https://vudeo.net/), [vidyard](https://www.vidyard.com/), [streamzz](http://streamzz.to/), [streamtape](https://streamtape.com/), [doodstream](https://doodstream.com/), [aparat](https://aparat.cam/), [supervideo](https://supervideo.tv/), [ninjastream](https://ninjastream.to/), [youdbox](https://youdbox.com/), [cloudvideo](https://cloudvideo.tv/),  [powvideo](http://powvideo.net/), [upstream](https://upstream.to/), [videobin](https://videobin.co/), [streamable](https://streamable.com/), [abyss](https://abyss.to/), [NetU](https://netu.io/view_page.php?pid=4), [voe.sx](https://voe.sx/), [videy](https://videy.co/), [wolfstream](https://wolfstream.tv/), [flashx](https://flashx.pw/), [userload](https://userload.co/), [vidcloud](https://vidcloud.co/), [vidoza](https://vidoza.net/), [youdbox](https://youdbox.net/), [fileone](https://fileone.tv/), [streamlare](https://streamlare.com/), [videovard](https://videovard.to/), [streamsb](https://www.streamsb.com/), [HighStream](https://highstream.tv/), [uqload](https://uqload.com/), [anavidz](https://anavidz.com/), [vupload](https://vupload.com/), [speedostream](https://www.speedostream.com/), [sendvid](https://sendvid.com/), [videovard](https://videovard.sx/), [HighLoad](https://highload.to/)

***

#### Video Players

* **[MPC-HC](https://github.com/clsid2/mpc-hc/releases/)**, [MPC-BE](https://sourceforge.net/projects/mpcbe/) / [Fork](https://github.com/clsid2/mpc-hc)
* **[MPV](https://mpv.io/)** / [2](https://mpv-net.github.io/mpv.net-web-site/), [MPV.net](https://github.com/stax76/mpv.net), [MPV-EASY-Player](https://github.com/422658476/MPV-EASY-Player), [mpv.snad](https://github.com/thisisshihan/mpv.snad)
* [VLC](https://www.videolan.org/)
* [Pot Player](http://potplayer.daum.net/)
* [SMPlayer](https://www.smplayer.info/) / [2](https://sourceforge.net/projects/smplayer/) / [YouTube](https://www.smtube.org/)
* [uView](https://www.idruf.com/)
* [Rise Media Player](https://github.com/Rise-Software/Rise-Media-Player)
* [KikoPlay](https://kikoplay.fun/) - [GitHub](https://github.com/KikoPlayProject/KikoPlay/)

**Video Player Tools**

* MPV Tools - [Tools](https://github.com/VideoPlayerCode/mpv-tools) / [Frontends](https://github.com/mpv-player/mpv/wiki/Applications-using-mpv) / [Modern UI](https://github.com/cyl0/MordenX), [2](https://github.com/Zren/mpv-osc-tethys) / [Context Menu](https://gitlab.com/carmanaught/mpvcontextmenu) / [Sub Navigation](https://github.com/perogiue/mpv-scripts/releases/) / [Sub Sync](https://github.com/joaquintorres/autosubsync-mpv) / [SponsorBlock](https://github.com/po5/mpv_sponsorblock) / [MPV-DiscordRPC](https://github.com/cniw/mpv-discordRPC) / [MPC-DiscordRPC](https://github.com/angeloanan/MPC-DiscordRPC) / [Config Guide](https://rentry.co/MPV-Config), [2](https://kokomins.wordpress.com/2019/10/14/), [3](https://hooke007-github-io.translate.goog/unofficial/index.html?_x_tr_sl=auto&_x_tr_tl=en&_x_tr_hl=en-US&_x_tr_pto=wapp) / [File Associations](https://github.com/rossy/mpv-install)
* VLC Tools - [Resources](https://github.com/mfkl/awesome-vlc), [Browser Control](https://mybrowseraddon.com/remote-vlc-player.html) / [Sub Downloader](https://github.com/exebetche/vlsub) / [OpenWithVLC](https://addons.mozilla.org/en-US/firefox/addon/open-with-vlc/) / [Slow Seek Fix](https://redd.it/os6f1q) / [Skins](https://www.videolan.org/vlc/skins.php)
* [Video Player Codecs](http://www.codecguide.com/download_kl.htm)
* [Windows Media Player Skins](https://web.archive.org/web/20100827223732/http://windows.microsoft.com/en-US/windows/downloads/windows-media-player/skins?T1=all) / [2](https://wmpskinsarchive.neocities.org/)

***

####  Video Stream Sync

[Giggl](https://giggl.app/), [neko](https://neko.m1k1o.net/) / [GitHub](https://github.com/m1k1o/neko), [SyncPlay](https://syncplay.pl/), [CyTube](https://cytu.be/), [HyperBeam](https://hyperbeam.com/), [Kast](https://kast.gg/), [Gaze](https://letsgaze.com/), [twoseven](https://twoseven.xyz/), [Metastream](https://getmetastream.com/), [Trast](https://trast.live/), [Watch2Gether](https://w2g.tv/), [Vynchronize](https://vynchronize.herokuapp.com/), [SyncTube](https://sync-tube.de/), [Kosmi](https://kosmi.io/), [Invited.tv](https://invited.tv/), [Caracal Club](https://caracal.club/), [baked.live](http://baked.live/), [Surge](https://surge.live/), [Screen Share Party](https://ba.net/screen/), [WatchParty](https://www.watchparty.me/), [Stream New](https://stream.new/) / [GitHub](https://github.com/muxinc/stream.new), [bear.cat](https://bear.cat/), [TurtleTV](https://turtletv.app/), [OpenTogetherTube](https://opentogethertube.com/), [WatchPubs](https://watchpubs.com/), [MovieNight](https://github.com/zorchenhimer/MovieNight)

***

#### Video Search Sites

Good for finding classic, obscure & short films. 

* **[Video Search Sites CSE](https://cse.google.com/cse?cx=006516753008110874046:6v9mqdaai6q#gsc.tab=0)** - Multi-Video Site Search
* **[noodlemagazine](https://noodlemagazine.com)**, [2](https://mat6tube.com/), [3](https://18.tyler-brown.com/) - Lots of NSFW
* **[OK](https://ok.ru/video)** 
* [YouTube](https://www.youtube.com/) / [Advanced](https://playlists.at/youtube/search/)
* [Archive](https://archive.org/) 
* [Dailymotion](https://www.dailymotion.com/us) 
* [bilibili](https://www.bilibili.com/) / [Client](https://github.com/Richasy/Bili.Uwp)
* [Vimeo](https://vimeo.com/)
* [0xDB](https://0xdb.org/) - [How-to](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/find-rare-movies#wiki_method_2_-_streaming)
* site:vk.com (add to search)
* [my.mail.ru](https://my.mail.ru/video) + try adding `site:my.mail.ru` to a search
* [Veoh](https://www.veoh.com/)
* [Facebook Videos](https://www.facebook.com/watch/search/?query=fmhy)
* [Ronemo](https://ronemo.com/)
* [rutube](https://rutube.ru) - account required
* [nicovideo](https://www.nicovideo.jp/) 
* [lbry](https://lbry.tv/) / [Frontend](https://librarian.bcow.xyz/)
* [cda.pl](https://www.cda.pl/)
* [tilvids](https://tilvids.com/)
* [bitchute](https://www.bitchute.com/)
* [PeerTube](https://joinpeertube.org/), [2](https://search.joinpeertube.org/) / [Instances](https://instances.joinpeertube.org/instances)
* [V-S Mobi](https://v-s.mobi/) 
* [Videa](https://videa.hu/)
* [youku](https://www.youku.com/)
* [zloekino](https://zloekino.su/)
* [metacafe](https://www.metacafe.com)
* [Aparat](https://www.aparat.com/)
* [NewTube](https://newtube.app/)
* [tudou](https://www.tudou.com/) 
* [BitView](https://www.bitview.net/)
* [Vidlii](https://www.vidlii.com/)
* [Naver](https://tv.naver.com/)
* [vdube](https://www.vdube.com/)
* [ultimedia](https://www.ultimedia.com/)
* [odysee](https://odysee.com/)
* [UTreon](https://utreon.com/)
* [Rumble](https://rumble.com/)
* [tubidy](https://tubidy.com/) 
* [lbry](https://lbry.com/) - App
* [commons.wikimedia](https://commons.wikimedia.org/wiki/Category:Videos) 
* [Myspace Videos](https://myspace.com/search/videos) 
* [Google Videos](https://www.google.com/?tbm=vid)
* [Yandex Videos](https://yandex.ru/video) 
* [DuckDuckGo Videos](https://duckduckgo.com/?q=freemediaheckyeah&iar=videos&iax=videos&ia=videos)
* [Uloz](https://ulozto.net/) - Short Film Downloads
* [PeteyVid](https://www.peteyvid.com/) - Multi-Site Video Search 

***

#### VSCode Tools

[Open VSX Registry](https://open-vsx.org/) / [Snippet Generator](https://snippet-generator.app/) / [Discord Tools](https://github.com/Darkempire78/Discord-Tools) / [Twitch Hightlighter](https://marketplace.visualstudio.com/items?itemName=clarkio.twitch-highlighter) / [Smart Clicks](https://github.com/antfu/vscode-smart-clicks) / [Browser](https://vscode.dev/), [2](https://code.cs50.io/) / [Settings](https://github.com/antfu/vscode-settings) / [Insider Build](https://insiders.vscode.dev/) / [Logo Extension](https://github.com/tale/logos-vscode) / [Pets](https://marketplace.visualstudio.com/items?itemName=tonybaloney.vscode-pets)

**VSCode Themes** 

[VSCodeThemes](https://vscodethemes.com/) / [Dark Theme](https://github.com/whiplashoo/dartcula-theme) / [Extensions](https://hl2guide.github.io/Awesome-Visual-Studio-Code-Extensions/), [2](https://marketplace.visualstudio.com/) / [Theme Generator](https://oslo-vsc.netlify.app/) / [Bracket Pair Colorizer 2](https://marketplace.visualstudio.com/items?itemName=CoenraadS.bracket-pair-colorizer-2)

***

#### Wallpapers

**[wallhaven](https://wallhaven.cc/)**, **[Wallpaper Abyss](https://wall.alphacoders.com/)**, [HD wallpapers](https://www.hdwallpapers.net/), [WallpaperFusion](https://www.wallpaperfusion.com/), [WallpaperAccess](https://wallpaperaccess.com/), [Wallpapers.com](https://wallpapers.com/), [Wallpaper Safari](https://wallpapersafari.com/), [CoolBackgrounds](https://coolbackgrounds.io/), [sys.re](https://sys.re/pics/wallpapers/), [WallpaperCave](https://wallpapercave.com/), [Positron Dream](https://www.positrondream.com/), [WalLegend](https://wallegend.net/en/), [SkinBase](https://skinbase.org/), [GetWalls](https://getwalls.io/), [Wallpapers](http://wallpapers.net/), [DualMonitorBackgrounds](https://www.dualmonitorbackgrounds.com/), [SocWall](https://www.socwall.com/), [ThewWallpapers](https://thewallpapers.org/), [WPGallery](http://www.wpgallery.com/), [wallpaperstock](https://wallpaperstock.net/), [vlad.studio](https://vlad.studio/wallpapers/?sort=free&filter=all), [ewallpapers](http://www.ewallpapers.eu/), [Bing Wallpaper](https://bingwallpaper.anerg.com/), [simpledesktops](http://simpledesktops.com/), [doostihaa](http://dl1.doostihaa.com/files/Wallpaper/), [Mac Wallpapers](https://goo.gl/photos/HjY1hmo6p3jfFz8a7) [2](https://photos.google.com/share/AF1QipNNQyeVrqxBdNmBkq9ILswizuj-RYJFNt5GlxJZ90Y6hx0okrVSLKSnmFFbX7j5Mg?key=RV8tSXVJVGdfS1RIQUI0Q3RZZVhlTmw0WmhFZ2V3), [Microsoft Wallpapers](https://wallpapers.microsoft.design/) / [2](https://mega.nz/folder/QZwW1LLZ#WFjZoQNQm7LfyQzr_rUNIA/folder/MEZTVYDB), [3](https://onedrive.live.com/?authkey=%21AGFudU5q0LqPcSY&id=84D7E222958B8EFB%2118111&cid=84D7E222958B8EFB), [WallpaperHub](https://wallpaperhub.app/), [Wallpaper Tip](https://wallpapertip.com/), [WallpaperFlare](https://www.wallpaperflare.com/), [hdqwalls](https://hdqwalls.com/), [uhdpaper](https://www.uhdpaper.com/), [wallpapersden](https://wallpapersden.com/), [arrowwallpapers](https://arrowwallpapers.blogspot.com/), [MovieMania](https://www.moviemania.io/), [Xbox Wallpapers](https://www.xbox.com/en-us/wallpapers/), [vsthemes](https://vsthemes.org/en/pictures/), [wallpaperscraft](https://wallpaperscraft.com/), [backiee](https://backiee.com/), [hdwallpapers](https://www.hdwallpapers.in/), [wallpaper-house](https://wallpaper-house.com/), [pixelstalk](https://www.pixelstalk.net/), [7-themes](http://7-themes.com/), [gettywallpapers](http://m.gettywallpapers.com/), [wallpaperset](https://wallpaperset.com/), [wallpapershome](https://wallpapershome.com/), [teahub](https://www.teahub.io/), [sfwallpaper](http://sfwallpaper.com/), [99images](https://www.99images.com/), [wallpaperbetter](https://www.wallpaperbetter.com/), [wallpaperforu](https://wallpaperforu.com/), [wallpapercrafter](https://wallpapercrafter.com/), [wallpapersmug](https://wallpapersmug.com/), [goldposter](https://wallpaper.goldposter.com/), [pikist](https://www.pikist.com/), [hdwallsbox](https://hdwallsbox.com/), [wallpaperbat](https://wallpaperbat.com/), [wallhere](https://wallhere.com/), [ilikewallpaper](https://www.ilikewallpaper.net/), [wallup](https://wallup.net/), [wallpaperup](https://www.wallpaperup.com/), [setaswall](https://www.setaswall.com/), [peakpx](https://www.peakpx.com/), [itl](https://www.itl.cat/), [papers](https://papers.co/), [pixel4k](https://www.pixel4k.com/), [suwalls](https://suwalls.com/), [GDrive Collection](https://photos.google.com/share/AF1QipO7LmX8oM3ZAyUuPAtwIWzbO5TjAppRfQ880DSuFR6jjcEzFysj4pAWThXUzO_tiw?key=aURJRDlneERpMmJnRmphdHRFRmdTMHJmbmlxZTNR) / [2](https://photos.google.com/share/AF1QipM66C99gz4-hP2dN_IdxdwWLz2cTTWuVARgxiqF3kNc_m0t2yxNCk8opZH6x7LIlQ?pli=1&key=LXROOG52Qi1STEZXeG1xaVk4UG02dUduSDBRUGZB) / [3](https://drive.google.com/drive/folders/1McO4o16fppflfn8I_62cML_s29nc1SvF), [drawstructure](https://drawstructure.vercel.app/), [ps4wallpapers](https://www.ps4wallpapers.com/), [wallha](https://wallha.com/), [justinmaller](http://justinmaller.com/wallpapers/), [4kwallpapers](https://4kwallpapers.com/), [wallpaperswide](http://wallpaperswide.com/), [wallpaper.dog](https://wallpaper.dog/), [MoeWalls](https://moewalls.com/)

**Telegram Wallpaper Channels** 

[wallpapers](https://t.me/wallpapers/), [ull_HD_4K_wallpapers](https://t.me/Full_HD_4K_wallpapers/), [WallpapersGram4K](https://t.me/WallpapersGram4K), [WallpapersGram](https://t.me/WallpapersGram/), [picsart_hd_background](https://t.me/picsart_hd_background), [wallpaper_profilei](https://t.me/wallpaper_profilei/), [Anime_WallpapersHD](https://t.me/Anime_WallpapersHD/), [allwallpaper](https://t.me/allwallpaper), [Wallpaper](https://t.me/Wallpaper), [ZedgeImagesBot](https://t.me/ZedgeImagesBot), [picsart_hd_background](https://t.me/picsart_hd_background), [wallpaperselection](https://t.me/wallpaperselection) [Hk3To](https://t.me/Hk3To) [jianoliuwalls](https://t.me/jianoliuwalls) [G_Walls](https://t.me/G_Walls) [EZwalls](https://t.me/EZwalls), [pengwyn](https://t.me/pengwyn), [Quotes_Wallpapers](https://t.me/Quotes_Wallpapers), [wallpapersite](https://www.wallpapersite.com/)

**Wallpaper Managers**

[Wallpaper Engine](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/base64#wiki_wallpaper_engine) / [PKG to Zip](https://github.com/TheRioMiner/Wallpaper-Engine-Pkg-to-Zip), [SuperDuperWallpaper](https://gitlab.com/sech1p/superduperwallpaper), [ScreenPlay](https://screen-play.app/), [backiee](https://www.microsoft.com/en-in/p/backiee-wallpaper-studio-10/9wzdncrfhzcd?activetab=pivot:overviewtab), [Daily Reddit Wallpaper](https://github.com/ssimunic/Daily-Reddit-Wallpaper), [Daily Bing Wallpaper](https://github.com/sfn101/bing-daily-lively-wallpaper), [Awesome Wallpaper](http://awesome-wallpaper.com/), [tanck.nl](https://tanck.nl/wallpaper/)

* [Wallery](https://github.com/metafates/Wallery) - Display Wallpapers
* [Faerber](https://farbenfroh.io/faerber) - Edit Wallpaper to Match Color Scheme

**Animated Wallpapers**

[/r/LivingBackgrounds](https://reddit.com/r/LivingBackgrounds), [wallpaperwaifu](https://wallpaperwaifu.com/), [Scenic Illustrations](https://www.pixeltrue.com/scenic-illustrations), [MyLiveWallpapers](https://mylivewallpapers.com/), [AnimatedBackgrounds](https://animatedbackgrounds.me/), [Lively](https://rocksdanister.github.io/lively/) (Create)

**Mobile Wallpapers** 

**[Mobile Abyss](https://mobile.alphacoders.com/)**, [Wallpaper Engine](https://www.wallpaperengine.io/android/en), [wallhaven](https://wallhaven.cc/search?categories=110&purity=100&ratios=portrait), [wallpaperfusion](https://www.wallpaperfusion.com/Apps/), [wallpaperaccess](https://wallpaperaccess.com/cat/devices), [wallpapers.com](https://wallpapers.com/mobile), [wallpapersafari](https://wallpapersafari.com/), [wallpapercave](https://wallpapercave.com/categories/devices), [positrondream](https://www.positrondream.com/wallpapers-all), [wallpaperstock](https://wallpaperstock.net/mobile-wallpapers.html), [simpledesktops](http://simpledesktops.com/app/android/), [wallpapertip](https://www.wallpapertip.com/), [wallpaperflare](https://www.wallpaperflare.com/search?wallpaper=vertical), [hdqwalls](https://hdqwalls.com/), [wallpapersden](https://wallpapersden.com/), [arrowwallpapers](https://arrowwallpapers.blogspot.com/), [moviemania](https://www.moviemania.io/phone), [iOS Wallpapers](https://goo.gl/photos/ZVpabTtcezd35XBa9/) / [2](https://photos.google.com/share/AF1QipNi8VN2pw2Ya_xCV8eFgzEZmiXDy1-GwhXbqFtvXoH3HypF10as9puV8FdoVZpOZA?key=WkZjQTIxQTM5a01oZkNUYTE2ZllKTVJKZk1CMTR3), [VectorifyDaHome](https://github.com/enricocid/VectorifyDaHome), [Doodle](https://patrick.zedler.xyz/doodle/), [backiee](https://backiee.com/), [AnimeLibrary_MobileWallpapers](https://t.me/AnimeLibrary_MobileWallpapers/), [Wallpapers_Phone_Mobile](https://t.me/Wallpapers_Phone_Mobile/), [iphone11papers](https://iphone11papers.com/), [Wallpapers Clan](https://wallpapers-clan.com/), [Wallme](https://f-droid.org/packages/com.alaory.wallmewallpaper/)

* [Darkinator](https://play.google.com/store/apps/details?id=com.tfuerholzer.darkmodewallpaper) - Change Wallpaper Depending on System Theme
* [wallpaperwaifu](https://wallpaperwaifu.com/), [Muzei](https://github.com/muzei/muzei), [Chroma Galaxy](https://play.google.com/store/apps/details?id=com.at2_software.terracollageapp), [Doodle](https://patrickzedler.com/doodle/) or [LiveLoop](https://play.google.com/store/apps/details?id=com.wallpaper.liveloop) - Live Android Wallpapers
* [koncius](https://play.google.com/store/apps/details?id=com.koncius.video.wallpaper) - Android Video to Wallpaper
* [Das Image](https://apps.apple.com/ca/app/das-image-search-and-explore/id1464079804) - iOS Wallpaper App

***

#### WCO Clones

* https://www.thewatchcartoononline.tv/
* https://www.wcostream.com/
* https://www.wcoforever.com/
* https://www.wcoanimesub.tv/
* https://www.wcoanimedub.tv/
* https://www.wcofun.com/
* https://www.wcoforever.net/ 

*** 

#### WebFont Changer

[Firefox](https://addons.mozilla.org/en-US/firefox/addon/web-font-changer/) / [Chrome](https://chrome.google.com/webstore/detail/font-changer/obgkjikcnonokgaiablbenkgjcdbknna)

***

#### Website Creators

[GoHugo](https://gohugo.io/), [SouPalt](https://soupault.app/), [Barly](https://github.com/charludo/barely), [Zola](https://www.getzola.org/), [Jamstack Generators](https://jamstack.org/generators/), [Hugo](https://gohugo.io/), [Jekyll](https://jekyllrb.com/), [Tails](https://devdojo.com/tails), [vveb](https://www.vvveb.com/), [Potion](https://www.potion.so/), [8b](https://8b.com/), [WebFlow](https://webflow.com/), [EasyLogic](https://www.easylogic.studio/), [Universe](https://onuniverse.com/), [Website.com](https://www.website.com/), [GrapeDrop](https://grapedrop.com/), [Specctr](https://specctr.com/cloud/home), [Astro](https://astro.build/), [TypeDream](https://typedream.com/), [Processwire](https://processwire.com/), [Google Sites](https://sites.google.com/new), [AngelFire](https://angelfire.com)

**Simple Site Creators**

[Straw.Page](https://straw.page/), [Own Free Website](https://www.own-free-website.com), [itty.bitty](https://itty.bitty.site/), [txti](http://txti.es/), [Sitey](https://www.sitey.com/), [mmm](https://build.mmm.page/), [cargo](https://cargo.site/), [Talium](https://talium.co/), [Jigsy](https://jigsy.com/), [Temper](https://temper.one/), [Neocities](https://neocities.org/), [Mobirise](https://mobirise.com/)

***

#### Web Scraping / Archiving Tools

[Wayback Machine](http://web.archive.org/) / [Downloader](https://github.com/hartator/wayback-machine-downloader), [2](https://github.com/jsvine/waybackpack) / [Addon](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/storage#wiki_wayback_machine_extension) / [Script](https://github.com/overcast07/wayback-machine-spn-scripts) / [Toolkit](https://github.com/wabarc/wayback), [awesome-web-scraping](https://github.com/lorien/awesome-web-scraping) / [2](https://github.com/iipc/awesome-web-archiving), [awesome-web-archiving](https://github.com/iipc/awesome-web-archiving), [ArchiveBox](https://github.com/ArchiveBox/ArchiveBox), [Collect](https://github.com/xarantolus/Collect), [grab-site](https://github.com/ArchiveTeam/grab-site), [Heritrix](https://github.com/internetarchive/heritrix3), [HTTrack](https://www.httrack.com/), [wail](https://github.com/machawk1/wail), [Webrecorder](https://github.com/Rhizome-Conifer/conifer), [WikiTeam](https://github.com/WikiTeam/wikiteam), [wallabag](https://github.com/wallabag/docker), [Conifer](https://github.com/Rhizome-Conifer/conifer), [CrowLeer](https://erap320.github.io/CrowLeer/), [brozzler](https://github.com/internetarchive/brozzler), [Kiwix](https://www.kiwix.org/en/), [wpull](https://github.com/ArchiveTeam/wpull), [suckit](https://github.com/skallwar/suckit), [wget](https://www.gnu.org/software/wget/) / [wget2](https://gitlab.com/gnuwget/wget2) / [Commands](https://www.whatismybrowser.com/developers/tools/wget-wizard/) / [Guide](https://web.archive.org/web/20210305122849/https://the-eye.eu/public/Wget_Windows_Guide.pdf), [zenscrape](https://zenscrape.com/), [scraping-bot](https://www.scraping-bot.io/), [webscraping](https://webscraping.ai/), [scrapingant](https://scrapingant.com/), [pyscrappy](https://pyscrappy.netlify.app/), [scrapestack](https://scrapestack.com/), [conifer](https://conifer.rhizome.org/), [archivy](https://archivy.github.io/), [archive.vn](https://archive.vn/), [cachedview](https://cachedview.nl/), [archivematica](https://www.archivematica.org/), [webarchive](https://www.webarchive.org.uk/), [cyotek-webcopy](https://www.cyotek.com/cyotek-webcopy), [Website-downloader](https://github.com/AhmadIbrahiim/Website-downloader), [Site-DWLoader](https://site-dwloader.herokuapp.com/), [archive.ph](https://archive.ph/), [timetravel](http://timetravel.mementoweb.org/), [Eternal](https://eternal.report/), [oldweb](https://oldweb.today/), [vortimo](https://www.vortimo.com/), [22120](https://github.com/i5ik/22120) (Browser Controller), [ghostarchive](http://ghostarchive.org/), [webrecorder](https://webrecorder.net/), [web.scraper](https://web.scraper.workers.dev/), [archive.fo](https://archive.fo/), [archivebox](https://archivebox.io/), [cachedpages](http://www.cachedpages.com/), [stealth](https://github.com/tholian-network/stealth), [replayweb](https://replayweb.page/) / [GitHub](https://github.com/webrecorder/replayweb.page), [CopySite](https://xdan.ru/copysite/, [Scrapy](https://scrapy.org/), [offliberty](http://offliberty.xyz/), [CachedView](https://cachedview.com/)

**Extensions** 

[SingleFileZ](https://github.com/gildas-lormeau/SingleFileZ), [archiveror](https://github.com/rahiel/archiveror), [archiveweb](https://archiveweb.page/), [Wayback Machine](https://github.com/internetarchive/wayback-machine-webextension), [Web Archives](https://github.com/dessant/web-archives), [Vandal](https://vegetableman.github.io/vandal/) / [Git](https://github.com/vegetableman/vandal), [simplescraper](https://simplescraper.io/), [markdownload](https://github.com/deathau/MarkDownload)

***

#### Windows 10 Antispy Tools

[ShutUp10](https://www.oo-software.com/en/shutup10), [Blackbird](https://www.getblackbird.net/), [W10Privacy](https://www.w10privacy.de/english-home/), [WPD](https://wpd.app/), [PrivateWin10](https://github.com/DavidXanatos/priv10), [Manage connection endpoints](https://docs.microsoft.com/en-us/windows/privacy/manage-windows-2004-endpoints), [Manage Microsoft Services connection endpoints](https://docs.microsoft.com/en-us/windows/privacy/manage-connections-from-windows-operating-system-components-to-microsoft-services), [gp-pack PaT](https://www.gp-pack.com/gp-pack-pat-privacy-and-telemetry/), [WindowsSpyBlocker](https://github.com/crazy-max/WindowsSpyBlocker), [privacy.sexy](https://privacy.sexy/), [optimizer](https://github.com/hellzerg/optimizer), [purge_windows_10_telemetry](https://github.com/bmrf/tron/blob/master/resources/stage_4_repair/disable_windows_telemetry/purge_windows_10_telemetry.bat), [DisableWinTracking](https://github.com/bitlog2/DisableWinTracking), [win10-unfuck](https://github.com/dfkt/win10-unfuck)

***

#### Windows 10 Debloater

**[Better Windows (Guide)](https://rentry.co/better-windows)**, **[QuickBoost](https://github.com/SanGraphic/QuickBoost)**, [Windows 10 Debloater](https://github.com/Sycnex/Windows10Debloater), [Win10AppRemove](https://github.com/WurstCommander/Win10AppRemove), [TronScript](https://old.reddit.com/r/TronScript/) / [DL](https://www.reddit.com/r/TronScript/wiki/downloads), [win10script](https://github.com/ChrisTitusTech/win10script) / [2](https://christitus.com/debloat-windows-10-2020/), [Decrapify Windows 10](https://gitlab.com/secure_croco/decrapify-windows10), [Ninjutsu](https://www.teamos-hkrg.com/threads/window-10-ninjutsu-v1-0-x64.128178/), [BloatBox](https://github.com/builtbybel/bloatbox), [Optimize-Offline](https://github.com/DrEmpiricism/Optimize-Offline), [CleanWin](https://github.com/pratyakshm/cleanwin), [Windows-Decrapifier](https://github.com/n1snt/Windows-Decrapifier), [Windows10PowerShellReimaging](https://github.com/aesser11/windows-reimage-script), [Remove-Windows10-Bloat](https://gist.github.com/matthewjberger/2f4295887d6cb5738fa34e597f457b7f), [Debloat Windows 10](https://github.com/W4RH4WK/Debloat-Windows-10), [Windows-Optimize-Harden-Debloat](https://github.com/simeononsecurity/Windows-Optimize-Harden-Debloat), [SophiApp](https://github.com/Sophia-Community/SophiApp), [WinRice](https://github.com/pratyakshm/WinRice), [TweakList](https://github.com/couleur-tweak-tips/TweakList), [Windows-On-Reins](https://github.com/gordonbay/Windows-On-Reins), [BRU](https://github.com/arcadesdude/BRU), [Windows-Bloatware-Removal](https://github.com/BallisticTurtle/Windows-Bloatware-Removal/blob/master/Remove%20Windows%20Bloatware.bat), [optimizer](https://github.com/hellzerg/optimizer/)

***

#### Windows File Explorers

* **[Everything](https://voidtools.com/)**
* [Total Commander](https://www.ghisler.com/)
* [OldNewExplorer](https://m.majorgeeks.com/files/details/oldnewexplorer.html)
* [Q-Dir](https://www.softwareok.com/?seite=Freeware/Q-Dir)
* [Sigma](https://github.com/aleksey-hoffman/sigma-file-manager)
* [Quick Access Popup](https://www.quickaccesspopup.com/)
* [Xplorer](https://github.com/kimlimjustin/xplorer)
* [One Commander](https://www.onecommander.com/)
* [Free Commander](https://freecommander.com/)
* [ExplorerEx](https://github.com/DearVa/ExplorerEx)
* [dive](https://github.com/ffaanngg/dive)
* [fd](https://github.com/sharkdp/fd)
* [Orange](https://github.com/naaive/orange)
* [Files](https://files.community/)
* [sist2](https://github.com/simon987/sist2)
* [MUCommander](https://www.mucommander.com/)
* [TablacusExplorer](https://tablacus.github.io/explorer_en.html) - [GitHub](https://github.com/tablacus/TablacusExplorer)
* [AlTap](https://www.altap.cz/)
* [AstroGrep](https://sourceforge.net/projects/astrogrep/)
* [DoubleCMD](https://github.com/doublecmd/doublecmd)
* [ExplorerPatcher](https://github.com/valinet/ExplorerPatcher)
* [Files](https://www.microsoft.com/en-us/p/files/9nghp3dx8hdx#activetab=pivot:overviewtab) - [Themes](https://www.microsoft.com/en-us/p/themes-for-files/9n20kq61lsfq?activetab=pivot:overviewtab)
* [Clover](http://en.ejie.me/) or [QTTabBar](http://qttabbar.wikidot.com/) - Windows Explorer Tabs
* [WinFile](https://github.com/microsoft/winfile) or [FileSearchEX](https://goffconcepts.com/products/filesearchex)/download.html) - Original Windows File Manager
* [Multi Commander](http://multicommander.com/) - Multi-Tabbed File Manager

***

#### Windows ISO

* **[TechBench](https://tb.rg-adguard.net/)**
* **[Bob Pony](https://downloadui.bobpony.com/)**
* **[Windows 10 LTSC](https://supreme-gamers.com/t/windows-10-ltsc-the-best-windows-10-version-ever.845/)** - [/r/Windows10LTSC](https://www.reddit.com/r/Windows10LTSC/)
* **[Windows AME](https://ameliorated.info/)**
* [Massgravel's Index](https://massgrave.dev/genuine-installation-media.html) / [Massgravel's WindowsAddict Archive](https://web.archive.org/web/20220301153730/https://windowsaddict.ml/readme-genuine-installation-media.html) / [Massgravel's Pastebin Archive](https://web.archive.org/web/20211231221536/https://pastebin.com/raw/jduBSazJ)
* [ReviOS](https://sites.google.com/view/meetrevision)
* [ISO Files](https://isofiles.bd581e55.workers.dev/0:/). [2](https://stuff.mtt-m1.workers.dev/)
* [microsoft-download-link-archive](https://github.com/luzeadev/microsoft-download-link-archive)
* [malwarewatch](https://dl.malwarewatch.org/windows/)
* [Windows ISO Google Doc](https://docs.google.com/spreadsheets/d/1zTF5uRJKfZ3ziLxAZHh47kF85ja34_OFB5C5bVSPumk/) 
* [VLSC](http://vlsc.ksu.ac.th/)
* [geeks4christ](http://www.geeks4christ.org/MS-OS/)
* [kacabenggala](https://kacabenggala.uny.ac.id/windows/)
* [Microsoft](https://www.microsoft.com/en-us/software-download/)
* [jerryching](http://jerryching.spdns.de/Software/ISO%20Backup/)
* [minerswin](http://root3.minerswin.de/ISO/Windows/)
* [ISO GDrive](https://docs.google.com/spreadsheets/d/e/2PACX-1vSScnE8yYzjgTlMiTpoGZ4VwDKHDanTld2_BXXliZg_nTyVVJq0ppvDJHiRFuMEoAO9UKHZqCG2o97T/pubhtml#)
* [AtlasOS](https://atlasos.net/) - Custom Windows 10 20H2 / [Discord](https://discord.com/invite/xx6S3g3HzE)
* [Fido](https://github.com/pbatard/Fido) - Powershell Script
* [ggOS](https://discord.gg/A5BHSQV) - Custom Windows 10 20H2
* [Windows Sun Valley](https://archive.org/details/windows-sv-pro-v-1) - Custom Windows 10 21H1
* [ReviOS](https://www.revi.cc/) - Custom Windows 10
* [Ghost Spectre](https://youtube.com/playlist?list=PLLP5vMyczsRwwyDQQBRJQfQtxozNkEWwk) - Custom Windows 10
* [Phoenix LiteOS](https://phoenixliteos.com/)  - Custom Windows 10
* [RekOS](https://discord.com/invite/YNFFN4W52y)  - Custom Windows 10
* [KernelOS](https://discord.gg/GYmNPtfwfs)  - Custom Windows 10
* [TheWorldofPC](https://nexusliteos.blogspot.com/)  - Custom Windows 10
* [FoxOS](https://discord.gg/A5Y76ymyBY) - Custom Windows 7
* [EagleOS](https://discord.gg/GCRxX8JE) - Custom Windows 7
* [OldSchoolOS](https://www.oldschoolos.com/), [OS Vault](https://osvault.weebly.com/directory.html), [VETUSWARE](https://vetusware.com/) or [WinWorldPC](https://winworldpc.com/) - Oldschool ISO's
* [MediaCreationTool.bat](https://gist.github.com/AveYo/c74dc774a8fb81a332b5d65613187b15) - Media Creation Tool Wrapper
* [Windows 10 Building](https://teamos-hkrg.com/threads/windows-10-building-and-modding-and-custom-os-s.129309/) - How-to Make Custom Windows 10 ISOs

***

#### Window Tiling Programs

[Plumb](https://palatialsoftware.com/plumb/), [nog](https://github.com/TimUntersberger/nog), [bug.n](https://github.com/fuhsjr00/bug.n), [GridMove](https://www.dcmembers.com/jgpaiva/), [Amethyst Windows](https://github.com/glsorre/amethystwindows), [WorkSpacer](https://www.workspacer.org/), [Komorebi](https://github.com/LGUG2Z/komorebi), [TileMe](https://gitlab.com/slavoutich/tileme), [WindowsGrid](http://windowgrid.net/), [FancyWM](https://apps.microsoft.com/store/detail/fancywm-dynamic-tiling-window-manager/9P1741LKHQS9?hl=en-in&gl=IN)

***

#### Wordpress Themes

[gpldl](https://gpldl.com/), [wplocker](https://www.wplocker.com/), [WePlay](https://www.weaplay.com/), [freegetdownloader](https://www.freegetdownloader.com/), [FreeNulledCode](https://freenulledcode.com/), [crackthemes](https://www.crackthemes.com/), [Mega Drive](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/base64#wiki_wordpress_themes), [jojo-themes](https://www.jojo-themes.net/), [babiato](https://babiato.co/), [newtemplate](https://newtemplate.net/), [justfreewpthemes](https://justfreewpthemes.com/), [themesplugins](https://themesplugins.club/)

***

#### Worldwide News Sites Index

[ABYZNews](http://www.abyznewslinks.com/), [AllYouCanRead](https://www.allyoucanread.com/), [W3Newspapers.com](https://www.w3newspapers.com/), [World-Newspapers](https://world-newspapers.com/), [OnlineNewspapers](http://www.onlinenewspapers.com/index.shtml), [4IMN](https://www.4imn.com/)

***

#### Youtube Android Apps

* **[ReVanced Manager](https://github.com/revanced/revanced-manager)** / [2](https://forum.mobilism.org/viewtopic.php?f=429&t=4858677)
* [Vanced Mirrors](https://mirror.codebucket.de/vanced/api/) / [2](https://vanced.esherloon.com/) / [3](https://github.com/cuynu/ytvanced) / [4](https://github.com/jinoo2005609/VancedManager) / [5](https://github.com/inotia00/VancedManager_v2) / [6](https://github.com/inotia00/VancedManager) / [7](https://t.me/vanced_mod_archive)
* [AfterVanced](https://www.reddit.com/r/AfterVanced/)
* [Skytube](https://skytube-app.com/) / [GitHub](https://github.com/SkyTubeTeam/SkyTube/)
* [NewPipe](https://newpipe.net/)
* [Newpipe w/ Sponsorblock](https://github.com/polymorphicshade/NewPipe)
* [VueTube](https://vuetube.app/) / [GitHub](https://github.com/Frontesque/VueTube)
* [uYouPlus](https://github.com/qnblackcat/uYouPlus)
* [WebTube](https://webtubeapp.xyz/)
* [Revanced Creator](https://github.com/XDream8/revanced-creator), [Revanced Builder](https://mega.nz/file/Omxn2T6L#PAJJ5V_ricfBt78CSqg21rL6rt-hP9RIUWbSyspEqQk), [revanced-build-template](https://github.com/n0k0m3/revanced-build-template), [Revanced Repo](https://github.com/Lyceris-chan/revanced-repo) or [Docker-Py-ReVanced](https://github.com/nikhilbadyal/docker-py-revanced) - Build Revanced App

***

#### YouTube Frontends

[Invidious](https://invidious.io/) / [2](https://tube.cadence.moe/) / [3](https://redirect.invidious.io/) / [4](https://inv.riverside.rocks/feed/popular) / [Instances](https://api.invidious.io/) / [TUI](https://github.com/darkhz/invidtui), [FreeTubeApp](https://freetubeapp.io/), [ViewTube](https://viewtube.io/) / [GitHub](https://github.com/ViewTube/viewtube-vue), [Piped](https://github.com/TeamPiped/Piped), [2](https://piped.kavin.rocks/), [PSTube](https://github.com/prateekmedia/pstube), [Youtube-local](https://github.com/user234683/youtube-local), [tube.cadence](https://tube.cadence.moe/), [invuedious](https://github.com/bocchilorenzo/invuedious), [YTB](https://ytb.trom.tf/), [WebTube](https://webtubeapp.xyz/)

***

#### YouTube Movies

* [Official YouTube Movies](https://www.youtube.com/feed/storefront?bp=kgEDCPYDogUCKAU%3D) / [TV](https://www.youtube.com/feed/storefront?bp=kgEDCO8HogUCKAU%3D)
* [YouTube Streaming Channels](https://rentry.co/YT-Movies)
* [FreeMovies](https://freemovies.ltd/)
* [Video Dictionary](https://videodictionary.kwebpia.net/)
* [MoviesFoundOnline](https://moviesfoundonline.com/) 
* [FREEMOVIESNOW](https://www.youtube.com/c/FREEMOVIESNOW/featured)
* [YT Movies Multireddit](https://www.reddit.com/user/nbatman/m/streaming/) - Youtube Streaming Subs

***

#### YouTube Music Players 

[YTMDesktop](https://github.com/JamesParkDev/ytmdesktop-adblock) / [2](https://ytmdesktop.app/), [AbleMusicPlayer](https://github.com/uditkarode/AbleMusicPlayer), [Youtube-Music](https://th-ch.github.io/youtube-music/) / [2](https://github.com/th-ch/youtube-music), [mps-youtube](https://github.com/mps-youtube/mps-youtube), [YMD](https://github.com/MaverickMartyn/youtube-music-desktop) 


***

#### YouTube to MP3

**[9xbuddy](https://9xbuddy.org/)**, **[YouTube-DL](https://github.com/ytdl-org/youtube-dl)** / **[GUIs](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/storage#wiki_yt-dl_tools)**, **[YT-DLP](https://github.com/yt-dlp/yt-dlp)** / **[Discord](https://discord.com/invite/H5MNcFW63r)**, **[YTMDL](https://ytmdl.deepjyoti30.dev/)** / [GitHub](https://github.com/deepjyoti30/ytmdl), **[Ripping Guide](https://redd.it/vv27dy)**, [YTDL-PATCHED](https://github.com/ytdl-patched/ytdl-patched), [Gramophy](https://github.com/rnayabed/gramophy), [YTMP3](https://ytmp3.ch/), [2](https://ytmp3.cc/), [3](https://ytmp3.eu/), [mps-youtube](https://github.com/mps-youtube/mps-youtube), [Ontiva](https://ontiva.com/), [YMP4](https://ymp4.cc/), [YouTube to MP3 Converter](https://www.mediahuman.com/youtube-to-mp3/22/), [loader](https://loader.to/), [YoutubeDL-Material](https://github.com/Tzahi12345/YoutubeDL-Material), [DeURL](http://deturl.com/), [Yout](https://yout.com/), [FLVto](https://www.flvto.biz/en83/), [FreeMake](https://www.freemake.com/free_video_downloader/), [AudioJack](http://blue9.github.io/AudioJack-GUI/), [megaconverter](https://megaconverter.net/), [videovor](https://www.videovor.com/en), [onlinevideoconverter](https://onlinevideoconverter.pro/), [yt-mp3s](https://www.yt-mp3s.com/), [savemp3](https://savemp3.cc/), [mp3youtubeconverter](https://mp3youtubeconverter.org/), [mp3fy](https://mp3fy.com/en37/), [youtubeplaylist](https://youtubeplaylist.cc/), [musicmp3](https://musicmp3.ru/), [y2mp3](https://www.y2mp3.net/), [mp3quack](https://mp3quack.wiki/), [mpgun](https://mpgun.com/convert-mp3-mp4-compliant), [ymp4](https://www.ymp4.download/), [mp3download](https://mp3download.to), [snappea](https://www.snappea.com/en7/), [ytmp3x](https://ytmp3x.com/), [ytformp3](https://ytformp3.com/), [snappea](https://www.snappea.com/), [mp3.studio](https://mp3.studio/), [y2meta](https://www.y2meta.com/), [okmusi](https://okmusi.com/), [myfreemp3](https://myfreemp3.to/), [topsandtees](https://getx.topsandtees.space/1YZ7z886l5), [mp3download](https://mp3download.one/en3, [ytmp4converter](https://ytmp4converter.com/), [ytm-proxy](https://github.com/harmonoid/ytm-proxy), [c-youtube](https://www.c-youtube.com/), [YT-RED-UI](https://github.com/adanvdo/YT-RED-UI), [tubemp3](https://tubemp3.to/), [dirpy](https://dirpy.com/)

***

#### YouTube Video Downloaders

**[YT-DL](https://github.com/ytdl-org/youtube-dl)** / **[GUIs](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/storage#wiki_yt-dl_tools)**, **[YT-DLP](https://github.com/yt-dlp/yt-dlp)**, [YTDL-PATCHED](https://github.com/ytdl-patched/ytdl-patched), [ytmp3](https://ytmp3.cc), [Local Youtube Downloader](https://greasyfork.org/en/scripts/369400-local-youtube-downloader), [Tartube](https://github.com/axcore/tartube), [YoutubeDL-Material](https://github.com/Tzahi12345/YoutubeDL-Material), [Youtube Video Downloader](https://github.com/OmarAflak/Youtube-Video-Downloader), [YouTube MP4](https://youtubemp4.to/), [DeURL](http://deturl.com/), [Ontiva](https://ontiva.com/), [YMP4](https://ymp4.cc/), [LocoDownloader](https://locoloader.com/), [FLVto](https://www.flvto.biz/en80/), [FreeMake](https://www.freemake.com/free_video_downloader/), [megaconverter](https://megaconverter.net/), [videovor](https://www.videovor.com/en), [onlinevideoconverter](https://onlinevideoconverter.pro/), [projectlounge ytdl](https://projectlounge.pw/ytdl), [snappea](https://www.snappea.com/en7/), [YoutubeDownloader](https://github.com/Tyrrrz/YoutubeDownloader), [savemp3](https://savemp3.cc/), [mp3youtubeconverter](https://mp3youtubeconverter.org/), [mpgun](https://mpgun.com/convert-mp3-mp4-compliant), [pobieracz](https://pobieracz.net/), [ymp4](https://www.ymp4.download/), [snappea](https://www.snappea.com/), [ytmp4converter](https://ytmp4converter.com/), [AllToMP3](https://alltomp3.org/), [YT-RED-UI](https://github.com/adanvdo/YT-RED-UI)

**Playlists**

[Loader](https://loader.to/), [YouTubeMultiDownloader](https://youtubemultidownloader.net/index.html), [KeepVid](https://keepvid.works/), [youtubeplaylist](https://youtubeplaylist.cc/)

***

#### YT-DL Tools

**[/r/YouTubeDL GUI List](https://www.reddit.com/r/youtubedl/wiki/info-guis)**, [GUI](https://mrs0m30n3.github.io/youtube-dl-gui/), [2](https://youtube-dl-helper.github.io/), [3](https://github.com/JaGoLi/ytdl-gui), [4](https://stacher.io/), [5](https://jely2002.github.io/youtube-dl-gui/), [6](https://github.com/KoleckOLP/yt-dl), [7](https://github.com/stefnotch/downline), [8](https://github.com/alexta69/metube), [9](https://github.com/Maxstupo/ydl-ui), [10](https://github.com/ShalmonAnandas/GUI-Youtube-dl), [11](https://github.com/emberedsky/skydl), [12](https://github.com/oleksis/youtube-dl-gui), [13](https://github.com/jely2002/youtube-dl-gui), [14](https://jeanslack.github.io/Videomass/), [15](https://github.com/Rudloff/alltube), [16](https://github.com/marcopeocchi/yt-dlp-web-ui), [17](https://github.com/mhogomchungu/media-downloader), [18](https://github.com/blackjack4494/yt-dlc)
[Scripts Index](https://github.com/TheFrenchGhosty/TheFrenchGhostys-Ultimate-YouTube-DL-Scripts-Collection) or [ytBATCH](https://github.com/eppic/ytBATCH)
[Colab](https://colab.research.google.com/drive/13G4Q8scsCPh6r9YqX39hqEUu7axq4Xr2)
[Bookmarklet](https://github.com/tardisx/gropple)

***

#### Z-Library Mirrors 

* https://b-ok.org/
* https://b-ok.cc/
* https://b-ok.xyz/
* https://b-ok.asia/
* https://booksc.org/
* https://b-ok.global/
* https://b-ok.lat/
* https://b-ok.africa/
* https://ua1lib.org/

***

#### Z-Library Tools

[Mirrors](https://www.reddit.com/r/FREEMEDIAHECKYEAH/wiki/storage#wiki_z-library_mirrors) / [Scraper](https://github.com/SofianeHamlaoui/b-ok-scraper) / [Amazon Links](https://github.com/annaelmoussa/amazon-zlibrary)

***

#### Zoom WE

[Firefox](https://addons.mozilla.org/en-US/firefox/addon/zoom-page-we/), [Chrome](https://chrome.google.com/webstore/detail/zoom-page-we/bcdjhkphgmiapajkphennjfgoehpodpk)
